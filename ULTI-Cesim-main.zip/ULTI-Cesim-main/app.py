import colorsys
import glob
import hashlib
import os
import re
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from cesim_parser import build_historico
from gap_analysis import (calcular_gaps, load_proyeccion, ronda_a_num, DEFAULT_PROYECCION_EXCEL,
                          precio_volumen_mercado, variacion_precio_volumen_mix, costo_unitario_area,
                          cuota_mercado_objetivo_vs_real, flujo_caja_plan_real_global,
                          demanda_estimada_vs_real,
                          TECNOLOGIAS as _TECNOLOGIAS_GAP, MERCADOS as _MERCADOS_GAP, AREAS as _AREAS_GAP,
                          MONEDA_MERCADO as _MONEDA_MERCADO_GAP)
from metric_crosswalk import CROSSWALK_FINANZAS, CROSSWALK_MERCADO, CROSSWALK_OPERACIONES, CROSSWALK_RESULTADOS
# Motor de proyección (build_gestion_v2.py, ver README del motor): genera el Excel de gestión
# ("ULTI_Gestion_v2.xlsx") al vuelo a partir de los RDOS de cada ronda jugada, sin tocar el disco
# del servidor (io.BytesIO) -- ver bloque "Generar Excel de gestión" en la sidebar, más abajo.
# Ronda N.N (Fase 4 -- arquitectura basada en repo, sin file_uploader): la fuente de RDOS oficiales y
# de decisiones previas ya no se sube a mano en cada corrida -- se lee de rutas fijas DENTRO del
# propio repo de GitHub (data/raw/oficial/ y data/decisiones/), commiteadas como parte del repo (igual
# que ya se commitea ULTI_Gestion_v2.xlsx hoy). generar_excel_desde_repo() hace todo: detecta la
# frontera REAL/PLAN, arma el Excel completo, rescata decisiones futuras cargadas en el archivo de
# decisiones anterior y congela el plan de la ronda que acaba de pasar a REAL.
from build_gestion_v2 import generar_excel_desde_repo, descubrir_ultima_proyeccion
# --- IDENTIDAD Y PALETA SEMÁNTICA ---
MY_COMPANY = 'ULTI'
COMPANIES = ['LUCKY', 'MECHA', 'PRELA', 'NEXUS', 'ULTI', 'NOSRE', 'NODO']
# Adenda 25 (a pedido del equipo, mockup aprobado -- Opción B "Ciruela"): antes un solo rojo
# (BRAND_ACCENT) hacía DOBLE trabajo -- identificar a CÁDIZ Y marcar negativo/crítico -- por eso
# casi todo el tablero "se veía mal" con solo ver el color. Se separan en dos constantes con un
# solo uso cada una:
#   COLOR_CADIZ    -- SOLO identidad ("esto es CADIZ", o el equipo en foco cuando coincide con
#                     CADIZ). Nunca se usa para positivo/negativo.
#   COLOR_NEGATIVE -- SOLO semántica negativo/crítico, universal para cualquier equipo (antes
#                     BRAND_ACCENT). COLOR_POSITIVE (verde) es su contraparte, sin cambios.
# BRAND_ACCENT queda retirado del código -- si aparece en algún lugar es una referencia vieja sin
# migrar, no una tercera opción válida.
COLOR_CADIZ = '#7C5CA8'        # Lila Ciruela -- identidad CADIZ
COLOR_NEGATIVE = '#B3261E'     # Rojo -- semántica negativo/crítico (mismo rojo que antes, ahora sin
                                # doble uso)
COLOR_POSITIVE = '#94D02D'     # Verde Lima
BRAND_DARK = '#1A1714'         # Negro Grafito
BRAND_LIGHT = '#F5F2ED'        # Crema
# Tonos apagados pero CON matiz (no gris puro) para distinguir competidores de un vistazo,
# sin competir visualmente con el lila de identidad de CADIZ.
MUTED_PALETTE = ['#8C97A6', '#A68C6E', '#7E9E8C', '#9E8CA0', '#A69B6E', '#7E8C9E']
# Adenda 25 (a pedido del equipo, "sacá ese marrón, ese tipo de cosas"): variante de MUTED_PALETTE
# SIN el marrón (índice 1) -- para usar en `color_discrete_sequence=` de gráficos con categorías
# genéricas (sin identidad ni sentimiento) donde Plotly asigna el color por ORDEN de aparición, no
# por nombre -- ahí un MUTED_PALETTE[1] "se cuela" igual aunque no se lo nombre a mano (fue el caso
# de "Mix tecnológico": Plotly le tocó el marrón a "Tec 2" solo por ser la 2ª tecnología de la
# lista). No se reemplaza por lila: siguen siendo categorías sin identidad de CADIZ.
# Fix adicional (feedback "ya casi"): sacar el marrón no alcanzaba -- MUTED_PALETTE[5] y [0] son dos
# grises azulados casi idénticos (distancia RGB ~19.5, muy por debajo del resto de la paleta) y
# MUTED_PALETTE[4] (kaki) está a solo ~15 de distancia del marrón baneado, o sea que seguía leyéndose
# como una variante de marrón. Se reemplazaron por '#58759D' (azul acero) y '#B67C8F' (rosa apagado).
# Adenda 28 (feedback "poca diferencia entre colores, seguí una paleta única"): la versión anterior
# de MUTED_SIN_MARRON (gris azulado + sage + rosa apagado + lila grisáceo + azul acero) fue auditada
# con el validador de contraste de la skill dataviz (validate_palette.js, método OKLab/CVD) y
# reprobó: el par gris/sage medía apenas ΔE 5.3 en visión normal (piso mínimo aceptable: 15) y el
# par ámbar/sage del gráfico de WACC medía ΔE 13.4, también por debajo del piso. Paleta nueva,
# verificada con el mismo validador (5 colores, modo claro, lista de pares adyacentes -- el uso real
# es en barras/torta/chips, no en dispersión, así que ese es el criterio correcto de la skill):
# TODOS los checks pasan (Lightness band, Chroma floor, CVD separation, Normal-vision floor). Los
# primeros dos colores son deliberadamente los mismos hex que COLOR_METRICA['riesgo'] (ámbar) y
# COLOR_METRICA['dinero'] (azul, definido más abajo -- no se puede referenciar el dict acá porque
# todavía no existe en este punto del archivo) -- ya usados en el resto de la app -- para que el
# gráfico de Mix tecnológico y el de Deuda/Equity del WACC compartan una paleta única y reconocible,
# en vez de dos sets de colores distintos sin relación entre sí.
MUTED_SIN_MARRON = ['#C9922E', '#3E7CB1', '#1BAF7A', '#E87BA4', '#4A3AA7']
# Color por CONCEPTO, no por orden de aparición. El lila de marca queda reservado para
# identificar a CÁDIZ entre los equipos; las métricas usan colores con significado propio
# y estable en toda la app (antes el rojo era "Salario" en un gráfico y "Rotación" en el de al lado).
COLOR_METRICA = {
    'dinero':      '#3E7CB1',   # azul  — plata: costos, presupuestos, salarios
    'personas':    '#8C97A6',   # gris azulado — headcount, contrataciones
    'eficiencia':  '#4E9A4E',   # verde — indicadores donde más es mejor
    'riesgo':      '#C9922E',   # ámbar — rotación, deuda, alertas blandas
    'critico':     COLOR_NEGATIVE # rojo  — problemas (ya no comparte color con "es CADIZ")
}
COLOR_MAP = {MY_COMPANY: COLOR_CADIZ}
for i, c in enumerate([c for c in COMPANIES if c != MY_COMPANY]):
    COLOR_MAP[c] = MUTED_PALETTE[i % len(MUTED_PALETTE)]

def _hex_a_rgba(hex_color, alpha):
    """Convierte '#RRGGBB' a 'rgba(r,g,b,alpha)' -- para fills semitransparentes que tienen que
    matchear el color de línea que sea (antes varios fills estaban hardcodeados al rojo/lila de
    marca sin importar qué color se pasara)."""
    h = (hex_color or '').lstrip('#')
    if len(h) != 6:
        return f'rgba(140,151,166,{alpha})'
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    return f'rgba({r},{g},{b},{alpha})'
def _ramp_secuencial(hex_color, n, claro=0.88):
    """Genera `n` tonos de UN SOLO hue, de claro a oscuro (regla de la skill de dataviz: "Sequential
    = one hue, light->dark") -- interpola en HLS desde un tinte muy claro del mismo matiz hasta el
    color pedido (el escalón más oscuro/saturado de la rampa). Se usa para dimensiones ORDENADAS
    (ej. año) en vez de una paleta categórica de colores distintos -- escala sola a cualquier
    cantidad de escalones sin quedarse sin colores."""
    h = (hex_color or '').lstrip('#')
    if len(h) != 6 or n <= 0:
        return [hex_color] * max(n, 1)
    r, g, b = int(h[0:2], 16) / 255, int(h[2:4], 16) / 255, int(h[4:6], 16) / 255
    hue, light, sat = colorsys.rgb_to_hls(r, g, b)
    if n == 1:
        return [hex_color]
    out = []
    for i in range(n):
        t = i / (n - 1)
        l_i = claro + (light - claro) * t
        s_i = (sat * 0.45) + (sat * 0.55) * t
        r2, g2, b2 = colorsys.hls_to_rgb(hue, l_i, s_i)
        out.append('#{:02x}{:02x}{:02x}'.format(round(r2 * 255), round(g2 * 255), round(b2 * 255)))
    return out
RONDAS_ORDENADAS = [f'Año {i}' for i in range(13)]
CHART_HEIGHT = 260      # alto del área de ploteo de referencia
ALTURA_TARJETA = 370    # alto FIJO de toda tarjeta de gráfico, con o sin leyenda abajo:
                        # es lo que garantiza que dos gráficos en columnas queden parejos
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'data', 'raw')
DIR_DECISIONES = os.path.join(BASE_DIR, 'data', 'decisiones')
st.set_page_config(page_title='ULTI | Tablero Directivo', layout='wide')
# ---------------- Carga de datos y Helpers ----------------
def get_pais(estado: str) -> str:
    if re.search(r'\bGlobal\b', estado) or 'casa matriz' in estado: return 'Global'
    if 'EE.UU.' in estado: return 'EE.UU.'
    if 'Asia' in estado: return 'Asia'
    if 'Europa' in estado: return 'Europa'
    return 'General'
_CESIM_PARSER_PATH = os.path.join(BASE_DIR, 'cesim_parser.py')
def _parser_version() -> str:
    """Firma de versión de `cesim_parser.py` para el caché de `cargar_historico`.

    Bug real, corregido (encontrado por el equipo en despliegue -- la web mostraba datos "Ronda N"
    viejos después de subir el rename "Ronda"->"Año", aunque el código ya estaba actualizado):
    `st.cache_data` solo hashea el bytecode de la función decorada (`cargar_historico`) más sus
    argumentos -- NO hashea el de los módulos que esa función llama (acá, `cesim_parser.py`, donde
    vive la lógica real de parseo). Un cambio en `cesim_parser.py` que no toque también el cuerpo de
    `cargar_historico` no invalidaba el caché por sí solo, y el dashboard podía quedar sirviendo
    datos parseados con la lógica VIEJA aunque el código desplegado fuera el nuevo (el slider y el
    resto de la UI sí mostraban "Año N" porque `rondas_timeline` es una lista fija, no depende del
    caché -- pero cualquier cruce contra los datos reales, que sí dependía del caché, no encontraba
    nada). Fix: se incluye un hash del contenido de `cesim_parser.py` como parte de la firma de
    caché -- cualquier cambio futuro en ese archivo invalida el caché automáticamente, sin depender
    de acordarse de hacer un reboot completo de la app."""
    try:
        with open(_CESIM_PARSER_PATH, 'rb') as f:
            return hashlib.sha256(f.read()).hexdigest()[:16]
    except OSError:
        return 'unknown'
@st.cache_data(show_spinner='Procesando rondas...')
def cargar_historico(files_signature: tuple, parser_version: str) -> pd.DataFrame:
    data = build_historico(list(files_signature))
    data['Pais'] = data['Estado'].apply(get_pais)
    return data
def get_data(tipo_ronda) -> pd.DataFrame:
    xls_files = sorted(glob.glob(os.path.join(DATA_DIR, '**', '*.xls'), recursive=True) +
                       glob.glob(os.path.join(DATA_DIR, '**', '*.XLS'), recursive=True))
    if not xls_files:
        st.warning(f'No se encontraron archivos .xls en {DATA_DIR} ni en subcarpetas.')
        st.stop()
    df_raw = cargar_historico(tuple(xls_files), _parser_version())
    return df_raw[df_raw['Tipo_Ronda'] == tipo_ronda].copy()
@st.cache_data(show_spinner='Leyendo proyección de ULTI...')
def _cargar_proyeccion_cached(path: str, mtime: float):
    # `mtime` en la firma de cache -- no se usa dentro de la función, pero cambia cada vez que se
    # reemplaza ULTI_Gestion_v2.xlsx en el repo (mismo nombre de archivo), así Streamlit invalida
    # el caché y relee el Excel en vez de servir una versión vieja. Devuelve un DataFrame o None.
    return load_proyeccion(path)
def get_proyeccion(ronda_num=None):
    """Ronda N.N+1 (bug real, corregido -- a pedido de Mati, confirmado contra el repo real): cada
    Ulti_proyeccion_R{N}.xlsx es AUTOSUFICIENTE para comparar la ronda N contra SU PROPIO plan --
    trae su propia fila status='PLAN', round=N para CADIZ (ver gap_analysis._valor_proyeccion, que
    filtra por round==ronda_num SIN filtrar por status). El lado 'Real' de la comparación nunca sale
    de este archivo -- sale siempre de df_all/df (parseado directo de los RDOS vía cesim_parser) --
    así que para comparar una ronda YA JUGADA no hace falta el archivo "más reciente" ni que la
    cadena de Plan Congelado (extraer_plan_congelado/inyectar_plan_congelado) haya arrastrado bien
    esa ronda hasta hoy: alcanza con abrir el archivo CON ESE MISMO NÚMERO de ronda.

    Bug real, corregido: antes esta función usaba SIEMPRE descubrir_ultima_proyeccion() (el N más
    alto commiteado en data/decisiones/), asumiendo que ese único archivo traía el Plan de TODAS las
    rondas anteriores todavía congelado. Verificado contra el repo real: esa cadena se rompió en
    alguna corrida intermedia -- Ulti_proyeccion_R6.xlsx (el commiteado) NO trae el Plan congelado
    de las Rondas 2, 4 y 5, que Ulti_proyeccion_R4.xlsx/R5.xlsx SÍ tenían en su momento (confirmado
    leyendo la hoja DATA_EXPORT de cada archivo: R4.xlsx trae round=2 con status PLAN+REAL, R5.xlsx
    trae round=2 y round=4 con PLAN+REAL, R6.xlsx no trae ningún PLAN de rondas 0-5). Como Control de
    Gestión siempre leía el último archivo commiteado, Ronda 3/4/5 mostraban "sin datos" en vez del
    desvío Plan vs. Real, aunque esas rondas SÍ tuvieran su propio Ulti_proyeccion_R{N}.xlsx cargado
    en el repo. Ahora cada ronda lee DIRECTAMENTE su propio archivo -- no depende de que ninguna
    corrida posterior lo haya "arrastrado" bien.

    ronda_num=None (o sin archivo con ese número exacto -- ej. una ronda que todavía no tiene su
    propio Ulti_proyeccion_R{N}.xlsx generado) cae al comportamiento viejo: el N más alto
    commiteado en data/decisiones/, y si tampoco hay ninguno, al viejo ULTI_Gestion_v2.xlsx en la
    raíz por compatibilidad -- si nada de eso existe, no hay proyección para mostrar (la app debe
    poder arrancar igual)."""
    path = None
    if ronda_num is not None:
        for pref in ("Ulti_proyeccion_R", "Cadiz_proyeccion_R"):
            candidato = os.path.join(DIR_DECISIONES, f"{pref}{ronda_num}.xlsx")
            if os.path.exists(candidato):
                path = candidato
                break
    if path is None:
        path = descubrir_ultima_proyeccion(DIR_DECISIONES)
    if path is None:
        for fallback_name in (DEFAULT_PROYECCION_EXCEL, os.path.join(BASE_DIR, "CADIZ_Gestion_v2.xlsx")):
            if os.path.exists(fallback_name):
                path = fallback_name
                break
    if path is None:
        return None
    return _cargar_proyeccion_cached(path, os.path.getmtime(path))
def num(series):
    return pd.to_numeric(series, errors='coerce')
def format_num(val, dec=1):
    """Al menos un decimal en todos los rangos (antes el corte de miles truncaba a entero, ej.
    '638k' en vez de '638.2k' -- perdía precisión visible justo en el rango donde más se usa)."""
    if pd.isna(val) or val is None: return ""
    try:
        val = float(val)
        dec = max(dec, 1)
        # Nivel 'B' (miles de millones) agregado a pedido del equipo -- las Valorizaciones de mercado
        # derivadas de Volumen x Precio (industria completa, USD) caen naturalmente en este rango una
        # vez corregido el bug de escala x1000 (ver _industria_dinamica_mercado/_tech): sin este nivel,
        # $74.8B se mostraba truncado como "74,790.4M" en vez de "74.8B". No afecta ningún valor que
        # ya se mostrara en rango M/k -- solo agrega un piso nuevo arriba de 1000M.
        if abs(val) >= 1_000_000_000: return f"{val/1_000_000_000:,.1f}B"
        if abs(val) >= 1_000_000: return f"{val/1_000_000:,.1f}M"
        if abs(val) >= 1_000: return f"{val/1_000:,.1f}k"
        return f"{val:,.{dec}f}"
    except (ValueError, TypeError):
        return ""
def _texto_cascada(valores, base=None):
    """Texto para las barras de un gráfico en cascada (Waterfall): valor absoluto + % sobre la barra
    de referencia -- por defecto la PRIMERA barra de la cascada (el ancla desde la que se arma el
    resto, ej. 'Ingresos Proyectados', 'Costo Proyectado', 'Precio'). A pedido del equipo: además
    del valor absoluto, mostrar también el %, en todos los gráficos en cascada de la app. Si la base
    es 0/None (o el valor no es numérico), se muestra solo el absoluto -- dividir por 0 no aporta."""
    base = valores[0] if base is None else base
    out = []
    for v in valores:
        if base not in (None, 0) and pd.notna(v) and pd.notna(base):
            out.append(f'{format_num(v)} ({v / base * 100:.1f}%)')
        else:
            out.append(format_num(v))
    return out
def valor_de(sub_df, metrica, empresa=None):
    d = sub_df[sub_df['Metrica'] == metrica]
    if empresa: d = d[d['Empresa'] == empresa]
    return pd.to_numeric(d['Valor'].iloc[0], errors='coerce') if not d.empty else None
def valor_texto(sub_df, metrica, empresa=None):
    """Como valor_de, pero para campos de texto (ej. calificación crediticia 'A+') —
    no fuerza conversión a número, así que no se rompe en NaN."""
    d = sub_df[sub_df['Metrica'] == metrica]
    if empresa: d = d[d['Empresa'] == empresa]
    return d['Valor'].iloc[0] if not d.empty else None
def valor_fuzzy(sub_df, keyword, empresa=None):
    d = sub_df[sub_df['Metrica'].str.contains(rf'{keyword}', case=False, na=False)]
    if empresa: d = d[d['Empresa'] == empresa]
    return pd.to_numeric(d['Valor'].iloc[0], errors='coerce') if not d.empty else None
def es_modo_oscuro():
    """Fuente de verdad única: el tema REAL de Streamlit (nativo, el que el usuario elige en
    Settings o 'usar el del sistema'), no un toggle casero desconectado del resto de la UI."""
    try:
        return st.context.theme.type == 'dark'
    except Exception:
        return True
def mostrar(fig, ocultar_eje_valores=None, en_card=True, altura=None, margen_b=None, **kwargs):
    oscuro = es_modo_oscuro()
    # Si la figura ya trae leyenda propia posicionada abajo (y<0), necesita más alto/margen
    # para que la leyenda no quede tapando el gráfico.
    leyenda_abajo = False
    for ln in ('legend', 'legend2'):
        leg = getattr(fig.layout, ln, None)
        if leg is not None and leg.y is not None and leg.y < 0:
            leyenda_abajo = True
    # Altura ÚNICA para todos los gráficos del tablero. Antes cada figura podía traer la suya
    # (CHART_HEIGHT, +20, +60, 280) y las que tenían leyenda abajo crecían: dos gráficos en
    # columnas contiguas terminaban de distinto alto. Ahora la tarjeta siempre mide lo mismo y
    # lo único que cambia es cuánto de ese alto se reserva abajo para la leyenda.
    # Adenda 23: 'altura' opcional para paneles que agrupan varios KPIs en una sola figura (ej.
    # chart_bullet_panel) -- necesitan más alto que ALTURA_TARJETA cuando tienen muchas filas, y
    # menos cuando tienen pocas; el resto de los llamados no pasa este parámetro y sigue con el
    # alto fijo de siempre (ALTURA_TARJETA), sin cambio de comportamiento.
    altura = altura or ALTURA_TARJETA
    # Adenda 24: 'margen_b' opcional -- BUG REPORTADO (leyenda y anotaciones tapando las barras en
    # chart_bullet_panel): el margen inferior fijo (110px) se restaba de un 'altura' que en paneles
    # de pocas filas quedaba demasiado chica, dejando un área de ploteo casi nula -- ahí cualquier
    # offset de leyenda (que es una FRACCIÓN del área de ploteo, no de la figura entera) terminaba en
    # unos pocos píxeles, es decir prácticamente pegado al eje X, encima de las barras y anotaciones.
    # Quien llama con pocas filas ahora puede pedir un margen distinto sin afectar los ~40 llamados
    # existentes que no lo pasan (siguen con 110/20 de siempre).
    if margen_b is None:
        margen_b = 110 if leyenda_abajo else 20
    color_linea_eje = '#4A4642' if oscuro else '#D8D3CC'
    fig.update_layout(template='plotly_dark' if oscuro else 'plotly_white',
                       paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)',
                       font=dict(color=BRAND_LIGHT if oscuro else BRAND_DARK, family='Plus Jakarta Sans, sans-serif'),
                       title_font=dict(family='Plus Jakarta Sans, sans-serif', size=14, weight=600),
                       margin=dict(l=20, r=20, t=45, b=margen_b),
                       height=altura,
                       bargap=0.4)
    fig.update_xaxes(showgrid=False, zeroline=False, showline=True, linewidth=1, linecolor=color_linea_eje)
    fig.update_yaxes(showgrid=False, zeroline=False, showline=True, linewidth=1, linecolor=color_linea_eje)

    if ocultar_eje_valores == 'y': fig.update_yaxes(showticklabels=False, title=None)
    elif ocultar_eje_valores == 'x': fig.update_xaxes(showticklabels=False, title=None)
    
    if en_card:
        with st.container(border=True): st.plotly_chart(fig, use_container_width=True, **kwargs)
    else: st.plotly_chart(fig, use_container_width=True, **kwargs)
def linea_media(fig, valor, eje='y', etiqueta='Promedio'):
    if pd.isna(valor): return
    color_ref = 'rgba(255,255,255,0.35)' if es_modo_oscuro() else 'rgba(26,23,20,0.35)'
    kwargs = dict(line_dash='dash', line_color=color_ref, line_width=1.5,
                  annotation_text=etiqueta, annotation_font_size=10, annotation_font_color=color_ref)
    if eje == 'y': fig.add_hline(y=valor, **kwargs)
    else: fig.add_vline(x=valor, **kwargs)
def chart_comparacion_equipos(sub: pd.DataFrame, titulo: str, ronda=None):
    ronda = ronda or ronda_ultima
    d = sub[sub['Ronda'] == ronda].copy()
    d['Valor'] = num(d['Valor'])
    d = d.dropna(subset=['Valor']).sort_values('Valor', ascending=False)
    if d.empty: return st.info('Sin datos numéricos.')
    d['Etiqueta'] = d['Valor'].apply(format_num)
    fig = px.bar(d, x='Empresa', y='Valor', color='Empresa', color_discrete_map=COLOR_MAP, title=f'{titulo} — {ronda}', text='Etiqueta')
    fig.update_traces(textposition='outside', cliponaxis=False, showlegend=False)
    mostrar(fig, ocultar_eje_valores='y')
def _hover_yoy_textos(rondas, valores, fmt_fn=None):
    """Construye la lista de textos de hover para cualquier serie evolutiva (x=rondas, y=valores),
    incluyendo siempre la variación % contra el punto inmediatamente anterior de la misma serie."""
    fmt_fn = fmt_fn or format_num
    r_list = list(rondas)
    v_list = [pd.to_numeric(v, errors='coerce') for v in valores]
    out = []
    for i, (r_act, v_act) in enumerate(zip(r_list, v_list)):
        if pd.isna(v_act):
            out.append('')
            continue
        base_txt = fmt_fn(v_act)
        if i > 0 and pd.notna(v_list[i - 1]) and v_list[i - 1] != 0:
            yoy = (v_act - v_list[i - 1]) / abs(v_list[i - 1]) * 100
            r_prev_corto = str(r_list[i - 1]).replace('Año ', 'A')
            out.append(f'{base_txt} ({yoy:+.1f}% vs. {r_prev_corto})')
        else:
            out.append(base_txt)
    return out

def chart_evolucion(sub: pd.DataFrame, titulo: str, altura=None):
    ev = sub.copy()
    ev['Valor'] = num(ev['Valor'])
    ev = ev.dropna(subset=['Valor'])
    if ev.empty: return st.info('Sin datos para evolución.')
    fig = go.Figure()
    for comp in COMPANIES:
        d = ev[ev['Empresa'] == comp].sort_values('Ronda_Orden').copy()
        if d.empty: continue
        es_cadiz = comp == MY_COMPANY
        d['Valor_Prev'] = d['Valor'].shift(1)
        d['YoY'] = (d['Valor'] - d['Valor_Prev']) / d['Valor_Prev'].replace(0, np.nan).abs() * 100
        textos = [f"{format_num(r['Valor'])} ({r['YoY']:+.1f}% vs. {r_prev.replace('Año ', 'A')})"
                  if pd.notna(r['YoY']) and isinstance(r_prev, str) else format_num(r['Valor'])
                  for (_, r), r_prev in zip(d.iterrows(), d['Ronda'].shift(1))]
        fig.add_trace(go.Scatter(x=d['Ronda'], y=d['Valor'], mode='lines+markers', name=comp,
                                  line=dict(color=COLOR_MAP[comp], width=3 if es_cadiz else 1),
                                  marker=dict(size=6 if es_cadiz else 4), opacity=1.0 if es_cadiz else 0.5,
                                  text=textos, hovertemplate=f'<b>%{{x}}</b><br>{comp}: %{{text}}<extra></extra>'))
    promedio_x_ronda = ev.groupby('Ronda_Orden').agg(Ronda=('Ronda', 'first'), Valor=('Valor', 'mean')).sort_index()
    if len(promedio_x_ronda) > 0:
        promedio_x_ronda['Valor_Prev'] = promedio_x_ronda['Valor'].shift(1)
        promedio_x_ronda['YoY'] = (promedio_x_ronda['Valor'] - promedio_x_ronda['Valor_Prev']) / promedio_x_ronda['Valor_Prev'].replace(0, np.nan).abs() * 100
        textos_prom = [f"{format_num(r['Valor'])} ({r['YoY']:+.1f}% vs. {r_prev.replace('Año ', 'A')})"
                       if pd.notna(r['YoY']) and isinstance(r_prev, str) else format_num(r['Valor'])
                       for (_, r), r_prev in zip(promedio_x_ronda.iterrows(), promedio_x_ronda['Ronda'].shift(1))]
        color_ref = 'rgba(255,255,255,0.35)' if es_modo_oscuro() else 'rgba(26,23,20,0.35)'
        fig.add_trace(go.Scatter(x=promedio_x_ronda['Ronda'], y=promedio_x_ronda['Valor'], mode='lines+markers',
                                  name='Promedio', line=dict(color=color_ref, width=1, dash='dash'), marker=dict(size=4),
                                  text=textos_prom, hovertemplate='<b>%{x}</b><br>Promedio: %{text}<extra></extra>'))
    fig.update_layout(title=f'Evolución — {titulo}', xaxis=dict(categoryorder='array', categoryarray=RONDAS_ORDENADAS))
    # 'altura' opcional (a pedido del equipo, "muy chiquitos" -- ver Finanzas): los 7 gráficos de
    # evolución (8 series: 7 equipos + Promedio) necesitan más alto que el fijo de ALTURA_TARJETA
    # (370px) para leerse bien a ancho completo -- default None preserva el alto de siempre en
    # el resto de los ~15 llamados a chart_evolucion() que no lo pasan.
    mostrar(fig, altura=altura)
def chart_evolucion_proyeccion(df_proy: pd.DataFrame, metric: str, region: str, titulo: str, team='ULTI'):
    """Evolución de una métrica que CADIZ proyecta pero que CESIM nunca publica en el RDOS (ej. FCF) --
    a diferencia de chart_evolucion (que grafica el dato REAL de los 7 equipos), acá solo hay una
    serie: la propia proyección de ULTI, ronda a ronda. Se muestra igual, sin comparación, para no
    perder de vista la tendencia de un indicador que de otro modo quedaría sin ningún gráfico."""
    if df_proy is None:
        return st.info('Sin proyección cargada.')
    sub = df_proy[(df_proy['team'] == team) & (df_proy['metric'] == metric) & (df_proy['region'] == region)].copy()
    sub['value'] = pd.to_numeric(sub['value'], errors='coerce')
    sub = sub.dropna(subset=['value']).sort_values('round')
    if sub.empty:
        return st.info('Sin datos para evolución.')
    textos_p = _hover_yoy_textos(sub['round'], sub['value'])
    fig = go.Figure(go.Scatter(x=sub['round'], y=sub['value'], mode='lines+markers', name=team,
                                line=dict(color=COLOR_MAP.get(team, COLOR_CADIZ), width=3), marker=dict(size=6),
                                text=textos_p, hovertemplate=f'<b>Año %{{x}}</b><br>{team}: %{{text}}<extra></extra>'))
    fig.update_layout(title=f'Evolución de la proyección — {titulo}', xaxis_title='Año')
    mostrar(fig)
def _techo_apilado(y):
    """Techo del eje con ~15% de aire arriba del máximo real -- ver nota en chart_dos_metricas_apiladas
    sobre por qué no alcanza con rangemode='tozero' solo para barras."""
    y_vals = [v for v in y if v is not None and not pd.isna(v)]
    y_max = max(y_vals) if y_vals else 0
    return y_max * 1.15 if y_max > 0 else 1
def chart_dos_metricas_apiladas(titulo, x_a, y_a, nombre_a, color_a, tipo_a,
                                 x_b, y_b, nombre_b, color_b, tipo_b):
    """UN solo gráfico, eje X compartido (misma Ronda), con la primera métrica en el eje Y
    izquierdo y la segunda en el eje Y derecho (doble eje Y superpuesto) -- a pedido explícito del
    equipo, que prefirió esto a la versión anterior (dos paneles apilados, cada uno con su propio
    eje). OJO: esto reintroduce a propósito el patrón de "doble eje Y" que se había evitado acá
    mismo (y que se sacó del todo en Mercado -> Evolución, "Trayectoria de precio y
    características", por el riesgo de sugerir una correlación entre las dos series que no está
    probada) -- queda anotado por si conviene revisar el criterio más adelante, pero el pedido fue
    explícito y puntual para ESTOS gráficos (RRHH y Beneficio vs. Deuda), no una vuelta atrás
    general de criterio."""
    fig = go.Figure()
    def _trace(x, y, nombre, color, tipo, yaxis):
        textos_t = _hover_yoy_textos(x, y)
        if tipo == 'bar':
            fig.add_trace(go.Bar(x=x, y=y, name=nombre, marker_color=color, yaxis=yaxis, opacity=0.85,
                                  customdata=textos_t, hovertemplate=f'<b>%{{x}}</b><br>{nombre}: %{{customdata}}<extra></extra>'))
        else:
            fig.add_trace(go.Scatter(x=x, y=y, name=nombre, mode='lines+markers',
                                      line=dict(color=color, width=3), yaxis=yaxis,
                                      text=textos_t, hovertemplate=f'<b>%{{x}}</b><br>{nombre}: %{{text}}<extra></extra>'))
    _trace(x_a, y_a, nombre_a, color_a, tipo_a, 'y1')
    _trace(x_b, y_b, nombre_b, color_b, tipo_b, 'y2')
    fig.update_layout(
        title=titulo,
        yaxis=dict(title=nombre_a, title_font=dict(size=10, color=color_a), tickfont=dict(color=color_a),
                   range=[0, _techo_apilado(y_a)], side='left'),
        yaxis2=dict(title=nombre_b, title_font=dict(size=10, color=color_b), tickfont=dict(color=color_b),
                    range=[0, _techo_apilado(y_b)], overlaying='y', side='right', showgrid=False),
        xaxis=dict(categoryorder='array', categoryarray=RONDAS_ORDENADAS),
        legend=dict(orientation='h', yanchor='top', y=-0.25, xanchor='center', x=0.5))
    mostrar(fig)
def sparkline(valores, color=None, invertir=False):
    """Minigráfico de tendencia para meter dentro de una tarjeta de KPI.
    Con 12-15 rondas, un número solo no dice nada: la forma de la serie sí.

    Adenda 25: el default ya NO es el lila/rojo de marca -- sparkline() es un helper genérico que no
    sabe de qué equipo es la serie (los dos llamadores lo usan para el equipo EN FOCO, que puede no
    ser CADIZ), así que asumir un color de identidad acá era el mismo bug de fondo que motivó esta
    limpieza de paleta. El default es un gris neutro; quien llama y sabe de qué equipo se trata debe
    pasar `color=COLOR_MAP.get(ese_equipo, ...)` explícito (ver _seccion_resultado_resumen)."""
    serie = [v for v in valores if v is not None and not pd.isna(v)]
    if len(serie) < 2:
        return None
    color = color or MUTED_PALETTE[0]
    fig = go.Figure(go.Scatter(y=serie, mode='lines', line=dict(color=color, width=2),
                                fill='tozeroy', fillcolor=_hex_a_rgba(color, 0.12), hoverinfo='skip'))
    fig.update_layout(height=46, margin=dict(l=0, r=0, t=0, b=0),
                       paper_bgcolor='rgba(0,0,0,0)', plot_bgcolor='rgba(0,0,0,0)',
                       xaxis=dict(visible=False), yaxis=dict(visible=False, autorange='reversed' if invertir else True),
                       showlegend=False)
    return fig
def chart_bullet(titulo, valor_fondo, valor_frente, tipo, nombre_fondo='Proyectado', nombre_frente='Real',
                  color_excedente=None):
    """Barra de progreso con desborde apilado: `valor_fondo` (Proyectado, o Punto de Equilibrio) define
    el 100% = el largo de la pista de referencia. `valor_frente` (Real) se dibuja como relleno DENTRO
    de esa pista; si la supera, el excedente se apila como un segmento aparte que sobresale del final
    de la pista en vez de superponer dos barras independientes (diseño anterior) -- así se ve de un
    vistazo si el Real se pasó del Proyectado y por cuánto, no solo que son distintos.

    `color_excedente` tiñe ese segmento de sobra: quien llama puede pasar el color que corresponda a
    si pasarse del Proyectado es favorable o no para esa métrica puntual (ej. superar el Punto de
    Equilibrio es bueno; superar una Deuda CP no planificada, no) -- por defecto un ámbar neutro
    ('se pasó de la referencia', sin prejuzgar si es bueno o malo) para cuando no se sabe.

    Reutilizado por la Fila 2 de la Comparativa Plan vs. Real (Proyectado vs. Real) y por el gráfico
    de Punto de Equilibrio de Operaciones (Volumen de Equilibrio vs. Volumen Real Vendido)."""
    if valor_fondo is None or valor_frente is None:
        return st.info('Sin dato para graficar.')
    plan, real = float(valor_fondo), float(valor_frente)
    color_excedente = color_excedente or COLOR_METRICA['riesgo']
    color_ref = 'rgba(255,255,255,0.5)' if es_modo_oscuro() else 'rgba(26,23,20,0.5)'
    fig = go.Figure()
    if plan > 0:
        # Normalizado a % del Proyectado: la pista siempre mide 100 = Plan, así el "se pasó de largo"
        # es directamente visual (el segmento de excedente empieza justo donde termina la pista) y
        # comparable entre KPIs de escalas muy distintas (USD, unidades, %) en la misma fila de columnas.
        pct_real = real / plan * 100
        dentro = min(pct_real, 100)
        excedente = max(0.0, pct_real - 100)
        fig.add_trace(go.Bar(x=[100], y=[''], orientation='h', name=nombre_fondo, base=0, width=0.55,
                              marker_color='rgba(140,151,166,0.30)', hoverinfo='skip'))
        # COLOR_CADIZ (identidad, no semántica): esta barra "Real" en chart_bullet() siempre es de
        # CADIZ -- es el único equipo con Plan/Proyección cargado, así que Plan vs. Real acá nunca
        # compara a otro equipo (Adenda 25).
        fig.add_trace(go.Bar(x=[dentro], y=[''], orientation='h', name=nombre_frente, base=0, width=0.55,
                              marker_color=COLOR_CADIZ,
                              hovertemplate=f'{nombre_frente}: {_fmt_valor_cg(real, tipo)}<extra></extra>'))
        if excedente > 0:
            fig.add_trace(go.Bar(x=[excedente], y=[''], orientation='h', name='Excedente sobre el plan',
                                  base=100, width=0.55, marker_color=color_excedente,
                                  hovertemplate=f'Excedente: +{pct_real - 100:,.1f} p.p. sobre el plan<extra></extra>'))
        # BUG REPORTADO Y CONFIRMADO (Playwright, caso real "Punto de Equilibrio" con Ronda 1 de
        # CADIZ, donde Real = 302.8% del plan): la pista de referencia (nombre_fondo, gris muy claro)
        # queda TOTALMENTE tapada en cuanto dentro llega a 100 -- porque barmode='overlay' dibuja la
        # barra de "Real" exactamente encima, mismo ancho y misma fila. El resultado: solo se ven los
        # colores de "Real" y "Excedente", la referencia desaparece del todo salvo por su nombre en la
        # leyenda -- que es justo el reporte del equipo ("el punto de equilibrio no se ve"). La línea
        # punteada de acá abajo YA marcaba el 100% pero sin ninguna etiqueta -- ahora lleva el nombre
        # de la referencia (nombre_fondo) escrito directamente sobre el gráfico, así el dato clave
        # (dónde está el equilibrio) queda visible pase lo que pase con las barras de abajo.
        fig.add_vline(x=100, line_dash='dot', line_width=1.5, line_color=color_ref,
                      annotation_text=nombre_fondo, annotation_position='top',
                      annotation_font_size=11, annotation_font_color=color_ref)
        fig.update_layout(barmode='overlay', title=titulo, xaxis_title=None,
                           xaxis=dict(ticksuffix='%', range=[0, max(100, pct_real) * 1.15]),
                           legend=dict(orientation='h', yanchor='top', y=-0.25, xanchor='center', x=0.5))
        mostrar(fig, ocultar_eje_valores='y')
        cumplimiento = f' ({pct_real:,.1f}% del plan)'
    else:
        # Proyectado <= 0: expresarlo como % del plan no tiene sentido (división por ~0) -- se cae a
        # una barra simple en valor absoluto, sin pista de referencia, y se avisa en el caption.
        fig.add_trace(go.Bar(x=[real], y=[''], orientation='h', name=nombre_frente, marker_color=COLOR_CADIZ, width=0.55))
        fig.update_layout(title=titulo, xaxis_title=None, showlegend=False)
        mostrar(fig, ocultar_eje_valores='y')
        cumplimiento = ' — Proyectado ≤ 0, no expresable como % de avance'
    st.caption(f'{nombre_fondo}: {_fmt_valor_cg(plan, tipo)} · {nombre_frente}: {_fmt_valor_cg(real, tipo)}{cumplimiento}')

def chart_bullet_panel(items):
    """Adenda 23 (a pedido del equipo): versión COMPACTA de chart_bullet() para cuando hay VARIOS
    KPIs para comparar Plan vs. Real a la vez (ej. la Fila 2 de 'Comparativa Plan vs. Real' de
    Finanzas -- EBITDA, Margen bruto, ROS, etc.). Antes cada KPI dibujaba su PROPIO chart_bullet()
    en una grilla de columnas -- con 8 KPIs eso son 2 filas de gráficos de altura completa, mucho
    espacio vertical para escanear poco. Acá es UN solo gráfico con una fila horizontal por KPI
    (mismo lenguaje visual: pista de Plan normalizada a 100%, relleno de Real, excedente apilado si
    se pasa), todas comparten el mismo eje X (% del Plan) y se leen de arriba hacia abajo.

    `items`: lista de dicts {'label', 'plan', 'real', 'tipo', 'color_excedente'} en el orden en que
    deben listarse (de arriba hacia abajo). Los que tienen Plan<=0 (no expresable como % de avance,
    ver chart_bullet) se devuelven aparte para que el llamador los grafique con chart_bullet() normal
    -- son la excepción, no vale la pena forzarlos al panel compacto."""
    validos = [it for it in items if it.get('plan') not in (None, 0) and it['plan'] > 0 and it.get('real') is not None]
    if not validos:
        return
    color_ref = 'rgba(255,255,255,0.5)' if es_modo_oscuro() else 'rgba(26,23,20,0.5)'
    fig = go.Figure()
    max_pct = 100.0
    filas = [it['label'] for it in validos]
    for i, it in enumerate(validos):
        plan, real, tipo = float(it['plan']), float(it['real']), it['tipo']
        pct = real / plan * 100
        max_pct = max(max_pct, pct)
        dentro = min(pct, 100)
        excedente = max(0.0, pct - 100)
        color_exc = it.get('color_excedente') or COLOR_METRICA['riesgo']
        fig.add_trace(go.Bar(x=[100], y=[it['label']], orientation='h', base=0, width=0.55,
                              name='Plan (100%)', marker_color='rgba(140,151,166,0.30)',
                              showlegend=(i == 0), hoverinfo='skip'))
        fig.add_trace(go.Bar(x=[dentro], y=[it['label']], orientation='h', base=0, width=0.55,
                              name='Real', marker_color=COLOR_CADIZ, showlegend=(i == 0),
                              hovertemplate=f"Real: {_fmt_valor_cg(real, tipo)} ({pct:,.0f}% del plan)<extra></extra>"))
        if excedente > 0:
            fig.add_trace(go.Bar(x=[excedente], y=[it['label']], orientation='h', base=100, width=0.55,
                                  name='Excedente sobre el plan', marker_color=color_exc, showlegend=(i == 0),
                                  hovertemplate=f'Excedente: +{pct - 100:,.1f} p.p. sobre el plan<extra></extra>'))
        fig.add_annotation(x=max(pct, 100) + max_pct * 0.03, y=it['label'], xanchor='left', showarrow=False,
                            text=f"{_fmt_valor_cg(real, tipo)} · {pct:,.0f}%", font=dict(size=10, color=color_ref))
    fig.add_vline(x=100, line_dash='dot', line_width=1.5, line_color=color_ref,
                  annotation_text='Plan', annotation_position='top',
                  annotation_font_size=11, annotation_font_color=color_ref)
    # Adenda 24 -- BUG REPORTADO Y CONFIRMADO (leyenda y anotaciones superpuestas a las barras, con
    # apenas 1-2 filas): el alto total se calculaba SIN separar "área de ploteo" de "margen para la
    # leyenda" -- mostrar() reserva un margen inferior FIJO (110px, ver esa función) para la leyenda,
    # pero con pocas filas el 'altura' de acá (70+36xn) apenas superaba ese margen fijo, dejando un
    # área de ploteo casi nula. Como la posición de la leyenda (fig.layout.legend.y) es una FRACCIÓN
    # del área de ploteo (no de la figura completa), un área de ploteo de pocos píxeles convertía
    # cualquier offset negativo en apenas 1-2 píxeles reales -- la leyenda terminaba pegada al eje X,
    # justo encima de las barras y las anotaciones de valor. Ahora se separan explícitamente: un área
    # de ploteo mínima garantizada (para que las filas no queden apretadas) + un margen inferior propio
    # (en vez del fijo de mostrar()) dimensionado para la leyenda, y la posición de la leyenda se
    # calcula en función del área de ploteo real (no de un % arbitrario) para que caiga siempre dentro
    # de ese margen, sea cual sea la cantidad de filas.
    n = len(validos)
    plot_alto = max(120, 34 * n)              # área de ploteo: nunca menos de 120px, aunque haya 1 fila
    margen_b = 70                              # espacio fijo para la leyenda horizontal de abajo
    altura = min(620, 45 + margen_b + plot_alto)
    y_leyenda = -34 / plot_alto                # ~34px por debajo del eje X, constante en píxeles
    fig.update_layout(barmode='overlay', title='Proyectado vs. Real',
                       xaxis=dict(ticksuffix='%', range=[0, max_pct * 1.4]), xaxis_title=None,
                       yaxis=dict(categoryorder='array', categoryarray=list(reversed(filas))),
                       legend=dict(orientation='h', yanchor='top', y=y_leyenda, xanchor='center', x=0.5))
    mostrar(fig, altura=altura, margen_b=margen_b)

# --- COMPARATIVA PLAN VS. REAL: Proyectado (ULTI_Gestion_v2.xlsx, vía export_proyeccion.py) vs.
# Real (RDOS de CESIM, ya parseados más arriba por cesim_parser) ---
def _fmt_valor_cg(v, tipo):
    if v is None:
        return '—'
    if tipo == 'usd':
        return format_num(v)
    if tipo == 'unidades':
        return f'{format_num(v)} u.'
    if tipo == 'usd_accion':
        return f'USD {v:,.2f}'
    if tipo == 'ratio':
        return f'{v * 100:,.1f}%'
    return str(v)
def _fmt_delta_cg(v):
    if v['estado'] != 'ok' or v['gap_abs'] is None:
        return None
    if v['tipo'] == 'usd':
        # Ronda con status=REAL en ambos lados (histórico ya migrado) da un gap de centavos por
        # redondeo de punto flotante entre el motor Python y el motor Excel -- no es un gap real y
        # mostrarlo como "-0" confundiría; se redondea al dólar y se omite si queda en 0.
        gap_redondeado = round(v['gap_abs'])
        return format_num(gap_redondeado) if gap_redondeado != 0 else None
    if v['tipo'] == 'unidades':
        gap_redondeado = round(v['gap_abs'])
        return f'{gap_redondeado:+,.0f} u.' if gap_redondeado != 0 else None
    if v['tipo'] == 'usd_accion':
        return f"{v['gap_abs']:+,.2f}"
    if v['tipo'] == 'ratio':
        return f"{v['gap_abs'] * 100:+.1f} p.p."
    return None
_DELTA_COLOR_CG = {'real_mayor': 'normal', 'real_menor': 'inverse', None: 'off'}
# Mismo mapeo de favorabilidad que _DELTA_COLOR_CG, pero como color de relleno para el segmento de
# excedente de chart_bullet(): si más Real es mejor (real_mayor), pasarse del plan es favorable
# (verde). Para 'real_menor' (ej. deuda no planificada) se probó primero con COLOR_NEGATIVE (rojo) para
# marcarlo como desfavorable, pero el relleno "Real" del propio bullet ya usa un color fijo (COLOR_CADIZ) --
# el segmento de excedente quedaba muy parecido, poco distinguible (ver test visual). Ámbar neutro
# funciona para ambos casos sin esa colisión: sigue leyéndose como "atención, se pasó de la
# referencia" sea o no favorable (la flecha de color del delta, un renglón más arriba, ya dice si eso
# es bueno o malo).
_COLOR_EXCEDENTE_CG = {'real_mayor': COLOR_POSITIVE, 'real_menor': COLOR_METRICA['riesgo'], None: COLOR_METRICA['riesgo']}
def panel_comparativa_plan_real(df_todas_rondas, ronda_snapshot, crosswalk=None, key_suffix='', mostrar_directo=False, mostrar_metricas=True, mostrar_extras=True):
    """Botón 'Comparativa Plan vs. Real': Proyectado (nuestro modelo) vs. Real (RDOS de CESIM) para los
    KPIs del crosswalk dado. Un KPI sin proyección para esta ronda (el modelo no lo cubre, o es una
    ronda de Práctica que el modelo no proyecta) o sin dato real todavía (CESIM no publicó esta
    ronda) no se omite en silencio: cae al gráfico de evolución de esa variable.

    mostrar_directo=True se salta el toggle y renderiza directo -- para cuando esta es la ÚNICA
    razón de estar en la página (p.ej. CESIM todavía no publicó ningún RDOS de esta ronda: no hay
    nada más que mostrar en el resto de las secciones, así que no tiene sentido esconder esto detrás
    de un clic extra).

    mostrar_metricas=False (Adenda 26, a pedido del equipo solo para Finanzas: "dejar como elemento
    protagonista exclusivo el panel de barras horizontales apiladas") -- oculta la Fila 1 de tarjetas
    st.metric (Proyectado/Real por KPI) y deja directo el panel compacto de barras (chart_bullet_panel).

    mostrar_extras=False (Adenda 27, mismo pedido pero llevado más lejos: "eliminar todo esos
    gráficos de comparativa vs real en finanzas, solo nos quedamos con la de comparativa vs real de
    barras horizontales") -- además de lo anterior, oculta el chart_bullet() suelto que se grafica
    aparte para los KPIs con Plan<=0 (ej. "Deuda CP no planificada") y todo el bloque de abajo (los
    gráficos de evolución de KPIs sin gap posible, ej. "Evolución — Margen bruto", y su caption). Deja
    ÚNICAMENTE el panel chart_bullet_panel ("Proyectado vs. Real") como elemento en pantalla.

    Ambos parámetros solo se pasaron en False desde el llamado de Finanzas: Resultados/Mercado/
    Operaciones siguen mostrando todo como antes -- no se tocó su comportamiento porque no fue lo que
    pidió el equipo (si se quiere el mismo cambio ahí, avisar)."""
    crosswalk = crosswalk or CROSSWALK_FINANZAS
    if not mostrar_directo:
        activo = st.toggle('📊 Comparativa Plan vs. Real', key=f'cg_toggle_{key_suffix}')
        if not activo:
            return
    ronda_num = ronda_a_num(ronda_snapshot)
    df_proy = get_proyeccion(ronda_num)
    if df_proy is None:
        st.info('Todavía no hay ningún `Ulti_proyeccion_R{N}.xlsx` en `data/decisiones/` (o no se '
                'pudo leer la hoja `DATA_EXPORT`) — generalo con el botón "Generar Excel de gestión" '
                'de la sidebar y commiteá el resultado en esa carpeta para ver la Comparativa Plan vs. Real.')
        return
    claves_no_publicadas = {k for k, spec in crosswalk.items() if spec.get('real_no_publicado')}
    gaps_todos = calcular_gaps(df_todas_rondas, df_proy, ronda_nombre=ronda_snapshot, ronda_num=ronda_num, crosswalk=crosswalk)
    gaps = {k: v for k, v in gaps_todos.items() if k not in claves_no_publicadas}
    sin_publicar = {k: v for k, v in gaps_todos.items() if k in claves_no_publicadas}
    con_gap = {k: v for k, v in gaps.items() if v['estado'] in ('ok', 'sin_real')}
    sin_gap = {k: v for k, v in gaps.items() if v['estado'] in ('sin_datos', 'sin_proyeccion')}
    with st.container(border=True):
        st.markdown(f'**Comparativa Plan vs. Real — {ronda_snapshot}**')
        if not con_gap:
            st.caption('ULTI no tiene una proyección cargada para este año en el modelo de gestión — '
                       'ver la evolución de cada indicador más abajo.')
        else:
            if mostrar_metricas:
                cols = st.columns(min(4, len(con_gap)))
                for i, (clave, v) in enumerate(con_gap.items()):
                    with cols[i % len(cols)]:
                        if v['estado'] == 'sin_real':
                            st.metric(v['label'], _fmt_valor_cg(v['proyectado'], v['tipo']))
                            st.caption('Proyectado (ULTI) — real de CESIM pendiente')
                        else:
                            st.metric(v['label'], _fmt_valor_cg(v['real'], v['tipo']),
                                       delta=_fmt_delta_cg(v), delta_color=_DELTA_COLOR_CG[v['gap_favorable']])
                            st.caption(f"Real — proyectado {_fmt_valor_cg(v['proyectado'], v['tipo'])}")
            # Fila 2: bullet charts (Proyectado vs. Real superpuestos) -- solo para los KPIs que
            # tienen AMBOS valores (estado='ok'); 'sin_real' ya se ve en la tarjeta de arriba, no hay
            # nada que superponer todavía.
            # tipo='texto' (ej. Calificación crediticia) no tiene sentido como barra -- ya se ve
            # completo en la tarjeta de Fila 1 (valor + "Real — proyectado ...").
            con_ambos = {k: v for k, v in con_gap.items() if v['estado'] == 'ok' and v['tipo'] != 'texto'}
            if con_ambos:
                st.markdown('###### Proyectado vs. Real')
                # Adenda 23 (a pedido del equipo, storytelling de Finanzas): panel COMPACTO de una
                # sola figura con una fila horizontal por KPI, en vez de un chart_bullet() por
                # columna -- mucho menos alto para escanear varios KPIs (EBITDA, ROS, etc.) de
                # arriba hacia abajo. Mismo criterio de favorabilidad que ya colorea la flecha del
                # delta de la tarjeta de arriba (_DELTA_COLOR_CG), pasado como color del excedente.
                items_panel = [
                    {'label': v['label'], 'plan': v['proyectado'], 'real': v['real'], 'tipo': v['tipo'],
                     'color_excedente': _COLOR_EXCEDENTE_CG.get(v['gap_favorable'])}
                    for v in con_ambos.values()
                ]
                chart_bullet_panel(items_panel)
                # Plan<=0 no es expresable como % de avance (ver chart_bullet) -- caso raro, se
                # grafica aparte con el chart_bullet() de siempre en vez de forzarlo al panel.
                # Adenda 27: mostrar_extras=False (Finanzas) lo saca -- el equipo pidió dejar SOLO
                # el panel de barras de arriba, sin excepciones sueltas.
                if mostrar_extras:
                    for clave, v in con_ambos.items():
                        if v['proyectado'] is not None and v['proyectado'] <= 0:
                            chart_bullet(v['label'], v['proyectado'], v['real'], v['tipo'],
                                         color_excedente=_COLOR_EXCEDENTE_CG.get(v['gap_favorable']))
        # Adenda 27: mostrar_extras=False (Finanzas) saca también todo este bloque de abajo (los
        # gráficos de evolución de KPIs sin gap posible + su caption) -- mismo pedido de "dejar solo
        # la de barras horizontales".
        if mostrar_extras and (sin_gap or sin_publicar):
            st.caption('Sin comparación posible para estos indicadores (no forman parte de la '
                       'proyección de ULTI, es un año de práctica, o CESIM no publica ese dato en '
                       'el RDOS) — se muestra su evolución:')
    if mostrar_extras and (sin_gap or sin_publicar):
        total = len(sin_gap) + len(sin_publicar)
        cols_ev = st.columns(min(2, total))
        i = 0
        for clave, v in sin_gap.items():
            spec = crosswalk[clave]['real']
            sub = df_todas_rondas[(df_todas_rondas['Estado'] == spec['estado']) & (df_todas_rondas['Metrica'] == spec['metrica'])]
            if spec.get('seccion'):
                sub = sub[sub['Seccion'] == spec['seccion']]
            with cols_ev[i % len(cols_ev)]:
                chart_evolucion(sub, v['label'])
            i += 1
        for clave, v in sin_publicar.items():
            spec = crosswalk[clave]['proyeccion']
            with cols_ev[i % len(cols_ev)]:
                chart_evolucion_proyeccion(df_proy, spec['metric'], spec['region'], v['label'])
                st.caption('CESIM no publica este dato en el RDOS — evolución de la proyección propia de ULTI.')
            i += 1

# --- Fila 3 de la Comparativa Plan vs. Real: gráficos de GAP/varianza específicos por sección
# (Adenda 12). Cada uno se llama desde la pestaña "Comparativa Plan vs. Real" de su propia sección
# (no desde panel_comparativa_plan_real, que es genérico y no conoce estas métricas de grano fino
# por mercado/tecnología/área) -- y solo tiene sentido con team=CADIZ (son cruces contra SU propia
# proyección en ULTI_Gestion_v2.xlsx). ---
def fila_cg_demanda_estimada(df_all, ronda_snapshot, ronda_num, df_proy, mercado_sel):
    """Adenda 30 (a pedido del equipo, Nivel 2 de Control de Gestión): desvío PURO de pronóstico de
    demanda -- Demanda Estimada por ULTI (D1c·DEMANDA, al planificar) vs. Demanda Real (RDOS), por
    tecnología, ANTES del corte de Ventas efectivas (que ya depende de disponibilidad/capacidad, no
    solo del pronóstico -- eso se ve aparte más abajo, en el waterfall de Ingresos). Barras agrupadas
    (mismo lenguaje visual que fila3_mercado_cuota_objetivo, para no introducir un tercer estilo de
    gráfico en la misma pantalla).
    Adenda 33 (consolidación de selectores, a pedido del equipo): 'mercado_sel' ya NO se elige acá --
    lo elige un único st.selectbox('Mercado', ...) al inicio del Nivel 2 en seccion_control_gestion(),
    y se pasa como parámetro a esta función y a las otras dos filas del nivel (cuota, ingresos), para
    que las tres lean siempre el mismo mercado sin selectores redundantes."""
    st.markdown('###### Desvío de Pronóstico — Demanda Estimada vs. Demanda Real')
    st.caption('Antes del corte de Ventas efectivas: acá se ve si ULTI estimó bien cuánto le iba a '
               'demandar el mercado, más allá de si después pudo o no abastecer toda esa demanda '
               '(eso se ve en el desvío de Ingresos, más abajo).')
    datos = demanda_estimada_vs_real(df_all, df_proy, ronda_snapshot, ronda_num, mercado_sel, team=MY_COMPANY)
    if not datos:
        return st.info(f'Sin datos de demanda estimada/real en {mercado_sel} para {ronda_snapshot}.')
    if all(d['plan'] is None for d in datos.values()):
        return st.info(f'ULTI no tiene una demanda estimada cargada para {mercado_sel} en {ronda_snapshot} '
                        '— el modelo de gestión proyecta recién desde Año 2, no hay Plan con el que comparar.')
    filas = []
    for tech, d in datos.items():
        if d['plan'] is not None:
            filas.append({'Tecnología': tech, 'Tipo': 'Demanda Estimada', 'Unidades': d['plan']})
        if d['real'] is not None:
            filas.append({'Tecnología': tech, 'Tipo': 'Demanda Real', 'Unidades': d['real']})
    dfd = pd.DataFrame(filas)
    fig = px.bar(dfd, x='Tecnología', y='Unidades', color='Tipo', barmode='group',
                 color_discrete_map={'Demanda Estimada': MUTED_PALETTE[0], 'Demanda Real': COLOR_CADIZ},
                 text=dfd['Unidades'].apply(format_num), title=f'Demanda Estimada vs. Real — {mercado_sel}, {ronda_snapshot}')
    fig.update_traces(textposition='outside', cliponaxis=False)
    fig.update_layout(yaxis_title='Unidades')
    mostrar(fig)

def fila3_resultados_ingresos(df_all, ronda_snapshot, ronda_num, df_proy, mercado_sel):
    """Adenda 33 (consolidación de selectores): 'mercado_sel' viene del único selector de Nivel 2 en
    seccion_control_gestion() -- ver nota en fila_cg_demanda_estimada."""
    st.markdown('###### Análisis de Desvíos de Ingresos — Precio / Volumen / Mix')
    datos = precio_volumen_mercado(df_all, df_proy, ronda_snapshot, ronda_num, mercado_sel, team=MY_COMPANY)
    if not datos:
        st.info(f'ULTI no tiene datos de precio/volumen (Plan o Real) en {mercado_sel} para {ronda_snapshot}.')
        return
    if all(d['precio_plan'] is None for d in datos.values()):
        # Sin ESTO, el waterfall tomaría Plan=0 como línea base y le atribuiría el 100% de los
        # Ingresos Reales al "Desvío por Precio" -- un artefacto de la falta de dato, no un desvío
        # real. El modelo de CADIZ solo proyecta desde Ronda 2 (Ronda 0/1 no tienen Plan cargado).
        st.info(f'ULTI no tiene una proyección de Precio/Volumen cargada para {mercado_sel} en {ronda_snapshot} '
                '— el modelo de gestión proyecta recién desde Año 2, no hay Plan con el que comparar.')
        return
    var = variacion_precio_volumen_mix(datos)
    if not var['reconciliacion_ok']:
        st.warning('El desglose Precio/Volumen/Mix no reconcilia exactamente con la variación de Ingresos — revisar.')
    etapas = [('Ingresos Proyectados', var['ingresos_plan']), ('Desvío por Precio', var['var_precio']),
              ('Desvío por Volumen', var['var_volumen']), ('Desvío por Mix', var['var_mix']),
              ('Ingresos Reales', var['ingresos_real'])]
    fig = go.Figure(go.Waterfall(
        orientation='v', measure=['absolute', 'relative', 'relative', 'relative', 'total'],
        x=[e[0] for e in etapas], y=[e[1] for e in etapas],
        text=_texto_cascada([v for _, v in etapas]), textposition='outside',
        # Adenda 25 (a pedido del equipo): TODOS los gráficos en cascada de la app usan ahora la
        # misma convención universal -- verde = lo que suma (increasing), rojo = lo que resta
        # (decreasing) -- en vez de favorable/desfavorable por caso. Antes acá era verde/ámbar.
        increasing={'marker': {'color': COLOR_POSITIVE}}, decreasing={'marker': {'color': COLOR_NEGATIVE}},
        totals={'marker': {'color': COLOR_CADIZ}}))  # total = "Ingresos Reales" -- identidad CADIZ, no sentimiento
    fig.update_layout(title=f'Ingresos — Proyectado vs. Real, {mercado_sel} ({_MONEDA_MERCADO_GAP[mercado_sel]})')
    mostrar(fig, ocultar_eje_valores='y')
    st.caption(f'Verde = desvío que sumó Ingresos; rojo = desvío que restó. % entre paréntesis = sobre los Ingresos '
               f'Proyectados. En moneda nativa de {mercado_sel} ({_MONEDA_MERCADO_GAP[mercado_sel]}) — no se '
               'convierte a USD para no asumir un tipo de cambio que el simulador no publica.')

def fila3_mercado_cuota_objetivo(df_all, ronda_snapshot, ronda_num, df_proy, mercado_sel):
    """Adenda 33 (consolidación de selectores): 'mercado_sel' viene del único selector de Nivel 2 en
    seccion_control_gestion() -- ver nota en fila_cg_demanda_estimada."""
    st.markdown('###### Cuota de mercado — Proyectado vs. Real, por tecnología')
    datos = cuota_mercado_objetivo_vs_real(df_all, df_proy, ronda_snapshot, ronda_num, mercado_sel, team=MY_COMPANY)
    if not datos:
        st.info(f'Sin datos de cuota objetivo/real en {mercado_sel} para {ronda_snapshot}.')
        return
    filas = []
    for tech, d in datos.items():
        # "Proyectado" en todos lados (antes decía "Objetivo (Plan)" acá, distinto del resto de la
        # Comparativa) -- mismo término que chart_bullet, la Fila 1 de KPIs y las demás Filas 3.
        if d['objetivo'] is not None:
            filas.append({'Tecnología': tech, 'Tipo': 'Proyectado', 'Cuota': d['objetivo'] * 100})
        if d['real'] is not None:
            filas.append({'Tecnología': tech, 'Tipo': 'Real', 'Cuota': d['real'] * 100})
    if not filas:
        return st.info('Sin datos suficientes.')
    dfc = pd.DataFrame(filas)
    fig = px.bar(dfc, x='Tecnología', y='Cuota', color='Tipo', barmode='group',
                 color_discrete_map={'Proyectado': MUTED_PALETTE[0], 'Real': COLOR_CADIZ},
                 text=dfc['Cuota'].apply(lambda v: f'{v:.1f}%'), title=f'Cuota de mercado — {mercado_sel}, {ronda_snapshot}')
    fig.update_traces(textposition='outside', cliponaxis=False)
    fig.update_layout(yaxis_title='% del mercado total')
    mostrar(fig)
    st.caption('Cuota = ventas de ULTI en esa tecnología / tamaño TOTAL del mercado (las 4 tecnologías) — '
               'misma convención en Plan y Real (distinta de la que el RDOS publica directo por tecnología, '
               'ver nota metodológica en gap_analysis.cuota_mercado_objetivo_vs_real). '
               'Ojo con leerla junto al gráfico de "Demanda estimada" de más arriba: el Proyectado de ESTA '
               'cuota se calculó contra el tamaño de mercado que el modelo había asumido al planificar; el '
               'Real se calcula contra el tamaño que terminó publicando CESIM. Si la demanda real vino más '
               'chica que la proyectada, la cuota puede salir MÁS ALTA que el objetivo aunque el volumen '
               'propio en unidades haya sido menor al planeado — no es una contradicción entre los dos '
               'gráficos, es la misma torta más chica repartida distinto.')

def _costo_fabricacion_ponderado(datos_area):
    """A partir de costo_unitario_area(): costo unitario de fabricación PONDERADO por producción REAL
    (propia + contratada), Plan vs. Real, y el GAP que aporta cada tecnología al total — usa los
    MISMOS pesos (producción real) para ponderar Plan y Real, así el desglose por tecnología
    reconcilia EXACTO con la diferencia total (no es una aproximación)."""
    filas = []
    prod_total = 0.0
    for tech, d in datos_area.items():
        prod_p, prod_t = d['prod_propia_real'], d['prod_terc_real']
        prod_tech = prod_p + prod_t
        if prod_tech <= 0:
            continue
        plan_tech = ((d['cu_propia_plan'] or 0) * prod_p + (d['cu_terc_plan'] or 0) * prod_t) / prod_tech
        real_tech = ((d['cu_propia_real'] or 0) * prod_p + (d['cu_terc_real'] or 0) * prod_t) / prod_tech
        filas.append({'tech': tech, 'prod': prod_tech, 'plan': plan_tech, 'real': real_tech})
        prod_total += prod_tech
    if prod_total <= 0:
        return None
    plan_pond = sum(f['prod'] * f['plan'] for f in filas) / prod_total
    real_pond = sum(f['prod'] * f['real'] for f in filas) / prod_total
    gaps = [{'tech': f['tech'], 'gap': (f['real'] - f['plan']) * f['prod'] / prod_total} for f in filas]
    return {'plan_pond': plan_pond, 'real_pond': real_pond, 'gaps': gaps}

def fila3_operaciones_gap_fabricacion(df_all, ronda_snapshot, ronda_num, df_proy, area_sel):
    """Adenda 33 (consolidación de selectores, a pedido del equipo): 'area_sel' ya NO se elige acá --
    lo elige un único st.selectbox('Área de producción', ...) en la cabecera del Nivel 3 en
    seccion_control_gestion(), y se pasa como parámetro (hoy Nivel 3 tiene una sola fila, pero se deja
    así para no reintroducir un selector propio si se agrega otra métrica al nivel más adelante)."""
    st.markdown('###### Desvío en Costo Unitario de Fabricación (Proyectado vs. Real)')
    st.caption('Alcance: solo costo de FABRICACIÓN (propia + contratada), ponderado por producción real. '
               'Transporte/aranceles y promoción se reportan por mercado de destino (no por área de origen) '
               'y no están incluidos acá — por eso este desvío no reconcilia el 100% de la Contribución '
               'Marginal unitaria completa.')
    datos = costo_unitario_area(df_all, df_proy, ronda_snapshot, ronda_num, area_sel, team=MY_COMPANY)
    if not datos:
        return st.info(f'Sin datos de costo unitario de fabricación en {area_sel} para {ronda_snapshot}.')
    if all(d['cu_propia_plan'] is None and d['cu_terc_plan'] is None for d in datos.values()):
        # Mismo motivo que en el waterfall de Ingresos: sin esto, Proyectado=0 le atribuiría el 100%
        # del costo real a un "Desvío" que en realidad es solo ausencia de proyección (Ronda 0/1,
        # antes de que el modelo de CADIZ empezara a proyectar en Ronda 2).
        return st.info(f'ULTI no tiene una proyección de costo unitario cargada para {area_sel} en {ronda_snapshot} '
                        '— el modelo de gestión proyecta recién desde Año 2, no hay Plan con el que comparar.')
    pond = _costo_fabricacion_ponderado(datos)
    if not pond:
        return st.info(f'Sin datos de producción real en {area_sel} para {ronda_snapshot}.')
    # "Desvío {tecnología}" (antes "GAP {tecnología}", en inglés y sin explicar qué significa): cuánto
    # empujó ESA tecnología al costo unitario PONDERADO total, de Proyectado a Real -- no es "cuánto le
    # costó de más esa tecnología en el vacío", es su aporte a la diferencia total, ponderado por su
    # propia producción real. La suma de todos los "Desvío X" + Costo Proyectado da EXACTO el Costo
    # Real (reconciliación por construcción, ver _costo_fabricacion_ponderado) -- por eso tiene sentido
    # como cascada/waterfall y no como barras sueltas.
    etapas = [('Costo Proyectado', pond['plan_pond'])]
    for g in pond['gaps']:
        if abs(g['gap']) > 1e-9:
            etapas.append((f"Desvío {g['tech']}", g['gap']))
    etapas.append(('Costo Real', pond['real_pond']))
    fig = go.Figure(go.Waterfall(
        orientation='v', measure=['absolute'] + ['relative'] * (len(etapas) - 2) + ['total'],
        x=[e[0] for e in etapas], y=[e[1] for e in etapas],
        text=_texto_cascada([v for _, v in etapas]), textposition='outside',
        # EXCEPCIÓN explícita a la convención universal de la Adenda 25 (a pedido del equipo,
        # confirmado -- ver conversación): para ESTE waterfall puntual (y solo este) se vuelve a
        # favorable/desfavorable para CADIZ, no "suma/resta" genérico. Motivo: acá lo que "suma"
        # (increasing) es un desvío que AUMENTA el costo unitario de fabricación -- eso es malo
        # para CADIZ, así que va en ROJO; lo que "resta" (decreasing) es un desvío que lo REDUCE --
        # bueno para CADIZ, va en VERDE. El resto de los waterfalls de la app (Ingresos, Flujo de
        # Caja, etc.) sigue con la convención universal verde=suma/rojo=resta sin cambios.
        increasing={'marker': {'color': COLOR_NEGATIVE}}, decreasing={'marker': {'color': COLOR_POSITIVE}},
        totals={'marker': {'color': COLOR_CADIZ}}))  # total = "Costo Real" -- identidad CADIZ, no sentimiento
    fig.update_layout(title=f'Costo unitario de fabricación — {area_sel}, {ronda_snapshot}')
    mostrar(fig, ocultar_eje_valores='y')
    st.caption('Cada barra "Desvío {tecnología}" es cuánto empujó esa tecnología el costo unitario ponderado '
               'total, de Proyectado a Real (ponderado por su propia producción real) — no el costo de esa '
               'tecnología en sí. Rojo = aumenta el costo (desfavorable para ULTI); verde = lo reduce '
               '(favorable) — única excepción a la convención de color del resto de la app (ver otros '
               'waterfalls), porque acá "suma/resta" y "favorable/desfavorable" van en sentido contrario. '
               '% entre paréntesis = sobre el Costo Proyectado. Costo Proyectado + todos los desvíos = Costo '
               'Real, exacto.')

def fila3_finanzas_flujo_caja(df_all, ronda_snapshot, ronda_num, df_proy):
    # Adenda 23 (a pedido del equipo): reemplaza las barras agrupadas (Proyectado vs. Real, un grupo
    # de barras por componente) por un puente/Cascada (Waterfall) que cuenta la historia de cómo se
    # llega de CFO a CFI a CFF hasta la Variación Neta de Caja de la ronda -- una Cascada por
    # Proyectado y otra por Real, para poder seguir mirando ambas lado a lado.
    st.markdown('###### Composición del Flujo de Caja — Puente CFO → CFI → CFF (Global)')
    res = flujo_caja_plan_real_global(df_all, df_proy, ronda_snapshot, ronda_num, team=MY_COMPANY)
    plan, real = res['plan'], res['real']

    def _waterfall_flujo(titulo, valores):
        if all(valores.get(k) is None for k in ('cfo', 'cfi', 'cff')):
            return False
        cfo, cfi, cff = valores.get('cfo') or 0.0, valores.get('cfi') or 0.0, valores.get('cff') or 0.0
        total = cfo + cfi + cff
        etapas = [('CFO', cfo), ('CFI', cfi), ('CFF', cff), ('= Variación Neta de Caja', total)]
        fig = go.Figure(go.Waterfall(
            orientation='v', measure=['relative', 'relative', 'relative', 'total'],
            x=[e[0] for e in etapas], y=[v for _, v in etapas],
            text=_texto_cascada([v for _, v in etapas], base=cfo if cfo not in (0, None) else None), textposition='outside',
            # Adenda 25: convención universal de color de la app -- verde = suma (increasing),
            # rojo = resta (decreasing), en todos los waterfalls, sin excepción por favorable/
            # desfavorable. Antes decreasing usaba COLOR_METRICA['riesgo'] (ámbar).
            increasing={'marker': {'color': COLOR_POSITIVE}}, decreasing={'marker': {'color': COLOR_NEGATIVE}},
            totals={'marker': {'color': COLOR_POSITIVE if total >= 0 else COLOR_NEGATIVE}}))
        fig.update_layout(title=titulo)
        mostrar(fig, ocultar_eje_valores='y')
        return True

    col_p, col_r = st.columns(2)
    with col_p:
        if not _waterfall_flujo(f'Proyectado — {ronda_snapshot}', plan):
            st.info('ULTI no proyecta Flujo de Caja para este año en el modelo de gestión (recién desde Año 2).')
    with col_r:
        if not _waterfall_flujo(f'Real — {ronda_snapshot}', real):
            st.info('CESIM todavía no publicó el RDOS real de este año.')
    st.caption('Cada barra es cuánta caja aportó o consumió ese bloque de actividades (Operativas / Inversión / '
               'Financieras) hasta llegar a la Variación Neta de Caja del año — no es el saldo de caja del '
               'Balance, es el cambio de este año puntual.')

def serie_metrica(estado, metrica, empresa=None, hasta_orden=None, seccion=None):
    """Serie histórica de una métrica para un equipo, ordenada por ronda.
    OJO con 'seccion': hay métricas cuyo nombre se repite dentro del mismo estado
    (ej. 'Total' aparece en Accionistas, Acreedores, Gobierno, Personal y Proveedores
    dentro de Creación de Valor). Sin filtrar por sección se mezclan cinco series distintas."""
    d = df_all[(df_all['Estado'] == estado) & (df_all['Metrica'] == metrica)].copy()
    if seccion: d = d[d['Seccion'] == seccion]
    if empresa: d = d[d['Empresa'] == empresa]
    if d.empty: return []
    d['Valor'] = num(d['Valor'])
    if hasta_orden is not None:
        d = d[d['Ronda_Orden'] <= hasta_orden]
    return d.sort_values('Ronda_Orden')['Valor'].tolist()

def ronda_anterior_de(ronda):
    """Adenda 24 -- helper genérico para el patrón 'variación vs. ronda anterior' que ya usaba
    _seccion_resultado_resumen() de forma manual (ver más abajo) -- se extrae acá para reusarlo en
    todos los KPIs del tablero que necesiten ese delta, sin repetir la lógica de Ronda_Orden en cada
    lugar. Devuelve el NOMBRE de la ronda anterior (ej. 'Ronda 1'), o None si `ronda` es la primera
    ronda disponible en los datos cargados (no hay anterior con la cual comparar)."""
    ordenes = sorted(df['Ronda_Orden'].dropna().unique())
    sub_act = df[df['Ronda'] == ronda]['Ronda_Orden']
    if sub_act.empty or sub_act.iloc[0] not in ordenes:
        return None
    idx = ordenes.index(sub_act.iloc[0])
    if idx == 0:
        return None
    sub_prev = df[df['Ronda_Orden'] == ordenes[idx - 1]]['Ronda']
    return sub_prev.iloc[0] if not sub_prev.empty else None

def delta_vs_ronda_anterior(estado, metrica, empresa=None, ronda_actual=None, seccion=None):
    """Adenda 25 -- delta % de una métrica para `empresa` entre `ronda_actual` (default:
    ronda_snapshot) y la ronda INMEDIATAMENTE ANTERIOR (vía ronda_anterior_de) -- generaliza el
    patrón 'vs. ronda anterior' para poder pedirlo de cualquier Estado/Métrica, igual que delta_raw
    (definido dentro de cada sección) generaliza 'vs. promedio de industria'. None si no hay ronda
    anterior en los datos cargados, o si falta el dato en cualquiera de las dos rondas.
    Devuelve (delta_pct, ronda_prev) -- se necesita el nombre de la ronda anterior para el texto
    ('vs Ronda 1'), así que se devuelve junto con el número en vez de forzar un segundo llamado a
    ronda_anterior_de()."""
    ronda_actual = ronda_actual or ronda_snapshot
    empresa = empresa or empresa_analisis
    ronda_prev = ronda_anterior_de(ronda_actual)
    if not ronda_prev:
        return None, None
    d_act = df[(df['Estado'] == estado) & (df['Ronda'] == ronda_actual)]
    d_prev = df[(df['Estado'] == estado) & (df['Ronda'] == ronda_prev)]
    if seccion:
        d_act = d_act[d_act['Seccion'] == seccion]
        d_prev = d_prev[d_prev['Seccion'] == seccion]
    val_act, val_prev = valor_de(d_act, metrica, empresa), valor_de(d_prev, metrica, empresa)
    if val_act is None or val_prev is None or pd.isna(val_act) or pd.isna(val_prev) or val_prev == 0:
        return None, ronda_prev
    return (val_act - val_prev) / abs(val_prev) * 100, ronda_prev

def kpi_con_tendencia(col, label, valor_txt, serie, delta=None, color=None, invertir=False):
    """Tarjeta de KPI + sparkline debajo, para ver nivel y tendencia sin cambiar de sección."""
    with col:
        st.metric(label, valor_txt, delta=delta)
        fig = sparkline(serie, color=color, invertir=invertir)
        if fig is not None:
            st.plotly_chart(fig, use_container_width=True, config={'displayModeBar': False})

def _icono_delta(texto):
    """Adenda 25: ícono 🔺/🔻 según el signo LITERAL del texto de delta (ya formateado con signo,
    ej. '+4.3% vs Prom' / '-2.0% vs Ronda 1') -- el color (verde/rojo) sigue viniendo de
    'favorable', que puede estar invertido para métricas donde bajar es bueno (Deuda, costos).
    Así un delta de Deuda que BAJA se ve con 🔻 (bajó, literal) pero en VERDE (es favorable)."""
    t = texto.strip()
    if t.startswith('+'): return '🔺 '
    if t.startswith('-') or t.startswith('−'): return '🔻 '
    return ''

def kpi_banda_oscura(items):
    """Banda oscura para los 2-3 KPIs de valor MÁS importantes de la ronda (los que le interesan
    a un accionista) -- los separa visualmente del resto de tarjetas claras en vez de competir al
    mismo nivel, estilo el bloque "Monto Pendiente / A vencer / Ya pagado" de la referencia. Es
    HTML de una sola pieza (no columnas + st.metric) porque no hay forma segura de "abrir" un div
    oscuro con un st.markdown y "cerrarlo" varios st.* después -- cada items[i] es un dict con
    'label', 'valor' (ya formateado) y opcionalmente 'delta' (texto) + 'favorable' (True/False/None
    para pintar el delta verde/rojo; None lo deja neutro).
    Adenda 25 (a pedido del equipo: "no quiero ver solamente la variación vs el promedio, que quede
    la variación con ronda anterior también, en todos los casos"): cada item admite además 'delta2'
    + 'favorable2' para una SEGUNDA línea de delta -- por convención delta = vs. Ronda Anterior,
    delta2 = vs. Promedio Industria (o al revés, según arme el caller; esta función no asume cuál es
    cuál, solo las apila en el orden en que llegan)."""
    piezas = []
    for it in items:
        delta_html = ''
        for clave_delta, clave_fav in (('delta', 'favorable'), ('delta2', 'favorable2')):
            if not it.get(clave_delta):
                continue
            # OJO: "favorable" suele venir de comparar floats de pandas/numpy (ej. delta > 0), que da
            # numpy.bool_ -- "is False" falla por identidad contra ese tipo aunque el valor sea
            # correcto (numpy.bool_(False) is False → False). Sin comparación de identidad.
            fav = it.get(clave_fav)
            clase = '' if fav is None else ('up' if fav else 'down')
            delta_html += f'<div class="kpi-band-delta {clase}">{_icono_delta(it[clave_delta])}{it[clave_delta]}</div>'
        piezas.append(f'<div class="kpi-band-item"><div class="kpi-band-label">{it["label"]}</div>'
                       f'<div class="kpi-band-value">{it["valor"]}</div>{delta_html}</div>')
    # En modo oscuro nativo de Streamlit la banda necesita distinguirse por color, no por
    # oscuridad -- ver el comentario junto a ".kpi-band-oscura.tema-oscuro" en style.css.
    clase_tema = ' tema-oscuro' if es_modo_oscuro() else ''
    st.markdown(f'<div class="kpi-band-oscura{clase_tema}">{"".join(piezas)}</div>', unsafe_allow_html=True)

def kpi_doble_delta(col, label, valor_txt, d_ronda=None, ronda_prev_nombre=None, favorable_ronda=None,
                     d_industria=None, favorable_industria=None, unidad='%'):
    """Adenda 25 (a pedido del equipo -- reemplaza st.metric(..., delta=...) en las tarjetas de KPI
    'claras' que antes mostraban un solo delta, 'X% vs Prom'): tarjeta con DOS deltas apilados, vs.
    Ronda Anterior y vs. Promedio Industria, siempre los dos que haya dato. st.metric no soporta dos
    deltas nativos, así que se arma en HTML -- el bloque '.kpi-card-doble' en style.css calca el
    estilo de las cards st.metric nativas (mismo borde lila, fondo y sombra) para que conviva sin
    desentonar al lado de tarjetas que todavía usan st.metric con un solo valor (ej. las que no
    tienen delta, como 'Calificación crediticia').
    - d_ronda / d_industria: delta YA calculado en %, como float (ej. de delta_vs_ronda_anterior() y
      delta_raw() respectivamente) -- None si no hay dato.
    - favorable_ronda / favorable_industria: True/False para pintar ESE delta verde/rojo; si se deja
      en None se asume signo positivo = favorable (sirve para la mayoría de las métricas; para
      'menos es mejor' -- Deuda, costos -- hay que pasarlo explícito, igual que ya hace el resto
      de la app con delta_color='inverse' / 'favorable' invertido).
    - ronda_prev_nombre: nombre de la ronda anterior (ronda_anterior_de(...)) para el texto de esa
      línea ('vs Ronda 1'); si no se pasa, queda 'vs ronda anterior' genérico.
    El ícono (🔺/🔻) sigue el signo LITERAL del delta (subió/bajó); el color sigue 'favorable' --
    mismo criterio que ya usa el resto del tablero (ver _icono_delta / kpi_banda_oscura)."""
    def _linea(valor, etiqueta, favorable):
        if valor is None or pd.isna(valor):
            return ''
        icono = '🔺' if valor > 0 else ('🔻' if valor < 0 else '➖')
        fav = favorable if favorable is not None else (valor > 0)
        clase = 'up' if fav else 'down'
        return f'<div class="kpi-card-delta {clase}">{icono} {valor:+.1f}{unidad} {etiqueta}</div>'
    etiqueta_ronda = f'vs {ronda_prev_nombre}' if ronda_prev_nombre else 'vs año anterior'
    html = (f'<div class="kpi-card-doble"><div class="kpi-card-label">{label}</div>'
            f'<div class="kpi-card-value">{valor_txt}</div>'
            f'{_linea(d_industria, "vs Industria", favorable_industria)}'
            f'{_linea(d_ronda, etiqueta_ronda, favorable_ronda)}'
            f'</div>')
    (col if col is not None else st).markdown(html, unsafe_allow_html=True)

# ---------------- Panel de alertas ----------------
def evaluar_alertas():
    """Corre un set de reglas sobre la ronda en foco y devuelve solo lo que se está prendiendo.
    La idea es no tener que recorrer las 5 secciones para enterarse de que algo se rompió."""
    alertas = []
    bal = df[(df['Estado'] == 'Hoja de Balance, miles USD, Global') & (df['Ronda'] == ronda_snapshot)]
    ratios = df[(df['Estado'] == 'Ratios e indicadores financieros clave') & (df['Ronda'] == ronda_snapshot)]

    # --- Liquidez: el sobregiro automático de Cesim es un hecho del reporte, no un umbral nuestro
    deuda_cp = valor_de(bal, 'Deudas a corto plazo (no planificadas)', empresa_analisis)
    if deuda_cp and deuda_cp > 0:
        alertas.append(('critico', 'Sobregiro automático',
                        f'{format_num(deuda_cp)} USD de deuda de corto plazo NO planificada: la caja no alcanzó '
                        'para cubrir obligaciones. Suele venir con tasa de interés penal.'))

    orden_hoy = df[df['Ronda'] == ronda_snapshot]['Ronda_Orden'].iloc[0] if not df[df['Ronda'] == ronda_snapshot].empty else None

    # NOTA: hubo acá una alerta "I+D fuera de lo común" (Categoría 3, supuesto propio de CADIZ) que
    # vigilaba gasto de I+D récord + por encima del promedio de rivales, como indicio temprano de
    # tecnología nueva en camino. Se sacó a pedido del equipo (ensuciaba el panel y no aportaba
    # suficiente valor accionable) -- la detección CONFIRMADA de tecnología nueva (Categoría 2, un
    # hecho, no una estimación) sigue más abajo en "Entrada a tecnología nueva de la competencia".

    # --- Tendencias: dos rondas seguidas en la misma dirección. No hay número inventado acá,
    #     es la propia serie del reporte la que define si viene cayendo o subiendo.
    def dos_rondas_seguidas(estado, metrica, etiqueta, detalle, subiendo=False, seccion=None):
        serie = serie_metrica(estado, metrica, empresa_analisis, hasta_orden=orden_hoy, seccion=seccion)
        serie = [v for v in serie if v is not None and not pd.isna(v)]
        if len(serie) < 3: return
        d1, d2 = serie[-1] - serie[-2], serie[-2] - serie[-3]
        if (d1 > 0 and d2 > 0) if subiendo else (d1 < 0 and d2 < 0):
            alertas.append(('aviso', etiqueta, detalle.format(a=serie[-3], b=serie[-1])))

    dos_rondas_seguidas('Ratios e indicadores financieros clave', 'Retorno total acumulado del accionista (p.a.), %',
                        'Retorno del accionista en baja', 'Cayó dos años seguidos: de {a:,.1f}% a {b:,.1f}%.')
    dos_rondas_seguidas('Hoja de Balance, miles USD, Global', 'Inventario',
                        'Inventario acumulándose', 'Creció dos años seguidos — capital inmovilizado.', subiendo=True)

    # --- Cambios vs. la ronda anterior: se compara el dato de una ronda contra el de la otra,
    #     sin definir qué valor es "bueno" o "malo".
    ordenes = sorted(df['Ronda_Orden'].dropna().unique())
    orden_prev = None
    if orden_hoy in ordenes:
        i = ordenes.index(orden_hoy)
        orden_prev = ordenes[i - 1] if i > 0 else None

    if orden_prev is not None:
        ronda_prev = df[df['Ronda_Orden'] == orden_prev]['Ronda'].iloc[0]

        # --- Crecimiento del Mercado vs. Crecimiento propio en Facturación USD (por región, acorde a diferenciación) ---
        for pais in _MERCADOS_GAP:
            est_dm_p = f'Desglose de margen por tec, miles USD, {pais}'
            ing_act_mkt = pd.to_numeric(df[(df['Estado'] == est_dm_p) & (df['Metrica'] == 'Ingresos por ventas') & (df['Ronda_Orden'] == orden_hoy)]['Valor'], errors='coerce').sum()
            ing_prev_mkt = pd.to_numeric(df[(df['Estado'] == est_dm_p) & (df['Metrica'] == 'Ingresos por ventas') & (df['Ronda_Orden'] == orden_prev)]['Valor'], errors='coerce').sum()
            ing_act_emp = pd.to_numeric(df[(df['Estado'] == est_dm_p) & (df['Metrica'] == 'Ingresos por ventas') & (df['Ronda_Orden'] == orden_hoy) & (df['Empresa'] == empresa_analisis)]['Valor'], errors='coerce').sum()
            ing_prev_emp = pd.to_numeric(df[(df['Estado'] == est_dm_p) & (df['Metrica'] == 'Ingresos por ventas') & (df['Ronda_Orden'] == orden_prev) & (df['Empresa'] == empresa_analisis)]['Valor'], errors='coerce').sum()

            u_act_mkt = pd.to_numeric(df[(df['Estado'] == f'Informe de mercado, {pais}') & (df['Metrica'] == 'Ventas, miles unidades') & (df['Ronda_Orden'] == orden_hoy)]['Valor'], errors='coerce').sum()
            u_prev_mkt = pd.to_numeric(df[(df['Estado'] == f'Informe de mercado, {pais}') & (df['Metrica'] == 'Ventas, miles unidades') & (df['Ronda_Orden'] == orden_prev)]['Valor'], errors='coerce').sum()
            u_act_emp = pd.to_numeric(df[(df['Estado'] == f'Informe de mercado, {pais}') & (df['Metrica'] == 'Ventas, miles unidades') & (df['Ronda_Orden'] == orden_hoy) & (df['Empresa'] == empresa_analisis)]['Valor'], errors='coerce').sum()
            u_prev_emp = pd.to_numeric(df[(df['Estado'] == f'Informe de mercado, {pais}') & (df['Metrica'] == 'Ventas, miles unidades') & (df['Ronda_Orden'] == orden_prev) & (df['Empresa'] == empresa_analisis)]['Valor'], errors='coerce').sum()

            if ing_prev_mkt > 0 and ing_prev_emp > 0:
                c_ing_mkt = (ing_act_mkt - ing_prev_mkt) / ing_prev_mkt * 100
                c_ing_emp = (ing_act_emp - ing_prev_emp) / ing_prev_emp * 100
                brecha_ing = c_ing_emp - c_ing_mkt
                ctx_u = ''
                if u_prev_mkt > 0 and u_prev_emp > 0:
                    c_u_mkt = (u_act_mkt - u_prev_mkt) / u_prev_mkt * 100
                    c_u_emp = (u_act_emp - u_prev_emp) / u_prev_emp * 100
                    ctx_u = f' (en volumen físico: {empresa_analisis} {c_u_emp:+.1f}% vs. Mercado {c_u_mkt:+.1f}%)'
                if brecha_ing <= -2.0:
                    niv_tr = 'critico' if (c_ing_mkt > 0 and c_ing_emp < 0) else 'aviso'
                    alertas.append((niv_tr, f'Facturación en {pais}: {empresa_analisis} {c_ing_emp:+.1f}% vs. Mercado {c_ing_mkt:+.1f}%',
                                    f'En valor (USD) contra {ronda_prev}, {empresa_analisis} quedó {abs(brecha_ing):.1f} p.p. por debajo del crecimiento de la región{ctx_u}.'))
                elif brecha_ing >= 2.0:
                    alertas.append(('ok', f'Facturación en {pais}: {empresa_analisis} {c_ing_emp:+.1f}% vs. Mercado {c_ing_mkt:+.1f}%',
                                    f'En valor (USD) contra {ronda_prev}, {empresa_analisis} superó en +{brecha_ing:.1f} p.p. el crecimiento de la región{ctx_u}.'))

            # --- Despegue tecnológico en el mix de demanda regional (>= 5 p.p. de salto en un año) ---
            dem_tot_act = pd.to_numeric(df[(df['Estado'] == f'Informe de mercado, {pais}') & (df['Metrica'] == 'Demanda, miles unidades') & (df['Ronda_Orden'] == orden_hoy)]['Valor'], errors='coerce').sum()
            dem_tot_prev = pd.to_numeric(df[(df['Estado'] == f'Informe de mercado, {pais}') & (df['Metrica'] == 'Demanda, miles unidades') & (df['Ronda_Orden'] == orden_prev)]['Valor'], errors='coerce').sum()
            if dem_tot_act > 0 and dem_tot_prev > 0:
                for tech in _TECNOLOGIAS_GAP[1:]:
                    d_t_act = pd.to_numeric(df[(df['Estado'] == f'Informe de mercado, {pais}') & (df['Seccion'] == tech) & (df['Metrica'] == 'Demanda, miles unidades') & (df['Ronda_Orden'] == orden_hoy)]['Valor'], errors='coerce').sum()
                    d_t_prev = pd.to_numeric(df[(df['Estado'] == f'Informe de mercado, {pais}') & (df['Seccion'] == tech) & (df['Metrica'] == 'Demanda, miles unidades') & (df['Ronda_Orden'] == orden_prev)]['Valor'], errors='coerce').sum()
                    pct_act = (d_t_act / dem_tot_act) * 100
                    pct_prev = (d_t_prev / dem_tot_prev) * 100
                    if (pct_act - pct_prev) >= 5.0:
                        alertas.append(('aviso', f'Aceleración de {tech} en {pais} ({pct_prev:.1f}% → {pct_act:.1f}% del mix)',
                                        f'Ganó +{pct_act - pct_prev:.1f} p.p. de participación sobre la demanda total de {pais} respecto de {ronda_prev}.'))
        ratios_prev = df[(df['Estado'] == 'Ratios e indicadores financieros clave') & (df['Ronda_Orden'] == orden_prev)]

        # Posición en el ranking de retorno del accionista
        def puesto(tabla):
            vals = {e: valor_de(tabla, 'Retorno total acumulado del accionista (p.a.), %', e) for e in COMPANIES}
            rk = sorted([e for e in vals if vals.get(e) is not None], key=vals.get, reverse=True)
            return rk.index(empresa_analisis) + 1 if empresa_analisis in rk else None
        p_hoy, p_ant = puesto(ratios), puesto(ratios_prev)
        if p_hoy is not None and p_ant is not None and p_hoy != p_ant:
            nivel = 'aviso' if p_hoy > p_ant else 'ok'
            verbo = 'Bajó' if p_hoy > p_ant else 'Subió'
            alertas.append((nivel, f'{verbo} del {p_ant}° al {p_hoy}° puesto',
                            f'Ranking de retorno del accionista, contra {ronda_prev}.'))

        # Calificación crediticia: se reporta el cambio, sin juzgar qué letra es aceptable
        calif_hoy = valor_texto(ratios, 'Calificación crediticia', empresa_analisis)
        calif_ant = valor_texto(ratios_prev, 'Calificación crediticia', empresa_analisis)
        if calif_hoy and calif_ant and str(calif_hoy).strip() != str(calif_ant).strip():
            alertas.append(('aviso', 'Cambió la calificación crediticia',
                            f'De {str(calif_ant).strip()} a {str(calif_hoy).strip()} respecto de {ronda_prev}.'))

        # --- Entrada CONFIRMADA de LA COMPETENCIA a una tecnología nueva: a diferencia del aviso de
        #     I+D de arriba (estimativo, y ciego a la vía de licencia), esto es un HECHO -- Categoría
        #     2, dato real de CESIM, sin ninguna estimación de nuestra parte. El manual describe DOS
        #     caminos para sumar tecnología (I+D propio o comprar una licencia, disponible de
        #     inmediato) y esta alerta los cubre a los dos por igual: no le importa CÓMO la consiguió
        #     el rival, solo que efectivamente ya la tiene y la está vendiendo -- verificado con la
        #     cuota de mercado real que CESIM publica por (país, tecnología) para los 7 equipos
        #     (`Informe de mercado, {país} → Seccion='{país} cuotas de mercado, %' → Metrica=
        #     tecnología`, el mismo campo que ya usa `cuota_mercado_objetivo_vs_real` en
        #     gap_analysis.py). Se dispara cuando un rival pasa de 0% en la ronda anterior a >0% en
        #     esta, en una tecnología/país donde antes no vendía nada -- vigila a todos los rivales
        #     siempre, igual que las otras alertas de competencia.
        #
        #     Aparece recién cuando ya hubo ventas reales (una ronda más tarde que la inversión en
        #     I+D si fue por esa vía, o la misma ronda si fue por licencia) -- llega después que el
        #     aviso de I+D, pero sin ninguna ambigüedad sobre qué tecnología es.
        #
        #     Se consolida en UN solo aviso (mismo patrón que "Movimientos de capacidad de la
        #     competencia" más abajo) en vez de una tarjeta por cada combinación: cuando una
        #     tecnología recién se habilita para toda la industria, pueden entrar 3-4 equipos juntos
        #     en la misma ronda, y una tarjeta idéntica repetida 4 veces satura el panel sin agregar
        #     información nueva en cada una.
        entradas_tech = []
        for pais in _MERCADOS_GAP:
            cuota_hoy = df[(df['Estado'] == f'Informe de mercado, {pais}') &
                           (df['Seccion'] == f'{pais} cuotas de mercado, %') &
                           (df['Ronda_Orden'] == orden_hoy) & (df['Empresa'] != MY_COMPANY)].copy()
            cuota_prev = df[(df['Estado'] == f'Informe de mercado, {pais}') &
                             (df['Seccion'] == f'{pais} cuotas de mercado, %') &
                             (df['Ronda_Orden'] == orden_prev) & (df['Empresa'] != MY_COMPANY)].copy()
            if cuota_hoy.empty: continue
            cuota_hoy['Valor'] = num(cuota_hoy['Valor'])
            cuota_prev['Valor'] = num(cuota_prev['Valor'])
            for tech in _TECNOLOGIAS_GAP:
                hoy_t = cuota_hoy[cuota_hoy['Metrica'] == tech].dropna(subset=['Valor']).set_index('Empresa')['Valor']
                prev_t = cuota_prev[cuota_prev['Metrica'] == tech].dropna(subset=['Valor']).set_index('Empresa')['Valor']
                for rival in [e for e in COMPANIES if e != MY_COMPANY]:
                    v_hoy = hoy_t.get(rival)
                    if v_hoy is None or v_hoy <= 0: continue
                    v_prev = prev_t.get(rival, 0.0)
                    if v_prev == 0:
                        entradas_tech.append(f'{rival} en {tech} ({pais}, 0% → {v_hoy:.1f}%)')
        if entradas_tech:
            detalle = (' · '.join(entradas_tech) + '. Antes no vendían nada ahí en esa tecnología — '
                       'confirmado con dato real, sin importar si la consiguieron con I+D propio o '
                       'comprando una licencia.')
            alertas.append(('aviso', 'Entrada a tecnología nueva de la competencia', detalle))

    # --- Movimientos de capacidad de LA COMPETENCIA: Cesim publica las fábricas que va a haber
    #     después de la próxima ronda, así que se sabe de antemano quién está por agrandarse o
    #     achicarse. La idea de esta alerta es específicamente vigilar a los rivales -- CADIZ ya
    #     sabe sus propias decisiones -- y hacerlo siempre, sin depender de a quién tengamos
    #     seleccionado en "Equipo en foco" (por eso se compara contra MY_COMPANY, no contra
    #     empresa_analisis: cambiar el equipo en foco para mirar otra sección no debe apagar esta
    #     vigilancia de la competencia).
    # OJO con la forma del reporte: Cesim pone el PAÍS en 'Metrica' (EE.UU. / Asia) y el
    # HORIZONTE en 'Subgrupo' (Ronda actual / Próxima ronda / Después de la próxima ronda).
    # Filtrando al revés no matchea nada y el conteo actual daba 0.
    #
    # Historial de este chequeo: la v1 mezclaba los 7 equipos en un solo mensaje ambiguo y solo
    # miraba subas (nunca bajas, como la reducción real de CEOS en EE.UU. 7->5 en Ronda 1) -- se
    # corrigió de más filtrando a empresa_analisis, lo cual apagaba el aviso de competencia cuando
    # el foco está en CADIZ, que es exactamente el caso de uso principal. Esta versión vuelve a
    # cubrir a todos los rivales (todo el que no sea MY_COMPANY), agrega reducciones, y desglosa
    # por área (Metrica) en vez de sumar EE.UU.+Asia en un solo número, que puede esconder un
    # movimiento real en un área si la otra se mueve al revés.
    #
    # Se mantiene el aviso de Ronda de práctica: verificado con datos reales que una decisión
    # cargada ahí (ensayo, ej. CADIZ Asia 2->3 en Práctica 2) puede no trasladarse nunca a la
    # competencia oficial (Ronda 1 mostró a CADIZ sin cambios) -- no es un compromiso real.
    #
    # FIX (reportado: "en Ronda 1 dice que CEOS expande Asia en las próximas 2 rondas, y en
    # Ronda 2 vuelve a decir lo mismo"): es el MISMO evento real, visto dos veces porque antes solo
    # se comparaba 'Ronda actual' contra 'Después de la próxima ronda' (fijo a 2 rondas vista) y el
    # título decía siempre "(próximas 2 rondas)" sin importar cuánto faltaba en realidad. Verificado
    # con los datos: en R1, CEOS Asia = 2 (actual) / 2 (próxima) / 3 (después) -> el cambio todavía
    # está a 2 rondas. En R2, CEOS Asia = 2 (actual) / 3 (próxima) / 3 (después) -> el MISMO cambio
    # ya está a 1 ronda -- el horizonte se acorta, pero el mensaje no lo reflejaba y parecía una
    # alerta repetida sin sentido. Ahora se mira primero 'Próxima ronda' (1 ronda vista); si ahí no
    # hay cambio, recién se usa 'Después de la próxima ronda' (2 rondas vista) -- así el aviso
    # cuenta regresiva (2 rondas -> 1 ronda) en vez de repetirse idéntico, y deja de aparecer solo
    # cuando el cambio ya se concretó en 'Ronda actual'.
    fab = df[(df['Estado'] == 'Detalles de fabricación') & (df['Seccion'] == 'Número de fábricas') &
             (df['Ronda'] == ronda_snapshot) & (df['Empresa'] != MY_COMPANY)].copy()
    if not fab.empty:
        fab['Valor'] = num(fab['Valor'])
        act = fab[fab['Subgrupo'] == 'Ronda actual'].groupby(['Empresa', 'Metrica'])['Valor'].sum()
        prox = fab[fab['Subgrupo'] == 'Próxima ronda'].groupby(['Empresa', 'Metrica'])['Valor'].sum()
        desp = fab[fab['Subgrupo'] == 'Después de la próxima ronda'].groupby(['Empresa', 'Metrica'])['Valor'].sum()
        movimientos = []
        for clave in act.index:
            empresa, area = clave
            a = act.get(clave, 0)
            p = prox.get(clave, a)
            d = desp.get(clave, p)
            # Prioridad: el cambio más cercano en el tiempo es el que importa mostrar ahora.
            if p != a:
                destino, horizonte = p, 'el próximo año'
            elif d != a:
                destino, horizonte = d, 'dentro de 2 años'
            else:
                continue
            verbo = 'expande' if destino > a else 'reduce'
            movimientos.append(f'{empresa} {verbo} {area} ({a:.0f} → {destino:.0f}, {horizonte})')
        if movimientos:
            detalle = ' · '.join(movimientos)
            alertas.append(('aviso', 'Movimientos de capacidad de la competencia', detalle))
    return alertas

def panel_alertas():
    alertas = evaluar_alertas()
    if not alertas:
        st.markdown('<div class="stat-segment-card"><div class="stat-segment-bar"><div class="seg ok" '
                    'style="width:100%"></div></div><div class="stat-segment-legend"><span class="ok">'
                    '<span class="pt"></span>Sin alertas activas</span></div></div>', unsafe_allow_html=True)
        st.markdown(f'<div class="alerta-fila ok">✅ <b>Sin alertas</b> '
                    f'<span class="detalle">— nada fuera de rango en {ronda_snapshot} para {empresa_analisis}.</span></div>',
                    unsafe_allow_html=True)
        return
    # Barra de composición por severidad -- el total es la cantidad de alertas ACTIVAS ahora
    # (no un universo fijo de "reglas evaluadas": una sola regla puede dispararse varias veces,
    # ver el comentario en assets/style.css junto a .stat-segment-card).
    n_critico = sum(1 for a in alertas if a[0] == 'critico')
    n_aviso = sum(1 for a in alertas if a[0] == 'aviso')
    n_ok = sum(1 for a in alertas if a[0] == 'ok')
    total_sev = n_critico + n_aviso + n_ok
    segs = ''.join(f'<div class="seg {niv}" style="width:{cnt/total_sev*100:.1f}%"></div>'
                   for niv, cnt in [('critico', n_critico), ('aviso', n_aviso), ('ok', n_ok)] if cnt)
    partes_legend = []
    if n_critico: partes_legend.append(f'<span class="critico"><span class="pt"></span>{n_critico} crítica{"s" if n_critico != 1 else ""}</span>')
    if n_aviso: partes_legend.append(f'<span class="aviso"><span class="pt"></span>{n_aviso} aviso{"s" if n_aviso != 1 else ""}</span>')
    if n_ok: partes_legend.append(f'<span class="ok"><span class="pt"></span>{n_ok} mejora{"s" if n_ok != 1 else ""}</span>')
    st.markdown(f'<div class="stat-segment-card"><div class="stat-segment-label">'
                f'Estado de alertas — {total_sev} activa{"s" if total_sev != 1 else ""} en {ronda_snapshot}</div>'
                f'<div class="stat-segment-bar">{segs}</div>'
                f'<div class="stat-segment-legend">{"".join(partes_legend)}</div></div>', unsafe_allow_html=True)
    # Orden: primero lo que hay que resolver, después lo informativo, al final las mejoras.
    orden = {'critico': 0, 'aviso': 1, 'ok': 2}
    iconos = {'critico': '🔴', 'aviso': '🟠', 'ok': '🟢'}
    clases = {'critico': 'alerta-fila', 'aviso': 'alerta-fila aviso', 'ok': 'alerta-fila ok'}
    for nivel, titulo, detalle in sorted(alertas, key=lambda a: orden.get(a[0], 1)):
        icono = iconos.get(nivel, '🟠')
        clase = clases.get(nivel, 'alerta-fila aviso')
        st.markdown(f'<div class="{clase}">{icono} <b>{titulo}</b> <span class="detalle">— {detalle}</span></div>',
                    unsafe_allow_html=True)

# ---------------- Sidebar ----------------
st.sidebar.markdown('### ULTI')
# Las rondas de Práctica (el ensayo previo al arranque de la competencia oficial) se sacaron de la
# navegación a pedido del equipo -- ya arrancó la competencia Oficial (Ronda 0 y Ronda 1 jugadas) y
# esos ensayos "no suman" al análisis de gestión. Quedan como dato histórico en el repo
# (data/raw/practicas/*.xls) por si hace falta revisarlos, pero la app ya no los ofrece para elegir.
filtro_tipo = 'Oficial'
rondas_timeline = [f'Año {i}' for i in range(1, 13)]
ronda_snapshot = st.sidebar.select_slider('Año de análisis', options=rondas_timeline, value=rondas_timeline[0], key='slider_rondas')
# Indicador de estado (estilo "● Conectado" de la referencia) -- acá confirma de un vistazo qué
# ronda está en foco, en vez de ser puramente decorativo.
st.sidebar.markdown(f'<div class="sidebar-status"><span class="dot"></span>{ronda_snapshot}</div>',
                     unsafe_allow_html=True)
empresa_analisis = st.sidebar.selectbox('Equipo en foco', COMPANIES, index=COMPANIES.index(MY_COMPANY), key='select_equipo')
st.sidebar.divider()

# ---------------- Generar Excel de gestión (motor de proyección, build_gestion_v2.py) ----------------
# Ronda N.N (Fase 4): ya NO se suben archivos a mano -- todo se resuelve leyendo rutas fijas DEL PROPIO
# REPO de GitHub (mismas que usa el resto de la app / el modelo):
#   - data/raw/practicas/oficial/ : RDOS oficiales de CESIM ya commiteados (nombre de archivo libre --
#     descubrir_rdos_oficiales() detecta la ronda por el nombre O, si no matchea, abriendo el propio
#     RDOS y leyendo el título 'Ronda N' de la hoja Results). La última ronda con RDOS ahí define la
#     frontera REAL; la ronda a decidir es automáticamente N+1.
#   - data/decisiones/       : Excels de trabajo con las proyecciones/decisiones de CADIZ, nombrados
#     Ulti_proyeccion_R{N}.xlsx. El botón toma el más reciente relevante (misma ronda en curso, o la
#     ronda que acaba de pasar a REAL), rescata ahí las decisiones futuras ya cargadas y congela el
#     plan de la ronda que acaba de cerrarse, todo dentro de generar_excel_desde_repo().
# El archivo nuevo se arma en memoria (io.BytesIO, nunca se escribe en el disco del servidor) y se
# ofrece para descargar con su nombre auto-detectado (Ulti_proyeccion_R{N+1}.xlsx) -- el usuario lo
# commitea a mano en data/decisiones/, mismo flujo manual que ya usa hoy para ULTI_Gestion_v2.xlsx.
with st.sidebar.expander('🔧 Generar Excel de gestión (próximo año)'):
    st.caption('Lee los RDOS oficiales de `data/raw/practicas/oficial/` y las decisiones previas de '
               '`data/decisiones/` -- ya commiteados en el repo, no hace falta subir nada acá.')
    if st.button('Generar Excel del próximo año', key='btn_generar_excel'):
        try:
            with st.spinner('Generando Excel...'):
                buf, nombre_salida, info = generar_excel_desde_repo()
            rondas_reales_txt = ', '.join(f'R{r}' for r in info['rondas_reales'])
            st.success(f'{nombre_salida} generado -- años reales detectados: {rondas_reales_txt} · '
                       f'año a decidir: R{info["ronda_a_decidir"]}.')
            detalle = []
            if info.get('archivo_previo_usado'):
                detalle.append(f'Decisiones previas rescatadas de `{os.path.basename(info["archivo_previo_usado"])}` '
                                f'({info["overrides_aplicados"]} valores aplicados'
                                + (f', {info["overrides_sin_match"]} sin match' if info.get('overrides_sin_match') else '')
                                + ').')
            else:
                detalle.append('No había un archivo de decisiones previo -- primera corrida (bootstrap).')
            if info.get('plan_congelado_filas'):
                detalle.append(f'Plan Congelado: {info["plan_congelado_filas"]} filas inyectadas en DATA_EXPORT.')
            if not info.get('ok', True):
                detalle.append(f'⚠️ No se pudo recalcular con LibreOffice ({info.get("mensaje")}) -- el '
                                'Excel se generó igual, pero Excel recalculará las fórmulas recién al abrirlo.')
            for d in detalle:
                st.caption(d)
            st.download_button(f'⬇️ Descargar {nombre_salida}', data=buf,
                                file_name=nombre_salida,
                                mime='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                                key='dl_excel_generado')
        except FileNotFoundError as e:
            st.error(f'No se pudo generar el Excel: {e}')
        except Exception as e:
            st.error(f'No se pudo generar el Excel: {e}')
st.sidebar.divider()
# BUG REPORTADO Y CONFIRMADO -- es una limitación de la plataforma, no de este código: Streamlit
# expone el tema elegido (Settings > claro/oscuro/uso del sistema) vía st.context.theme.type, pero
# esa lectura se toma UNA VEZ por corrida del script, y alternar el tema en el menú de Settings no
# siempre dispara una corrida nueva por sí solo. Resultado: si tocás el toggle de tema, los colores
# que dependen de es_modo_oscuro() (banda de KPIs, sidebar, gráficos) pueden quedar con el tema
# VIEJO hasta que algo más fuerce un rerun -- cambiar de Ronda, de Equipo o de Sección, como ya
# venía notando el equipo. Este botón es el atajo más chico y confiable para lo mismo, sin tener
# que tocar otro control de la app.
if st.sidebar.button('🔄 Actualizar tema', help='Usalo si cambiaste entre modo claro/oscuro en Settings y los colores de la app no se actualizaron solos.'):
    st.rerun()
SECCIONES = ['Resultados', 'Mercado', 'Operaciones', 'Finanzas', 'RRHH y Sostenibilidad', 'Control de Gestión']
seccion = st.sidebar.radio('Sección', SECCIONES, key='select_seccion_router')
df_all = get_data(filtro_tipo)
if df_all.empty or ronda_snapshot not in df_all['Ronda'].unique():
    # CASO ESPECIAL: CESIM todavía no publicó ningún RDOS de esta ronda (nada que mostrar en
    # Resultados/Mercado/Operaciones/RRHH), pero ULTI ya cargó su propia proyección en el modelo de
    # gestión para esa ronda -- en vez de un callejón sin salida, se muestra directamente el Control
    # de Gestión (lo único que SÍ hay para ofrecer) en la sección Finanzas. Fuera de Finanzas, o si
    # no hay proyección tampoco, se mantiene el aviso original sin cambios.
    ronda_num_bypass = ronda_a_num(ronda_snapshot)
    df_proy_bypass = get_proyeccion(ronda_num_bypass) if ronda_num_bypass is not None else None
    hay_proyeccion_cadiz = (df_proy_bypass is not None and not df_proy_bypass[
        (df_proy_bypass['round'] == ronda_num_bypass) & (df_proy_bypass['team'] == MY_COMPANY)].empty)
    # Adenda 29: 'Control de Gestión' (nueva sección, home actual de Plan vs. Real) usa el mismo
    # crosswalk que antes usaba Finanzas acá -- es el Nivel 1 de su narrativa (chart_bullet_panel,
    # CROSSWALK_FINANZAS), el único nivel que tiene sentido mostrar sin ningún RDOS publicado todavía
    # (los otros 2 niveles cruzan contra datos de mercado/fabricación que tampoco existen aún).
    _CROSSWALK_POR_SECCION_BYPASS = {'Finanzas': CROSSWALK_FINANZAS, 'Mercado': CROSSWALK_MERCADO,
                                      'Operaciones': CROSSWALK_OPERACIONES, 'Resultados': CROSSWALK_RESULTADOS,
                                      'Control de Gestión': CROSSWALK_FINANZAS}
    if hay_proyeccion_cadiz and seccion in _CROSSWALK_POR_SECCION_BYPASS and empresa_analisis == MY_COMPANY:
        st.info(f"📁 CESIM todavía no publicó los RDOS de **{ronda_snapshot}** — el resto del tablero "
                "no tiene datos para mostrar todavía, pero ULTI ya cargó su proyección para este "
                "año en el modelo de gestión:")
        panel_comparativa_plan_real(df_all.copy(), ronda_snapshot, crosswalk=_CROSSWALK_POR_SECCION_BYPASS[seccion],
                               key_suffix=f'{seccion.lower()}_sin_real', mostrar_directo=True)
    else:
        st.info(f"📁 Faltan datos: No se encontraron archivos para **{ronda_snapshot}** en el entorno **{filtro_tipo}**.")
    st.stop()
df = df_all.copy()
ronda_ultima = ronda_snapshot
try:
    st.markdown(f'<style>{open(os.path.join(BASE_DIR, "assets", "style.css"), encoding="utf-8").read()}</style>', unsafe_allow_html=True)
except FileNotFoundError:
    # Antes fallaba en silencio (pass): si el archivo no está en el despliegue, la app se veía
    # sin ningún estilo custom (sidebar claro, sin banda oscura, sin barra segmentada) y no había
    # ninguna pista de por qué. Ahora al menos avisa.
    st.warning('No se encontró assets/style.css — el estilo visual (sidebar oscuro, banda de KPIs, '
               'barras segmentadas) no se aplicó en este despliegue. Verificá que la carpeta '
               '"assets" se haya subido junto con app.py.')
# =================================================================
# SECCIÓN 1 — RESULTADOS
# =================================================================
def seccion_resultado():
    # Adenda 29 (a pedido del equipo, "Control de Gestión" centralizado): la sub-pestaña
    # 'Comparativa Plan vs. Real' que vivía acá se elimina -- esta sección queda enfocada solo en el
    # análisis operativo/competitivo de la ronda (los 7 equipos). El desvío Plan vs. Real de CADIZ
    # (panel_comparativa_plan_real + fila3_resultados_ingresos, que se llamaban desde acá) ahora vive
    # consolidado en la sección propia 'Control de Gestión' (Nivel 2 de esa narrativa), sin perder
    # ningún gráfico -- ver seccion_control_gestion() más abajo.
    # Adenda 30 (a pedido del equipo, "reubicar la vista de Mercado"): la vista macro de industria
    # (que en la Adenda 29 había entrado como 4ta pestaña de seccion_mercado()) se muda ACÁ, como
    # 2da pestaña 'Mercado' junto a 'Resumen' -- ver _seccion_resultado_mercado_macro() más abajo.
    tab_resumen, tab_mercado_macro = st.tabs(['Resumen', 'Mercado'])
    with tab_resumen:
        _seccion_resultado_resumen()
    with tab_mercado_macro:
        _seccion_resultado_mercado_macro()
def _seccion_resultado_resumen():
    val_ronda = df[(df['Estado'] == 'Valuación - Global') & (df['Ronda'] == ronda_snapshot)]
    ratios_ronda_r1 = df[(df['Estado'] == 'Ratios e indicadores financieros clave') & (df['Ronda'] == ronda_snapshot)]

    # "Accionistas, Total" en la tabla de Creación de Valor = Beneficio de la ronda: es el valor
    # generado PARA EL ACCIONISTA en esa ronda puntual (no confundir con "Valor total creado", que
    # suma también lo pagado a Proveedores/Personal/Gobierno — no es plata del accionista).
    acc_ronda = df[(df['Modulo'] == 'Creación de valor') & (df['Seccion'] == 'Accionistas') &
                   (df['Metrica'] == 'Total') & (df['Ronda'] == ronda_snapshot)]
    cv_vals = {emp: valor_de(acc_ronda, 'Total', emp) for emp in COMPANIES}

    # Acumulado: Cesim ya reporta este campo pre-acumulado desde el inicio del juego — no hay que
    # sumarlo nosotros ronda a ronda. Es el criterio real de "creación de valor para el accionista".
    retorno_acum_vals = {emp: valor_de(ratios_ronda_r1, 'Retorno total acumulado del accionista (p.a.), %', emp) for emp in COMPANIES}

    # Retorno de ESTA ronda puntual: variación simple del precio de la acción vs. la ronda anterior.
    # (El campo "acumulado" es *per annum*, no es aditivo entre rondas — restarlo directo da un
    # número que no representa lo que pasó en la ronda. Esto sí es directamente comparable ronda a ronda.)
    precio_hist = df[(df['Estado'] == 'Ratios e indicadores financieros clave') &
                      (df['Metrica'] == 'Precio de la acción al final de la ronda, USD')].copy()
    precio_hist['Valor'] = num(precio_hist['Valor'])
    ordenes_disp = sorted(df['Ronda_Orden'].dropna().unique())
    orden_actual = df[df['Ronda'] == ronda_snapshot]['Ronda_Orden'].iloc[0] if not df[df['Ronda'] == ronda_snapshot].empty else None
    idx_orden = ordenes_disp.index(orden_actual) if orden_actual in ordenes_disp else None
    orden_anterior = ordenes_disp[idx_orden - 1] if idx_orden and idx_orden > 0 else None
    retorno_ronda_vals = {}
    if orden_anterior is not None:
        for emp in COMPANIES:
            p_act = valor_de(precio_hist[precio_hist['Ronda_Orden'] == orden_actual], 'Precio de la acción al final de la ronda, USD', emp)
            p_ant = valor_de(precio_hist[precio_hist['Ronda_Orden'] == orden_anterior], 'Precio de la acción al final de la ronda, USD', emp)
            retorno_ronda_vals[emp] = ((p_act - p_ant) / p_ant * 100) if (p_act is not None and p_ant not in (None, 0)) else None

    cap_vals = {emp: valor_de(val_ronda, 'Capitalización de mercado, miles USD', emp) for emp in COMPANIES}
    with st.container(border=True):
        st.markdown(f'**Alertas — {empresa_analisis}, {ronda_snapshot}**')
        panel_alertas()
    st.write('')
    st.subheader('KPIs de Valor')
    prom_ret_acum = np.nanmean([v for v in retorno_acum_vals.values() if v is not None]) if any(v is not None for v in retorno_acum_vals.values()) else None
    val_ret_acum = retorno_acum_vals.get(empresa_analisis)
    delta_ret_acum = ((val_ret_acum - prom_ret_acum) / abs(prom_ret_acum) * 100) if prom_ret_acum and val_ret_acum is not None else None

    ranking_acum = sorted([e for e in retorno_acum_vals if retorno_acum_vals.get(e) is not None], key=retorno_acum_vals.get, reverse=True)
    pos = ranking_acum.index(empresa_analisis) + 1 if empresa_analisis in ranking_acum else '-'
    ret_hist = df_all[(df_all['Estado'] == 'Ratios e indicadores financieros clave') &
                       (df_all['Metrica'] == 'Retorno total acumulado del accionista (p.a.), %')].copy()
    ret_hist['Valor'] = num(ret_hist['Valor'])
    puestos_hist = ret_hist.dropna(subset=['Valor']).copy()
    puestos_hist['Puesto'] = puestos_hist.groupby('Ronda')['Valor'].rank(ascending=False, method='min')
    serie_puesto = puestos_hist[puestos_hist['Empresa'] == empresa_analisis].sort_values('Ronda_Orden')['Puesto'].tolist()

    prom_cv = np.nanmean([v for v in cv_vals.values() if v is not None]) if any(v is not None for v in cv_vals.values()) else None
    val_cv = cv_vals.get(empresa_analisis)
    delta_cv = ((val_cv - prom_cv)/prom_cv*100) if prom_cv and val_cv is not None else None

    prom_cap = np.nanmean([v for v in cap_vals.values() if v is not None]) if any(v is not None for v in cap_vals.values()) else None
    val_cap = cap_vals.get(empresa_analisis)
    delta_cap = ((val_cap - prom_cap)/prom_cap*100) if prom_cap and val_cap else None

    # Adenda 25 (a pedido del equipo: "no quiero ver solamente la variación vs el promedio, que
    # quede la variación con ronda anterior también, en todos los casos"): cada KPI de la banda
    # ahora trae TAMBIÉN su delta vs. la ronda anterior, además del vs. Promedio Industria que ya
    # tenía. "Beneficio del accionista" no tiene un Estado/Metrica directo en `df` (sale de
    # Modulo == 'Creación de valor', no de un Estado) -- por eso se arma a mano en vez de con
    # delta_vs_ronda_anterior(), que solo sabe filtrar por Estado.
    d_ret_acum_ronda, ronda_prev_kpi = delta_vs_ronda_anterior('Ratios e indicadores financieros clave', 'Retorno total acumulado del accionista (p.a.), %')
    d_cap_ronda, _ = delta_vs_ronda_anterior('Valuación - Global', 'Capitalización de mercado, miles USD')
    d_cv_ronda = None
    if ronda_prev_kpi:
        acc_prev = df[(df['Modulo'] == 'Creación de valor') & (df['Seccion'] == 'Accionistas') &
                      (df['Metrica'] == 'Total') & (df['Ronda'] == ronda_prev_kpi)]
        val_cv_prev = valor_de(acc_prev, 'Total', empresa_analisis)
        if val_cv_prev not in (None, 0) and val_cv is not None and pd.notna(val_cv_prev) and pd.notna(val_cv):
            d_cv_ronda = (val_cv - val_cv_prev) / abs(val_cv_prev) * 100

    def _fmt_delta(d, sufijo):
        return f'{d:+.1f}% {sufijo}' if d is not None else None

    sufijo_ronda = f'vs {ronda_prev_kpi}' if ronda_prev_kpi else 'vs año anterior'
    # Los 3 números que más le importan a un accionista van en la banda oscura, separados del
    # resto (ver kpi_banda_oscura) -- "Retorno acum. del accionista", mismo término base que usa
    # el crosswalk de Resultados; "Capitalización de mercado" (antes "Market Cap", en inglés) usa
    # el mismo nombre que el propio campo de CESIM.
    kpi_banda_oscura([
        {'label': 'Retorno acum. del accionista', 'valor': f'{val_ret_acum:,.1f}%' if val_ret_acum is not None else '—',
         'delta': _fmt_delta(d_ret_acum_ronda, sufijo_ronda), 'favorable': (d_ret_acum_ronda > 0) if d_ret_acum_ronda is not None else None,
         'delta2': _fmt_delta(delta_ret_acum, 'vs Industria'), 'favorable2': (delta_ret_acum > 0) if delta_ret_acum is not None else None},
        {'label': 'Beneficio del accionista', 'valor': format_num(val_cv),
         'delta': _fmt_delta(d_cv_ronda, sufijo_ronda), 'favorable': (d_cv_ronda > 0) if d_cv_ronda is not None else None,
         'delta2': _fmt_delta(delta_cv, 'vs Industria'), 'favorable2': (delta_cv > 0) if delta_cv is not None else None},
        {'label': 'Capitalización de mercado (USD)', 'valor': format_num(val_cap),
         'delta': _fmt_delta(d_cap_ronda, sufijo_ronda), 'favorable': (d_cap_ronda > 0) if d_cap_ronda is not None else None,
         'delta2': _fmt_delta(delta_cap, 'vs Industria'), 'favorable2': (delta_cap > 0) if delta_cap else None},
    ])

    # Posición en el ranking y Retorno de la ronda son más de contexto que de "número que decide
    # la creación de valor" -- se quedan como tarjetas claras con sparkline, más chicas.
    c2, c5 = st.columns(2)
    # color=COLOR_MAP.get(empresa_analisis): antes el sparkline caía al default de la función, que
    # (Adenda 25) dejó de asumir el lila/rojo de marca -- acá SÍ corresponde el color de identidad del
    # equipo en foco (COLOR_MAP ya resuelve lila para ULTI y el tono muted que le toque a cualquier
    # otro equipo), así que se pasa explícito.
    # invertir: en el ranking, "para arriba" en el gráfico tiene que ser mejorar de puesto
    # OJO -- excepción deliberada al "doble delta en todos los casos": "Posición en el ranking" es
    # un ORDINAL (1°, 2°...), no un monto ni un %, así que un "+X% vs Industria/Ronda Anterior" no
    # tiene una lectura clara acá (¿+50% de qué, de puesto?) -- se deja con su sparkline (que ya
    # muestra la tendencia del puesto) y sin delta numérico, en vez de forzar un % engañoso.
    kpi_con_tendencia(c2, 'Posición en el ranking', f'{pos}° de {len(COMPANIES)}', serie_puesto,
                       color=COLOR_MAP.get(empresa_analisis), invertir=True)

    prom_ret_ronda = np.nanmean([v for v in retorno_ronda_vals.values() if v is not None]) if any(v is not None for v in retorno_ronda_vals.values()) else None
    val_ret_ronda = retorno_ronda_vals.get(empresa_analisis)
    delta_ret_ronda = ((val_ret_ronda - prom_ret_ronda) / abs(prom_ret_ronda) * 100) if prom_ret_ronda and val_ret_ronda is not None else None
    # OJO -- segunda excepción deliberada: "Retorno de la acción" YA ES, por definición, la variación
    # de precio de ESTA ronda vs. la ronda anterior (ver comentario más arriba) -- agregarle un
    # segundo delta "vs. Ronda Anterior" sería comparar un cambio contra sí mismo, confuso. Se deja
    # con un solo delta (vs. Industria), que sí es una comparación genuinamente distinta.
    kpi_con_tendencia(c5, 'Retorno de la acción',
                       f'{val_ret_ronda:+,.1f}%' if val_ret_ronda is not None else '—',
                       serie_metrica('Ratios e indicadores financieros clave', 'Precio de la acción al final de la ronda, USD', empresa_analisis),
                       delta=f'{delta_ret_ronda:+.1f}% vs Industria' if delta_ret_ronda is not None else None,
                       color=COLOR_MAP.get(empresa_analisis))
    st.caption('El retorno acumulado es per-annum y no es aditivo entre años — para ver cómo fue *este* año usá '
               '"Retorno de la acción", que es variación simple de precio. En el primer año del ecosistema no hay '
               'año previo con el cual compararla. "Retorno de la acción" ya es en sí una comparación vs. año '
               'anterior, por eso trae un solo delta (vs. Industria) y no dos.')
    st.divider()
    vista_ranking = st.radio('Vista del ranking (columna derecha)', ['Acumulado (Retorno del Accionista, %)', f'Solo {ronda_snapshot} (USD)'], horizontal=True, key='vista_ranking_cv')
    col_a, col_b = st.columns(2)
    with col_a:
        pl = df[(df['Estado'] == 'Cuenta de resultados, miles USD, Global') & (df['Empresa'] == empresa_analisis) & (df['Ronda'] == ronda_snapshot)]
        def g(metrica): return valor_de(pl, metrica) or 0.0
        ingresos = g('Ingresos por ventas')
        if ingresos > 0:
            costos_prod = g('Costos de fabricación interna') + g('Costos de características') + g('Costos de fabricación contratada')
            costos_op = g('Costos de transporte y aranceles') + g('I+D') + g('Promoción') + g('Administración')
            depr, ints, imp, ben = g('Depreciación de Activos Fijos'), g('Gastos financieros netos'), g('Impuesto sobre el beneficio'), g('Beneficio de la ronda')
            _valores_puente = [ingresos, -costos_prod, -costos_op, -depr, -ints, -imp, ben]
            fig = go.Figure(go.Waterfall(
                orientation='v', measure=['relative', 'relative', 'relative', 'relative', 'relative', 'relative', 'total'],
                x=['Ingresos', '- Prod', '- Op/Admin', '- Depr', '- Int', '- Imp', '= Neto'],
                y=_valores_puente,
                # Adenda 25: % entre paréntesis sobre Ingresos (primera barra, el ancla del puente).
                text=_texto_cascada(_valores_puente), textposition='outside',
                # Adenda 25 (a pedido del equipo): convención universal -- verde = suma (increasing),
                # rojo = resta (decreasing), en todos los waterfalls de la app. Antes decreasing usaba
                # MUTED_PALETTE[2] (un verde grisáceo apagado, no rojo).
                decreasing={'marker': {'color': COLOR_NEGATIVE}}, increasing={'marker': {'color': COLOR_POSITIVE}},
                totals={'marker': {'color': COLOR_POSITIVE if ben > 0 else COLOR_NEGATIVE}}
            ))
            fig.update_layout(title=f'Puente de Beneficio Neto — {empresa_analisis}')
            mostrar(fig, ocultar_eje_valores='y')
    with col_b:
        es_acumulado = vista_ranking.startswith('Acumulado')
        datos_ranking = retorno_acum_vals if es_acumulado else cv_vals
        titulo_ranking = 'Ranking: Retorno Acumulado del Accionista, %' if es_acumulado else f'Ranking: Beneficio del Accionista — {ronda_snapshot}'
        ranking = pd.DataFrame(list(datos_ranking.items()), columns=['Empresa', 'Valor']).sort_values('Valor', ascending=True).dropna()
        ranking['Etiqueta'] = ranking['Valor'].apply(lambda v: f'{v:,.1f}%') if es_acumulado else ranking['Valor'].apply(format_num)
        fig = px.bar(ranking, x='Valor', y='Empresa', orientation='h', color='Empresa', color_discrete_map=COLOR_MAP, text='Etiqueta')
        fig.update_traces(textposition='outside', cliponaxis=False, showlegend=False)
        fig.update_layout(title=titulo_ranking, xaxis=dict(range=[0, ranking['Valor'].max() * 1.25]))
        mostrar(fig, ocultar_eje_valores='x')
    st.divider()
    st.subheader('Cuota de mercado')
    # Antes: 5 gráficos de barra casi idénticos (global, por valor, EE.UU., Asia, Europa) -- mismo
    # tipo de gráfico repetido 5 veces es exactamente la queja de "muchos gráficos de barra". Acá se
    # reemplazan por DOS formas distintas, cada una elegida por el trabajo que hace mejor:
    #   1) Dumbbell (dos puntos + línea): compara cuota por UNIDADES vs. cuota por VALOR por equipo en
    #      un solo gráfico -- la distancia entre los dos puntos de cada equipo ES el dato interesante
    #      (vender una porción de unidades distinta a la de ingresos implica un mix de precio propio).
    #   2) Heatmap: cuota por país (EE.UU./Asia/Europa) x equipo en una sola grilla -- reemplaza 3
    #      barras por 1 sola lectura de matriz, con la tabla de datos completa abajo por accesibilidad.
    sub_global = df[(df['Estado'] == 'Informe de mercado, global') &
                     (df['Seccion'] == 'Cuotas de mercado globales, %') & (df['Metrica'] == 'Total') &
                     (df['Ronda'] == ronda_snapshot)].copy()
    sub_global['Valor'] = num(sub_global['Valor'])
    cuota_unidades = sub_global.set_index('Empresa')['Valor'].to_dict()
    # Cuota por valor ($): CESIM no publica esta cifra directamente (los precios están en moneda local
    # por mercado -- USD/RMB/EUR -- y sumarlos sin convertir daría un número sin sentido). Se calcula
    # sobre "Ingresos por ventas, Global" (Cuenta de resultados), que CESIM SÍ publica ya convertido a
    # USD para los 7 equipos: cuota por valor = ingresos de la empresa / Σ ingresos de los 7 equipos.
    ingresos_glob = df[(df['Estado'] == 'Cuenta de resultados, miles USD, Global') &
                        (df['Metrica'] == 'Ingresos por ventas') & (df['Ronda'] == ronda_snapshot)].copy()
    ingresos_glob['Valor'] = num(ingresos_glob['Valor'])
    total_ing = ingresos_glob['Valor'].sum()
    cuota_valor = (ingresos_glob.set_index('Empresa')['Valor'] / total_ing * 100).to_dict() if total_ing else {}
    filas_dumbbell = [{'Empresa': e, 'Unidades': cuota_unidades.get(e), 'Valor': cuota_valor.get(e)} for e in COMPANIES]
    dfd = pd.DataFrame(filas_dumbbell).dropna(subset=['Unidades', 'Valor'])
    if not dfd.empty:
        dfd = dfd.sort_values('Valor')
        fig_d = go.Figure()
        for _, r in dfd.iterrows():
            es_cadiz = r['Empresa'] == MY_COMPANY
            fig_d.add_trace(go.Scatter(x=[r['Unidades'], r['Valor']], y=[r['Empresa'], r['Empresa']], mode='lines',
                                        line=dict(color=COLOR_CADIZ if es_cadiz else 'rgba(140,151,166,0.45)',
                                                  width=2.5 if es_cadiz else 1.5),
                                        showlegend=False, hoverinfo='skip'))
        # OJO: estos dos marcadores son por TIPO de medida (unidades vs. valor), para los 7 equipos a
        # la vez -- no son identidad de CADIZ (esa ya se marca en la línea de arriba, por es_cadiz),
        # así que van con tonos muted genéricos, no con el lila de marca.
        fig_d.add_trace(go.Scatter(x=dfd['Unidades'], y=dfd['Empresa'], mode='markers', name='Cuota por unidades, %',
                                    marker=dict(size=11, color=MUTED_PALETTE[0]),
                                    hovertemplate='%{y} — Unidades: %{x:.1f}%<extra></extra>'))
        # Adenda 25: se saca el marrón (MUTED_PALETTE[1]) de acá -- no pasa a lila porque seguiría sin
        # ser identidad (ver comentario de arriba), y el lila se reserva para "esto es CADIZ".
        # Fix "ya casi": MUTED_PALETTE[5] quedaba casi idéntico al MUTED_PALETTE[0] del marcador de
        # arriba (mismo gráfico) -- se reemplaza por el azul acero nuevo, bien separado del otro.
        fig_d.add_trace(go.Scatter(x=dfd['Valor'], y=dfd['Empresa'], mode='markers', name='Cuota por valor ($), %',
                                    marker=dict(size=11, color='#58759D', symbol='diamond'),
                                    hovertemplate='%{y} — Valor: %{x:.1f}%<extra></extra>'))
        fig_d.update_layout(title=f'Cuota de mercado global — unidades vs. valor, {ronda_snapshot}', xaxis_title='%',
                             legend=dict(orientation='h', yanchor='top', y=-0.2, xanchor='center', x=0.5))
        mostrar(fig_d)
    else:
        st.info('Sin datos suficientes de cuota global (unidades y valor) para este año.')
    st.caption('Cada línea conecta la cuota de UN equipo en dos monedas de medida: unidades vendidas y valor en '
               'USD. Cuando el punto de Valor queda a la derecha del de Unidades, ese equipo vende más caro que '
               'el promedio (o con mejor mix); si queda a la izquierda, más barato.')
    paises = ['EE.UU.', 'Asia', 'Europa']
    filas_hm = []
    for pais in paises:
        sub_pais = df[(df['Estado'] == f'Informe de mercado, {pais}') &
                      (df['Seccion'] == f'{pais} cuotas de mercado, %') & (df['Metrica'] == 'Total') &
                      (df['Ronda'] == ronda_snapshot)].copy()
        sub_pais['Valor'] = num(sub_pais['Valor'])
        for _, row in sub_pais.dropna(subset=['Valor']).iterrows():
            filas_hm.append({'Empresa': row['Empresa'], 'País': pais, 'Cuota': row['Valor']})
    if filas_hm:
        dfh = pd.DataFrame(filas_hm)
        piv = dfh.pivot(index='Empresa', columns='País', values='Cuota').reindex(columns=paises)
        piv = piv.reindex(piv.mean(axis=1).sort_values(ascending=False).index)  # ranking, no alfabético
        fig_hm = go.Figure(go.Heatmap(
            z=piv.values, x=list(piv.columns), y=list(piv.index),
            # Secuencial de un solo matiz, sin sentido de identidad ni sentimiento (esto muestra a los
            # 7 equipos, no solo a CADIZ) -- se usa el azul de COLOR_METRICA['dinero'] en vez del lila/
            # rojo de marca (Adenda 25).
            colorscale=[[0, _hex_a_rgba(COLOR_METRICA['dinero'], 0.06)], [1, COLOR_METRICA['dinero']]],
            text=[[f'{v:.1f}%' if pd.notna(v) else '' for v in fila] for fila in piv.values],
            texttemplate='%{text}', textfont=dict(size=12),
            hovertemplate='%{y} — %{x}: %{z:.1f}%<extra></extra>', showscale=False,
            xgap=3, ygap=3))  # gap entre celdas -- separador de superficie, no una grilla de líneas
        fig_hm.update_layout(title=f'Cuota de mercado por país, % — {ronda_snapshot}')
        mostrar(fig_hm)
        with st.expander('Ver como tabla'):
            st.dataframe(piv.style.format('{:.1f}%', na_rep='—'), use_container_width=True)
    else:
        st.info('Sin datos de cuota de mercado por país para este año.')
    st.divider()
    # Adenda 34 (a pedido del equipo, "sacar gráficos de líneas, dejar solo la evolución del retorno
    # acumulado"): se sacan de ACÁ los gráficos de evolución de "Capitalización de Mercado" y
    # "Beneficio Neto Acumulado" (el segundo se traslada a Finanzas, ver seccion_finanzas() --
    # "evolución del beneficio neto" que pidió el equipo ahí). Queda solo el de abajo.
    # Adenda 31 (a pedido del equipo, "Evolución vs. Año 0"): TSR es un dato REAL que CESIM ya
    # publica acumulado (no hay que sumarlo nosotros) -- Estado='Ratios e indicadores financieros
    # clave', Metrica='Retorno total acumulado del accionista (p.a.), %'. chart_evolucion() sirve
    # directo, sin transformar nada.
    tsr_sub = df[(df['Estado'] == 'Ratios e indicadores financieros clave') &
                 (df['Metrica'] == 'Retorno total acumulado del accionista (p.a.), %')].copy()
    chart_evolucion(tsr_sub, 'Retorno Total Acumulado del Accionista (TSR), %')

def _seccion_resultado_mercado_macro():
    """Adenda 29/30 (a pedido del equipo): vista de mercado AGREGADA -- a diferencia del resto del
    tablero (que siempre corta por tecnología y/o por equipo), acá se ve la industria entera (7
    equipos, 4 tecnologías) sumada, para responder "¿el mercado crece por volumen o por precio?" sin
    ese detalle. Vivía como 4ta pestaña de seccion_mercado() (Adenda 29); se muda acá, como 2da
    pestaña de Resultados, a pedido del equipo (Adenda 30)."""
    st.caption('Los 7 equipos y las 4 tecnologías sumados -- para ver si el negocio crece por '
               'volumen o por precio, sin el detalle de tecnología/equipo de la pestaña "Resumen" '
               'ni de la sección Mercado.')
    paises_macro = ['EE.UU.', 'Asia', 'Europa']

    def _industria_dinamica_mercado(paises_incluir):
        """Ventas efectivas, Demanda Total (=Ventas+Demanda insatisfecha) y Valoración de toda la
        industria (7 equipos, todas las tecnologías), sumados sobre `paises_incluir`, por ronda.

        Ventas/Demanda: 'Ventas, miles unidades' / 'Demanda, miles unidades' de 'Informe de mercado,
        {país}' -- Demanda YA es "lo que el mercado hubiera comprado" (Demanda >= Ventas por
        construcción; Demanda − Ventas = demanda potencial insatisfecha, terminología del manual
        CESIM), así que no hace falta recalcularla sumando un componente de insatisfecha aparte.

        Valoración: NO se calcula como 'Precio de venta' nativo × Volumen -- el Precio de venta que
        publica CESIM está en USD solo en EE.UU.; en Asia está en RMB y en Europa en EUR (ver
        Metrica 'Precio de venta, RMB' / 'Precio de venta, EUR' en cesim_parser). Convertir eso a USD
        acá asumiría un tipo de cambio que el RDOS no publica -- justo lo que se evita en toda la app
        (ver fila3_resultados_ingresos, que por eso muestra el waterfall de Ingresos en moneda
        nativa, sin convertir). En cambio se usa 'Ingresos por ventas' (Estado='Cuenta de resultados,
        miles USD, {país}', Sección 'Ingresos por ventas') -- CESIM YA reporta esa cifra en USD para
        las 3 regiones (el título de la hoja lo dice, 'miles USD', incluso para Asia/Europa: es la
        cifra que el propio simulador usa para consolidar el P&L Global). Verificado contra los RDOS
        reales de CADIZ (R0-R3): sumar 'de mercados' (EE.UU./Asia, único componente que es venta
        real a consumidor) + 'Ingresos por ventas' (Europa, que al no tener fábrica propia no tiene
        el desglose 'de mercados' / 'de transferencias internas') reconcilia EXACTO con 'Cuenta de
        resultados, miles USD, Global' de cada equipo/ronda. Se excluye 'de transferencias internas'
        (envíos entre áreas productivas, no venta a consumidor final) y el subtotal 'Beneficio de
        Ventas Totales' (= 'de mercados' + 'de transferencias internas' exacto -- un artefacto de la
        celda combinada del RDOS al parsear, no una tercera cifra). Equivale a "Volumen × Precio
        promedio" (el promedio ponderado por Ventas queda implícito: Valoración / Volumen)."""
        ven = df[(df['Estado'].isin([f'Informe de mercado, {p}' for p in paises_incluir])) &
                 (df['Metrica'] == 'Ventas, miles unidades')].copy()
        dem = df[(df['Estado'].isin([f'Informe de mercado, {p}' for p in paises_incluir])) &
                 (df['Metrica'] == 'Demanda, miles unidades')].copy()
        ven['Valor'] = num(ven['Valor']); dem['Valor'] = num(dem['Valor'])
        ven_r = ven.groupby(['Ronda', 'Ronda_Orden'], as_index=False)['Valor'].sum().rename(columns={'Valor': 'Ventas'})
        dem_r = dem.groupby(['Ronda', 'Ronda_Orden'], as_index=False)['Valor'].sum().rename(columns={'Valor': 'DemandaTotal'})
        val = df[(df['Estado'].isin([f'Cuenta de resultados, miles USD, {p}' for p in paises_incluir])) &
                 (df['Seccion'] == 'Ingresos por ventas') &
                 (df['Metrica'].isin(['de mercados', 'Ingresos por ventas']))].copy()
        val['Valor'] = num(val['Valor'])
        val_r = val.groupby(['Ronda', 'Ronda_Orden'], as_index=False)['Valor'].sum().rename(columns={'Valor': 'Valoracion'})
        # Bug de escala (x1000 de "miles USD") corregido de forma CENTRALIZADA en
        # cesim_parser._corregir_escala_monetaria() (Adenda 32) -- 'Valor' ya llega en USD absoluto,
        # sin necesidad de ningún ajuste puntual acá.
        out = ven_r.merge(dem_r, on=['Ronda', 'Ronda_Orden'], how='outer').merge(val_r, on=['Ronda', 'Ronda_Orden'], how='outer')
        return out.sort_values('Ronda_Orden')

    def _chart_dinamica_mercado(serie, titulo_sufijo):
        """Un solo gráfico de doble eje Y (a pedido explícito del equipo -- mismo criterio/excepción
        ya documentado en chart_dos_metricas_apiladas, que reintroduce a propósito el patrón de
        doble eje que el resto de la app evita): eje izquierdo = unidades (Ventas efectivas +
        Demanda Total, punteada), eje derecho = Valoración en USD. Curvas suaves (spline) en las 3
        series, a pedido del equipo."""
        d = serie.dropna(subset=['Ventas', 'DemandaTotal', 'Valoracion'], how='all')
        if d.empty:
            return st.info(f'Sin datos para graficar "Dinámica de Mercado — {titulo_sufijo}".')
        spline = dict(shape='spline', smoothing=1.3)
        fig = go.Figure()
        txt_ven = _hover_yoy_textos(d['Ronda'], d['Ventas'], fmt_fn=lambda v: f'{v:,.0f} mil u.')
        txt_dem = _hover_yoy_textos(d['Ronda'], d['DemandaTotal'], fmt_fn=lambda v: f'{v:,.0f} mil u.')
        txt_val = _hover_yoy_textos(d['Ronda'], d['Valoracion'], fmt_fn=lambda v: f'${format_num(v)} USD')
        fig.add_trace(go.Scatter(x=d['Ronda'], y=d['Ventas'], name='Ventas efectivas de la industria',
                                  mode='lines+markers', line=dict(color=COLOR_METRICA['eficiencia'], width=3, **spline),
                                  marker=dict(size=6), yaxis='y1', text=txt_ven,
                                  hovertemplate='<b>%{x}</b> — Ventas: %{text}<extra></extra>'))
        fig.add_trace(go.Scatter(x=d['Ronda'], y=d['DemandaTotal'], name='Demanda Total (Ventas + Insatisfecha)',
                                  mode='lines+markers', line=dict(color=COLOR_METRICA['riesgo'], width=2, dash='dot', **spline),
                                  marker=dict(size=5), yaxis='y1', text=txt_dem,
                                  hovertemplate='<b>%{x}</b> — Demanda Total: %{text}<extra></extra>'))
        fig.add_trace(go.Scatter(x=d['Ronda'], y=d['Valoracion'], name='Valoración total de mercado, USD',
                                  mode='lines+markers', line=dict(color=COLOR_METRICA['dinero'], width=3, **spline),
                                  marker=dict(size=6), yaxis='y2', text=txt_val,
                                  hovertemplate='<b>%{x}</b> — Valoración: %{text}<extra></extra>'))
        fig.update_layout(
            title=f'Dinámica de Mercado — {titulo_sufijo}',
            xaxis=dict(categoryorder='array', categoryarray=RONDAS_ORDENADAS),
            yaxis=dict(title='Miles de unidades', side='left', rangemode='tozero', showgrid=False),
            yaxis2=dict(title='Valoración, USD', side='right', overlaying='y', showgrid=False, rangemode='tozero'),
            legend=dict(orientation='h', yanchor='top', y=-0.25, xanchor='center', x=0.5))
        mostrar(fig)
        st.caption('La brecha entre "Ventas efectivas" y "Demanda Total" (ambas en el eje izquierdo) '
                   'ES la demanda insatisfecha del año -- no se grafica aparte para no duplicar el '
                   'mismo dato dos veces.')

    st.markdown('###### Evolución Global — toda la industria')
    _chart_dinamica_mercado(_industria_dinamica_mercado(paises_macro), 'Global')

    st.divider()
    st.markdown('###### Evolución Regional')
    pais_macro_sel = st.selectbox('Mercado', paises_macro, key='sel_mercado_macro_pais')
    _chart_dinamica_mercado(_industria_dinamica_mercado([pais_macro_sel]), pais_macro_sel)

    st.divider()
    st.markdown('###### Dinámica de Mercado por Tecnología')
    st.caption('Mismo par Demanda Total / Valoración de arriba, pero desagregado por cada '
               'tecnología con demanda real registrada (>0, en cualquier año) en el mercado elegido '
               '-- Tec 4 no aparece todavía porque, al día de hoy, ningún equipo vendió en esa '
               'tecnología (línea sólida = volumen, punteada = valorización).')
    COLOR_TECH_MERCADO = dict(zip(_TECNOLOGIAS_GAP, MUTED_SIN_MARRON))

    def _industria_dinamica_mercado_tech(pais_scope):
        """Igual que _industria_dinamica_mercado(), pero desagregado por tecnología (Seccion) en vez
        de sumar toda la industria. Ingresos por tecnología (para derivar el precio promedio y de ahí
        la Valoración) NO existen a nivel 'Cuenta de resultados' (esa hoja ya viene sumada por
        tecnología) -- CESIM sí los publica en 'Desglose de margen por tec, miles USD, {país}' ->
        Metrica='Ingresos por ventas', Seccion=tecnología. Verificado contra RDOS reales de CADIZ
        (R0-R3, EE.UU./Asia/Europa): sumado sobre tecnologías, reconcilia EXACTO con la cifra de
        Ingresos a nivel compañía ya validada en _industria_dinamica_mercado (ver esa nota) -- así que
        es la misma fuente 100% real, ya en USD, solo que sin colapsar la dimensión tecnología."""
        paises = ['EE.UU.', 'Asia', 'Europa'] if pais_scope == 'Global' else [pais_scope]
        ing = df[(df['Estado'].isin([f'Desglose de margen por tec, miles USD, {p}' for p in paises])) &
                 (df['Metrica'] == 'Ingresos por ventas') & (df['Seccion'].isin(_TECNOLOGIAS_GAP))].copy()
        ven = df[(df['Estado'].isin([f'Informe de mercado, {p}' for p in paises])) &
                 (df['Metrica'] == 'Ventas, miles unidades') & (df['Seccion'].isin(_TECNOLOGIAS_GAP))].copy()
        dem = df[(df['Estado'].isin([f'Informe de mercado, {p}' for p in paises])) &
                 (df['Metrica'] == 'Demanda, miles unidades') & (df['Seccion'].isin(_TECNOLOGIAS_GAP))].copy()
        for d_ in (ing, ven, dem):
            d_['Valor'] = num(d_['Valor'])
        clave = ['Ronda', 'Ronda_Orden', 'Seccion']
        ing_r = ing.groupby(clave, as_index=False)['Valor'].sum().rename(columns={'Seccion': 'Tecnología', 'Valor': 'Ingresos'})
        ven_r = ven.groupby(clave, as_index=False)['Valor'].sum().rename(columns={'Seccion': 'Tecnología', 'Valor': 'Ventas'})
        dem_r = dem.groupby(clave, as_index=False)['Valor'].sum().rename(columns={'Seccion': 'Tecnología', 'Valor': 'DemandaTotal'})
        out = ven_r.merge(dem_r, on=['Ronda', 'Ronda_Orden', 'Tecnología'], how='outer') \
                    .merge(ing_r, on=['Ronda', 'Ronda_Orden', 'Tecnología'], how='outer')
        # Supuesto de modelo (Categoría 3, NO regla CESIM verificada): CESIM no publica un "precio
        # promedio" ni una "valoración" de la demanda insatisfecha por tecnología -- se deriva
        # PrecioPromedio = Ingresos reales / Ventas reales (100% real) y se lo EXTRAPOLA a toda la
        # Demanda Total (Ventas + insatisfecha) para estimar cuánto "valdría" capturar esa demanda al
        # precio promedio ya realizado. Asume que la demanda no atendida se hubiera vendido al mismo
        # precio promedio que la vendida -- una hipótesis razonable pero no un hecho observado.
        # Adenda 32 (escala centralizada en cesim_parser): 'Ingresos' (Estado "miles USD") ya llega
        # absoluto -- pero 'Ventas'/'DemandaTotal' (Estado "miles unidades", NO tocado por esa
        # corrección, que es solo monetaria) siguen en miles, a propósito, igual que en el resto de la
        # app. Dividir Ingresos_absoluto / Ventas_miles da un precio 1000x MÁS GRANDE de lo real (el
        # denominador está 1000x más chico) -- hay que volver a bajarlo /1000 para tener USD/u.
        # absoluto real (verificado: así coincide en orden de magnitud con 'Precio de venta' nativo de
        # CESIM, ej. ~$22.500/u. EE.UU. Tec 1 R2, no ~$22.500.000/u.).
        out['PrecioPromedio'] = (out['Ingresos'] / out['Ventas'].replace(0, pd.NA)) / 1000.0
        # Con PrecioPromedio ya absoluto y DemandaTotal todavía en miles, el producto queda en "miles
        # de USD" -- ese x1000 sigue haciendo falta acá (es el mismo que antes, no lo introduce esta
        # corrección: viene de multiplicar un precio absoluto por un volumen en miles).
        out['Valoracion'] = out['PrecioPromedio'] * out['DemandaTotal'] * 1000
        return out.sort_values('Ronda_Orden')

    pais_tech_sel = st.selectbox('Mercado', ['Global'] + paises_macro, key='sel_mercado_tech_dinamica')
    serie_tech = _industria_dinamica_mercado_tech(pais_tech_sel)
    # BUG REPORTADO Y CONFIRMADO (Mati, con captura de este gráfico: "Dinámica de Mercado por
    # Tecnología -- Asia", Tec 3 no aparecía): la versión anterior recortaba a top2_tech[:2],
    # las 2 tecnologías con MÁS Demanda del año en foco -- en Asia, Tec 3 SÍ tiene demanda real
    # desde R4 (confirmado contra RDOS), pero en volumen absoluto queda 3° detrás de Tec 1 e
    # Tec 2, así que el cap de 2 lo excluía siempre, aunque tuviera datos reales. Fix: se muestran
    # TODAS las tecnologías con demanda real (>0) en CUALQUIER año para el mercado elegido -- mismo
    # criterio "activa" que ya usaba el fallback de abajo (y que usa la Curva de Aprendizaje), ahora
    # aplicado siempre y no solo cuando el año en foco no alcanza a distinguir 2. Con los datos
    # reales de este repo (R0-R6) esto muestra 3 tecnologías (Tec 1/Tec 2/Tec 3) -- nunca
    # Tec 4, que sigue en 0 unidades en los 3 mercados.
    tech_mostrar = [t for t in _TECNOLOGIAS_GAP if (serie_tech[serie_tech['Tecnología'] == t]['DemandaTotal'].fillna(0) > 0).any()]
    if not tech_mostrar:
        st.info(f'Sin datos de demanda por tecnología para {pais_tech_sel}.')
    else:
        spline = dict(shape='spline', smoothing=1.3)
        fig_tech = go.Figure()
        for tech in tech_mostrar:
            d_t = serie_tech[serie_tech['Tecnología'] == tech].dropna(subset=['DemandaTotal', 'Valoracion'], how='all').sort_values('Ronda_Orden')
            color_t = COLOR_TECH_MERCADO.get(tech, MUTED_SIN_MARRON[0])
            txt_dem_t = _hover_yoy_textos(d_t['Ronda'], d_t['DemandaTotal'], fmt_fn=lambda v: f'{v:,.0f} mil u.')
            txt_val_t = _hover_yoy_textos(d_t['Ronda'], d_t['Valoracion'], fmt_fn=lambda v: f'${format_num(v)} USD')
            fig_tech.add_trace(go.Scatter(x=d_t['Ronda'], y=d_t['DemandaTotal'], name=f'{tech} — Demanda Total',
                                           mode='lines+markers', line=dict(color=color_t, width=3, **spline),
                                           marker=dict(size=6), yaxis='y1', text=txt_dem_t,
                                           hovertemplate=f'<b>%{{x}}</b> — {tech} Demanda: %{{text}}<extra></extra>'))
            fig_tech.add_trace(go.Scatter(x=d_t['Ronda'], y=d_t['Valoracion'], name=f'{tech} — Valoración',
                                           mode='lines+markers', line=dict(color=color_t, width=2, dash='dash', **spline),
                                           marker=dict(size=5), yaxis='y2', text=txt_val_t,
                                           hovertemplate=f'<b>%{{x}}</b> — {tech} Valoración: %{{text}}<extra></extra>'))
        fig_tech.update_layout(
            title=f'Dinámica de Mercado por Tecnología — {pais_tech_sel}',
            xaxis=dict(categoryorder='array', categoryarray=RONDAS_ORDENADAS),
            yaxis=dict(title='Miles de unidades', side='left', rangemode='tozero', showgrid=False),
            yaxis2=dict(title='Valoración, USD', side='right', overlaying='y', showgrid=False, rangemode='tozero'),
            legend=dict(orientation='h', yanchor='top', y=-0.3, xanchor='center', x=0.5))
        mostrar(fig_tech)
        st.caption('Valoración = Precio promedio real (Ingresos ÷ Ventas, por tecnología) × Demanda '
                   'Total -- supuesto de modelo, no una cifra que CESIM publique: extrapola el precio '
                   'realmente cobrado a la demanda que hoy queda insatisfecha.')

    st.divider()
    st.markdown(f'###### Mix de Demanda por Región — {ronda_snapshot}')
    st.caption('Participación % de cada tecnología sobre la Demanda total (7 equipos sumados) de '
               'cada mercado, en el año seleccionado.')
    # category_orders fija el orden de categoría->color de Plotly (mismo criterio que ya usa el
    # gráfico de Balance ESG más abajo, con category_orders={'Empresa': orden_emp}) -- sin esto, una
    # tecnología ausente en un país (ej. Tec 3 todavía sin ventas) corre el orden de aparición y
    # cada donut le asigna un color de MUTED_SIN_MARRON distinto a la MISMA tecnología (mismo bug de
    # fondo que ya se corrigió en 'Mix tecnológico', Adenda 25 -- acá se previene desde el vamos).
    col1, col2, col3 = st.columns(3)
    for col, pais_mix in zip([col1, col2, col3], paises_macro):
        with col:
            d_mix = df[(df['Estado'] == f'Informe de mercado, {pais_mix}') &
                       (df['Metrica'] == 'Demanda, miles unidades') & (df['Ronda'] == ronda_snapshot)].copy()
            d_mix['Valor'] = num(d_mix['Valor'])
            por_tech = d_mix.groupby('Seccion', as_index=False)['Valor'].sum().rename(columns={'Seccion': 'Tecnología', 'Valor': 'Demanda'})
            por_tech = por_tech[por_tech['Demanda'] > 0]
            if por_tech.empty:
                st.info(f'Sin datos en {pais_mix}.')
                continue
            fig_donut = px.pie(por_tech, names='Tecnología', values='Demanda', hole=0.5,
                                category_orders={'Tecnología': _TECNOLOGIAS_GAP},
                                color_discrete_sequence=MUTED_SIN_MARRON, title=pais_mix)
            mostrar(fig_donut)
# =================================================================
# SECCIÓN 2 — MERCADO
# =================================================================
def seccion_mercado():
    # Adenda 29 (a pedido del equipo, "Control de Gestión" centralizado): se elimina la sub-pestaña
    # 'Comparativa Plan vs. Real' -- ver mismo comentario en seccion_resultado(). El desvío de cuota
    # (panel_comparativa_plan_real + fila3_mercado_cuota_objetivo) pasa al Nivel 2 de 'Control de
    # Gestión'. Adenda 30 (a pedido del equipo, "reubicar la vista de Mercado"): 'Evolución Macro de
    # la Industria' -- que en la Adenda 29 había entrado ACÁ como 4ta pestaña -- se muda a una
    # sub-pestaña 'Mercado' dentro de seccion_resultado() (junto a 'Resumen'); ver
    # _seccion_resultado_mercado_macro() más abajo. Esta sección vuelve a sus 3 pestañas originales.
    tab_pos, tab_pan, tab_evo = st.tabs(['Posicionamiento', 'Panorama Competitivo', 'Evolución'])
    tecnologias = ['Tec 1', 'Tec 2', 'Tec 3', 'Tec 4']

    with tab_pos:
        c1, c2 = st.columns(2)
        pais_sel = c1.selectbox('Mercado', ['EE.UU.', 'Asia', 'Europa'], key='sel_mercado_pais')
        tech_sel = c2.selectbox('Tecnología', tecnologias, key='sel_mercado_tech')
        estado_pais = f'Informe de mercado, {pais_sel}'
        sub = df[(df['Estado'] == estado_pais) & (df['Seccion'] == tech_sel) & (df['Ronda'] == ronda_snapshot)]

        ventas_data = [{'Empresa': emp, 'Volumen': valor_fuzzy(sub[sub['Empresa'] == emp], 'Ventas')} for emp in COMPANIES]
        vol_df = pd.DataFrame(ventas_data).dropna()

        # Adenda 22 (a pedido del equipo): antes había DOS scatter separados (Precio vs Volumen,
        # Características vs Volumen) -- se reemplazan por UNA sola Matriz de Valor con Precio y
        # Características en los dos ejes y el Volumen como tamaño de burbuja, para ver la
        # propuesta de valor completa de cada equipo de un vistazo.
        st.subheader('Matriz de Valor')
        st.caption('Precio vs. Características, tamaño de burbuja = Volumen de ventas. Arriba a la derecha = propuesta '
                   'de valor alta (mucho producto, precio alto); abajo a la izquierda = jugador de precio bajo / pocas '
                   'características. Sirve para ver en qué cuadrante de la propuesta de valor compite cada equipo.')
        precio_df = sub[sub['Metrica'].str.contains(r'^Precio', case=False, na=False)][['Empresa', 'Valor']].rename(columns={'Valor': 'Precio'})
        carac_df = sub[sub['Metrica'].str.contains(r'^Cantidad de características', case=False, na=False)][['Empresa', 'Valor']].rename(columns={'Valor': 'Características'})
        if not vol_df.empty and not precio_df.empty and not carac_df.empty:
            mv = precio_df.merge(carac_df, on='Empresa').merge(vol_df, on='Empresa').dropna()
            mv['Precio'] = num(mv['Precio']); mv['Características'] = num(mv['Características'])
            mv = mv[mv['Volumen'] > 0]
            if not mv.empty:
                fig_mv = px.scatter(mv, x='Precio', y='Características', size='Volumen', color='Empresa',
                                     color_discrete_map=COLOR_MAP, text='Empresa',
                                     title=f'Matriz de Valor — {tech_sel}, {pais_sel}, {ronda_snapshot}')
                fig_mv.update_traces(textposition='top center', showlegend=False)
                linea_media(fig_mv, mv['Precio'].mean(), eje='x', etiqueta='Precio Prom')
                linea_media(fig_mv, mv['Características'].mean(), eje='y', etiqueta='Caract. Prom')
                mostrar(fig_mv)
            else:
                st.info('Sin volumen de ventas positivo para graficar en esta combinación.')
        else:
            st.info('Sin datos suficientes de Precio/Características/Volumen para esta combinación.')

        st.divider()
        # Adenda 22 (a pedido del equipo): reemplaza el scatter "Eficiencia Comercial" (Marketing
        # vs. Volumen) por la matriz "Trampa del Volumen" (Margen de Contribución Unitario vs.
        # Volume Market Share), pensada para detectar equipos que ganan participación sacrificando
        # rentabilidad por unidad.
        st.subheader('"Trampa del Volumen" — Margen vs. Participación')
        st.caption('Eje X = Volume Market Share (% de las unidades vendidas de esta tecnología en este mercado que son de '
                   'cada equipo, dato que publica CESIM). Eje Y = Margen de Contribución Unitario (USD/unidad) = Margen de '
                   'contribución total de la tecnología / unidades vendidas. Abajo a la derecha = mucho volumen pero poco '
                   'margen por unidad — la "trampa del volumen". Arriba a la izquierda = poco volumen pero alto margen unitario.')
        share_tv = df[(df['Estado'] == estado_pais) & (df['Seccion'] == f'{pais_sel} cuotas de mercado, %') &
                      (df['Metrica'] == tech_sel) & (df['Ronda'] == ronda_snapshot)][['Empresa', 'Valor']].rename(columns={'Valor': 'Share'}).copy()
        share_tv['Share'] = num(share_tv['Share'])
        margen_tot_tv = df[(df['Estado'] == f'Desglose de margen por tec, miles USD, {pais_sel}') & (df['Seccion'] == tech_sel) &
                           (df['Metrica'] == 'Margen de contribución') & (df['Ronda'] == ronda_snapshot)][['Empresa', 'Valor']].rename(columns={'Valor': 'MargenTotal'}).copy()
        margen_tot_tv['MargenTotal'] = num(margen_tot_tv['MargenTotal'])
        ventas_tv = df[(df['Estado'] == estado_pais) & (df['Seccion'] == tech_sel) &
                       (df['Metrica'] == 'Ventas, miles unidades') & (df['Ronda'] == ronda_snapshot)][['Empresa', 'Valor']].rename(columns={'Valor': 'VentasMiles'}).copy()
        ventas_tv['VentasMiles'] = num(ventas_tv['VentasMiles'])
        tv = share_tv.merge(margen_tot_tv, on='Empresa').merge(ventas_tv, on='Empresa').dropna()
        tv = tv[tv['VentasMiles'] > 0]
        if not tv.empty:
            # Adenda 32 (escala centralizada en cesim_parser): 'MargenTotal' (Estado "miles USD") ya
            # llega absoluto; 'VentasMiles' (Estado "miles unidades", no monetario) sigue en miles --
            # hay que llevarlo a unidades absolutas antes de dividir.
            tv['MargenUnitario'] = tv['MargenTotal'] / (tv['VentasMiles'] * 1000.0)  # USD absoluto / u. absolutas
            fig_tv = px.scatter(tv, x='Share', y='MargenUnitario', color='Empresa', color_discrete_map=COLOR_MAP,
                                 text='Empresa', title=f'Margen Unitario vs. Share — {tech_sel}, {pais_sel}, {ronda_snapshot}')
            fig_tv.update_traces(textposition='top center', showlegend=False, marker=dict(size=14))
            fig_tv.update_layout(xaxis_title='Volume Market Share, %', yaxis_title='Margen de Contribución Unitario, USD/u.')
            linea_media(fig_tv, tv['Share'].mean(), eje='x', etiqueta='Share Prom')
            linea_media(fig_tv, tv['MargenUnitario'].mean(), eje='y', etiqueta='Margen Prom')
            mostrar(fig_tv)
        else:
            st.info('Sin datos suficientes de Share/Margen/Ventas para esta combinación.')

        st.divider()
        st.subheader('Share of Voice (SOV) vs. Share of Market (SOM)')
        st.caption(f'{tech_sel}, {pais_sel}, {ronda_snapshot}. SOV = Promoción del equipo / Promoción total de la '
                   'tecnología (los 7 equipos). SOM = cuota de mercado real que publica CESIM para esa tecnología '
                   '(Ventas del equipo / Ventas totales DE ESA TECNOLOGÍA, no del mercado completo) — mismo grano '
                   'que el SOV, para que la comparación sea de manzanas con manzanas.')
        promo_sov = df[(df['Estado'] == f'Desglose de margen por tec, miles USD, {pais_sel}') & (df['Seccion'] == tech_sel) &
                       (df['Metrica'] == 'Promoción') & (df['Ronda'] == ronda_snapshot)].copy()
        promo_sov['Valor'] = num(promo_sov['Valor']).abs()
        som_sov = df[(df['Estado'] == f'Informe de mercado, {pais_sel}') & (df['Seccion'] == f'{pais_sel} cuotas de mercado, %') &
                     (df['Metrica'] == tech_sel) & (df['Ronda'] == ronda_snapshot)].copy()
        som_sov['Valor'] = num(som_sov['Valor'])
        promo_total_sov = promo_sov['Valor'].sum()
        if promo_total_sov > 0 and not som_sov.empty:
            sov_df = promo_sov[['Empresa', 'Valor']].rename(columns={'Valor': 'Promo'})
            sov_df['SOV'] = sov_df['Promo'] / promo_total_sov * 100
            som_df = som_sov[['Empresa', 'Valor']].rename(columns={'Valor': 'SOM'})
            comp_sov = sov_df.merge(som_df, on='Empresa', how='outer')
            comp_sov_long = comp_sov.melt(id_vars='Empresa', value_vars=['SOV', 'SOM'], var_name='Indicador', value_name='Pct').dropna(subset=['Pct'])
            # Adenda 25 (pedido explícito del equipo, citado como ejemplo): se saca el marrón de acá.
            fig_sov = px.bar(comp_sov_long, x='Empresa', y='Pct', color='Indicador', barmode='group',
                              color_discrete_map={'SOV': MUTED_PALETTE[0], 'SOM': COLOR_CADIZ},
                              text=comp_sov_long['Pct'].apply(lambda v: f'{v:,.1f}%'),
                              title=f'SOV vs. SOM — {tech_sel}, {pais_sel}, {ronda_snapshot}')
            fig_sov.update_traces(textposition='outside', cliponaxis=False)
            fig_sov.update_layout(yaxis_title='%')
            mostrar(fig_sov)
        else:
            st.info('Sin datos suficientes de Promoción o Cuota de mercado para esta combinación.')

        st.divider()
        st.subheader('Inversión en Publicidad y Enfoque — Evolución año a año')
        st.caption(f'{tech_sel}, {pais_sel} (todos los años). Pasá el cursor sobre cada punto para ver el presupuesto de promoción, la variación % contra el año anterior y qué Enfoque de marketing eligió cada equipo en ese año.')
        promo_evo = df_all[(df_all['Estado'] == f'Desglose de margen por tec, miles USD, {pais_sel}') &
                           (df_all['Seccion'] == tech_sel) & (df_all['Metrica'] == 'Promoción')].copy()
        enf_evo = df_all[(df_all['Estado'] == estado_pais) & (df_all['Seccion'] == tech_sel) &
                         (df_all['Metrica'] == 'Enfoque de la estrategia de marketing')].copy()
        promo_evo['Valor'] = num(promo_evo['Valor']).abs()
        promo_evo = promo_evo.dropna(subset=['Valor'])
        if not promo_evo.empty:
            enf_map = enf_evo[['Ronda', 'Empresa', 'Valor']].rename(columns={'Valor': 'Enfoque'})
            mkt_evo = promo_evo.merge(enf_map, on=['Ronda', 'Empresa'], how='left').sort_values('Ronda_Orden')
            fig_mkt_evo = go.Figure()
            for emp in COMPANIES:
                d_e = mkt_evo[mkt_evo['Empresa'] == emp].sort_values('Ronda_Orden').copy()
                if d_e.empty or (d_e['Valor'].fillna(0) == 0).all():
                    continue
                es_ulti = emp == MY_COMPANY
                d_e['Valor_Prev'] = d_e['Valor'].shift(1)
                d_e['YoY'] = (d_e['Valor'] - d_e['Valor_Prev']) / d_e['Valor_Prev'].replace(0, np.nan).abs() * 100
                textos_m = []
                for (_, r_m), r_prev in zip(d_e.iterrows(), d_e['Ronda'].shift(1)):
                    v_str = f"${format_num(r_m['Valor'])}"
                    if pd.notna(r_m['YoY']) and isinstance(r_prev, str):
                        v_str += f" ({r_m['YoY']:+.1f}% vs. {r_prev.replace('Año ', 'A')})"
                    enf_str = str(r_m['Enfoque']).strip() if pd.notna(r_m['Enfoque']) and str(r_m['Enfoque']).strip() != '' else 'Sin enfoque'
                    textos_m.append(f"{v_str}<br>Enfoque: <b>{enf_str}</b>")
                fig_mkt_evo.add_trace(go.Scatter(
                    x=d_e['Ronda'], y=d_e['Valor'], mode='lines+markers', name=emp,
                    line=dict(color=COLOR_MAP[emp], width=3 if es_ulti else 1.5),
                    marker=dict(size=6 if es_ulti else 4),
                    opacity=1.0 if es_ulti else 0.55,
                    text=textos_m, hovertemplate=f'<b>%{{x}}</b> — {emp}<br>%{{text}}<extra></extra>'))
            fig_mkt_evo.update_layout(
                title=f'Promoción y Enfoque año a año — {tech_sel}, {pais_sel}',
                yaxis_title='Promoción (USD)',
                xaxis=dict(categoryorder='array', categoryarray=RONDAS_ORDENADAS))
            mostrar(fig_mkt_evo)
        else:
            st.info('Sin inversión en promoción registrada para esta tecnología/mercado.')

    with tab_pan:
        c1p, c2p = st.columns(2)
        pais_pan = c1p.selectbox('Mercado', ['EE.UU.', 'Asia', 'Europa'], key='sel_pan_pais')
        tech_pan = c2p.selectbox('Tecnología', tecnologias, key='sel_pan_tech')
        estado_pan = f'Informe de mercado, {pais_pan}'

        st.markdown('**Enfoque de estrategia de marketing — los 7 equipos**')
        est = df[(df['Estado'] == estado_pan) & (df['Seccion'] == tech_pan) &
                 (df['Metrica'] == 'Enfoque de la estrategia de marketing') & (df['Ronda'] == ronda_snapshot)][['Empresa', 'Valor']]
        if not est.empty:
            estrategias = ['Precio bajo', 'Equilibrado', 'Marca', 'Características', 'Precio alto']
            # Mapa de color FIJO por estrategia (antes usaba el color automático de Plotly, que
            # reasigna colores según el orden de aparición en cada gráfico — por eso "Marca"
            # salía de un color acá y de otro allá).
            # 5 categorías genéricas (no hay identidad ni sentimiento acá) -- las 5 usan tonos muted.
            # Adenda 25: se saca el marrón (MUTED_PALETTE[1]) -- no pasa a lila para no sugerir que
            # una de las 5 estrategias "es CADIZ" (esto es la estrategia de LOS 7 equipos a la vez).
            # Fix "ya casi": también se saca MUTED_PALETTE[5] (casi idéntico a [0]) y MUTED_PALETTE[4]
            # (kaki, a solo ~15 de distancia RGB del marrón baneado) -- mismo set de 5 tonos separados
            # que MUTED_SIN_MARRON.
            estrategia_colores = dict(zip(estrategias, MUTED_SIN_MARRON))
            est = est.copy().sort_values('Empresa')
            # Antes era un gráfico de barras todas de la misma altura: el eje Y no codificaba nada
            # y el texto iba rotado adentro de la barra. Peor todavía, px.bar parte el dataframe en
            # un trace por estrategia y el update_traces le pasaba la columna ENTERA a cada trace,
            # así que el texto de la barra no correspondía a su color. Con chips no hay ambigüedad
            # posible: el color y el texto salen de la misma fila.
            with st.container(border=True):
                st.markdown(f'**Estrategia elegida — {tech_pan}, {pais_pan}, {ronda_snapshot}**')
                chips = []
                for _, fila in est.iterrows():
                    color = estrategia_colores.get(fila['Valor'], MUTED_PALETTE[0])
                    clase = 'chip-estrategia destacado' if fila['Empresa'] == MY_COMPANY else 'chip-estrategia'
                    chips.append(f'<span class="{clase}" style="background-color:{color}">'
                                 f'{fila["Empresa"]} · {fila["Valor"]}</span>')
                st.markdown(' '.join(chips), unsafe_allow_html=True)
        else:
            st.info('Sin datos de estrategia para esta combinación.')

        st.divider()
        st.markdown('**Mix tecnológico**')
        col_mix1, col_mix2 = st.columns(2)
        mix_rows = []
        for tech in tecnologias:
            v = df[(df['Estado'] == estado_pan) & (df['Seccion'] == tech) & (df['Metrica'] == 'Ventas, miles unidades') & (df['Ronda'] == ronda_snapshot)]['Valor']
            mix_rows.append({'Tecnología': tech, 'Ventas': num(v).sum()})
        mix_df = pd.DataFrame(mix_rows)
        mix_df = mix_df[mix_df['Ventas'] > 0]
        with col_mix1:
            if not mix_df.empty:
                # Adenda 25: MUTED_SIN_MARRON en vez de MUTED_PALETTE -- acá se detectó que el marrón
                # SÍ se colaba (Plotly lo asigna por orden de aparición, no por nombre de tecnología).
                fig_mix = px.pie(mix_df, names='Tecnología', values='Ventas', hole=0.5,
                                  color_discrete_sequence=MUTED_SIN_MARRON,  # 4 tecnologías, genérico
                                  title=f'Toda la industria — {pais_pan}, {ronda_snapshot}')
                mostrar(fig_mix)
            else:
                st.info('Sin ventas registradas en esta combinación.')
        with col_mix2:
            mix_emp_rows = []
            for tech in tecnologias:
                sub_tech = df[(df['Estado'] == estado_pan) & (df['Seccion'] == tech) & (df['Metrica'] == 'Ventas, miles unidades') & (df['Ronda'] == ronda_snapshot)][['Empresa', 'Valor']]
                sub_tech['Valor'] = num(sub_tech['Valor'])
                for _, r in sub_tech.iterrows():
                    mix_emp_rows.append({'Empresa': r['Empresa'], 'Tecnología': tech, 'Ventas': r['Valor']})
            mix_emp_df = pd.DataFrame(mix_emp_rows).dropna(subset=['Ventas'])
            mix_emp_df = mix_emp_df[mix_emp_df['Ventas'] > 0]
            if not mix_emp_df.empty:
                totales = mix_emp_df.groupby('Empresa')['Ventas'].transform('sum')
                mix_emp_df['Pct'] = mix_emp_df['Ventas'] / totales * 100
                fig_mix_emp = px.bar(mix_emp_df, x='Empresa', y='Pct', color='Tecnología', barmode='stack',
                                      color_discrete_sequence=MUTED_SIN_MARRON,  # 4 tecnologías, genérico
                                      title=f'Por equipo — {pais_pan}, {ronda_snapshot}')
                fig_mix_emp.update_layout(yaxis_title='% de ventas')
                mostrar(fig_mix_emp)
            else:
                st.info('Sin ventas por equipo en esta combinación.')

    with tab_evo:
        pais_evo = st.selectbox('Mercado', ['EE.UU.', 'Asia', 'Europa'], key='sel_evo_pais')
        estado_evo = f'Informe de mercado, {pais_evo}'

        st.markdown('**Demanda total vs. ventas totales de la industria, por tecnología**')
        st.caption('Toda la torta del mercado (7 equipos sumados): la brecha entre demanda y ventas es oportunidad que nadie capturó. '
                   'Un panel por tecnología para ver dónde está esa brecha, en vez de un solo total que mezcla las cuatro — '
                   'se omite la tecnología que todavía no tiene ningún dato en este mercado.')
        paneles_tech = []
        for tech in tecnologias:
            dem = df[(df['Estado'] == estado_evo) & (df['Seccion'] == tech) & (df['Metrica'] == 'Demanda, miles unidades')].copy()
            ven = df[(df['Estado'] == estado_evo) & (df['Seccion'] == tech) & (df['Metrica'] == 'Ventas, miles unidades')].copy()
            dem['Valor'] = num(dem['Valor']); ven['Valor'] = num(ven['Valor'])
            dem_piv = dem.groupby(['Ronda', 'Ronda_Orden'], as_index=False)['Valor'].sum().assign(Tipo='Demanda')
            ven_piv = ven.groupby(['Ronda', 'Ronda_Orden'], as_index=False)['Valor'].sum().assign(Tipo='Ventas')
            piv = pd.concat([dem_piv, ven_piv], ignore_index=True)
            if piv.empty or piv['Valor'].fillna(0).abs().sum() == 0:
                continue  # tecnología sin ningún dato (>0) en este mercado -- no se muestra el panel
            paneles_tech.append((tech, piv.sort_values('Ronda_Orden')))
        if paneles_tech:
            cols_dv = st.columns(2)
            for i, (tech, piv) in enumerate(paneles_tech):
                fig_dv = go.Figure()
                # Adenda 25 (pedido explícito del equipo, override de la lectura anterior): "Ventas"
                # pasa a lila acá también, igual que en SOV vs. SOM -- aunque en rigor sea de los 7
                # equipos sumados y no identidad estricta de CADIZ, el equipo prefiere el lila como
                # color fijo de "Ventas" en los paneles de panorama competitivo.
                for tipo, color in [('Demanda', MUTED_PALETTE[0]), ('Ventas', COLOR_CADIZ)]:
                    d_t = piv[piv['Tipo'] == tipo]
                    fig_dv.add_trace(go.Bar(x=d_t['Ronda'], y=d_t['Valor'], name=tipo, marker_color=color))
                fig_dv.update_layout(barmode='group', title=f'{tech} — {pais_evo}')
                with cols_dv[i % 2]:
                    mostrar(fig_dv)
        else:
            st.info('Sin datos suficientes.')

        st.divider()
        st.markdown(f'**Evolución de la cuota de mercado — {pais_evo}**')
        st.caption('Los 7 equipos, ULTI resaltado.')
        share_hist = df[(df['Estado'] == estado_evo) & (df['Seccion'] == f'{pais_evo} cuotas de mercado, %') &
                         (df['Metrica'].str.strip() == 'Total')].copy()
        chart_evolucion(share_hist, f'Cuota de mercado, % — {pais_evo}')
        # NOTA: hasta acá había un gráfico "Trayectoria de {empresa}: precio y características en el
        # tiempo" (Precio, USD vs. Cantidad de características, cada uno en su propio eje Y superpuesto
        # en el mismo plano -- yaxis / yaxis2 con overlaying='y'). Era el único gráfico de doble eje Y
        # de verdad que quedaba en la app (el resto ya se había migrado a paneles apilados, ver
        # chart_dos_metricas_apiladas) -- señalado como pendiente en la Adenda 18 y sacado a pedido
        # explícito del equipo.
# =================================================================
# SECCIÓN 3 — OPERACIONES
# =================================================================
def seccion_operaciones():
    # Adenda 29 (a pedido del equipo, "Control de Gestión" centralizado): se elimina la sub-pestaña
    # 'Comparativa Plan vs. Real' -- ver mismo comentario en seccion_resultado(). El desvío fabril
    # (panel_comparativa_plan_real + fila3_operaciones_gap_fabricacion) pasa al Nivel 3 de 'Control
    # de Gestión'.
    bloque1, bloque2 = st.tabs(['Capacidad y Costos', 'Inventario y Logística'])
    with bloque1:
        cap = df[(df['Estado'] == 'Detalles de fabricación') & (df['Seccion'] == 'Capacidad empleada, %') & (df['Empresa'] == empresa_analisis) & (df['Ronda'] == ronda_snapshot) & (df['Subgrupo'].isin(['EE.UU.', 'Asia'])) & (df['Metrica'] != 'Capacidad Disponible')].copy()
        cap['Valor'] = num(cap['Valor'])
        # Cesim reporta la capacidad usada POR TECNOLOGÍA dentro de cada país (ej. Tec 1 45% +
        # Tec 2 40% en EE.UU. = 85% de la planta) — hay que sumarlas para tener el % real de la planta,
        # si no, cada tecnología aparecía como una gauge separada.
        cap = cap.dropna(subset=['Valor']).groupby('Subgrupo', as_index=False)['Valor'].sum()
        if not cap.empty:
            cols = st.columns(len(cap))
            for col, (_, row) in zip(cols, cap.iterrows()):
                titulo = row['Subgrupo'] if pd.notna(row['Subgrupo']) else 'Capacidad'
                uso = float(row['Valor'])
                libre = max(100 - uso, 0)
                # Barra segmentada, mismo lenguaje visual que "Estado de Alertas" (panel_alertas) --
                # pero acá SÍ hay un universo fijo real (100% = capacidad instalada de la planta),
                # a diferencia de las alertas, donde no existe un total fijo de "reglas evaluadas".
                # Sin semáforo: no hay un rango "sano" publicado por Cesim, así que poner umbrales
                # propios sería inventar un criterio que el reporte no da.
                with col:
                    st.markdown(
                        f'<div class="stat-segment-card">'
                        f'<div class="stat-segment-label">Capacidad empleada — {titulo}</div>'
                        f'<div class="stat-segment-value">{uso:,.1f}%</div>'
                        f'<div class="stat-segment-bar">'
                        f'<div class="seg uso" style="width:{min(uso, 100):.1f}%"></div>'
                        f'<div class="seg libre" style="width:{libre:.1f}%"></div></div>'
                        f'<div class="stat-segment-legend">'
                        f'<span class="uso"><span class="pt"></span>Usado</span>'
                        f'<span class="libre"><span class="pt"></span>Libre</span></div></div>',
                        unsafe_allow_html=True)

        st.divider()
        st.markdown('**Curva de Aprendizaje por Región y Mapa de Decisión de Producción (Dónde y Qué Producir)**')
        st.caption('Evolución año a año del costo unitario de fabricación **propia** en **EE.UU.** (izquierda) y **Asia** (derecha) — sin tercerización, ya que solo la producción propia acumula experiencia. '
                   f'Línea sólida = costo propio de {empresa_analisis}; línea punteada = mejor costo propio de la industria (con el equipo líder y su producción acumulada regional y global en el tooltip).')

        c_f1, c_f2 = st.columns([2, 1])
        tech_filtro_ca = c_f1.selectbox(
            'Enfoque de Tecnología (filtrá una tecnología puntual para ver su escala real sin distorsión)',
            ['Todas las tecnologías (Comparativa)'] + list(_TECNOLOGIAS_GAP),
            index=0, key='sel_tech_curva_aprendizaje')
        usar_log_ca = c_f2.toggle(
            'Escala logarítmica (Eje Y)',
            value=(tech_filtro_ca == 'Todas las tecnologías (Comparativa)'),
            help='Cuando mirás las 4 tecnologías juntas, la escala logarítmica permite ver con igual nitidez una caída del 50% en Tec 1 ($111 → $54) y una del 50% en Tec 4 ($539 → $255).',
            key='tog_log_curva_aprendizaje')

        ic_int_all = df[(df['Estado'] == 'Informe de costos') &
                        (df['Seccion'] == 'Costo de producción interna por unidad, USD') &
                        (df['Subgrupo'].isin(['EE.UU.', 'Asia']))].copy()
        ic_int_all['Valor'] = num(ic_int_all['Valor'])
        ic_int_all = ic_int_all.dropna(subset=['Valor'])
        ic_int_all = ic_int_all[ic_int_all['Valor'] > 0].sort_values('Ronda_Orden')

        # Grilla completa de producción interna de los 7 equipos para arrastrar el acumulado regional y global aunque un año puntual sea 0
        prod_raw_all = df[(df['Estado'] == 'Detalles de fabricación') &
                          (df['Seccion'] == 'Producción interna, miles unidades') &
                          (df['Subgrupo'].isin(['EE.UU.', 'Asia']))].copy()
        prod_raw_all['Vol'] = num(prod_raw_all['Valor']).fillna(0.0)
        rondas_unicas = df[['Ronda', 'Ronda_Orden']].drop_duplicates().sort_values('Ronda_Orden')
        grid_p = pd.MultiIndex.from_product(
            [COMPANIES, ['EE.UU.', 'Asia'], _TECNOLOGIAS_GAP, rondas_unicas['Ronda_Orden']],
            names=['Empresa', 'Subgrupo', 'Metrica', 'Ronda_Orden']
        ).to_frame().reset_index(drop=True)
        grid_p = grid_p.merge(rondas_unicas, on='Ronda_Orden', how='left')
        grid_p = grid_p.merge(prod_raw_all[['Empresa', 'Subgrupo', 'Metrica', 'Ronda_Orden', 'Vol']],
                              on=['Empresa', 'Subgrupo', 'Metrica', 'Ronda_Orden'], how='left')
        grid_p['Vol'] = grid_p['Vol'].fillna(0.0)
        grid_p = grid_p.sort_values('Ronda_Orden')
        grid_p['VolAcumReg'] = grid_p.groupby(['Empresa', 'Subgrupo', 'Metrica'])['Vol'].cumsum()
        glob_p = grid_p.groupby(['Empresa', 'Metrica', 'Ronda_Orden'], as_index=False)['Vol'].sum().rename(columns={'Vol': 'VolGlobRonda'}).sort_values('Ronda_Orden')
        glob_p['VolAcumGlob'] = glob_p.groupby(['Empresa', 'Metrica'])['VolGlobRonda'].cumsum()
        grid_p = grid_p.merge(glob_p[['Empresa', 'Metrica', 'Ronda_Orden', 'VolAcumGlob']], on=['Empresa', 'Metrica', 'Ronda_Orden'], how='left')

        ic_int_con_vol = ic_int_all.merge(
            grid_p[['Empresa', 'Subgrupo', 'Metrica', 'Ronda_Orden', 'Vol', 'VolAcumReg', 'VolAcumGlob']],
            on=['Empresa', 'Subgrupo', 'Metrica', 'Ronda_Orden'], how='left')

        techs_a_graficar = _TECNOLOGIAS_GAP if tech_filtro_ca == 'Todas las tecnologías (Comparativa)' else [tech_filtro_ca]
        COLOR_TECH_CURVA = dict(zip(_TECNOLOGIAS_GAP, MUTED_SIN_MARRON))
        col_ca_usa, col_ca_asia = st.columns(2)
        for col_reg, area_ca in [(col_ca_usa, 'EE.UU.'), (col_ca_asia, 'Asia')]:
            with col_reg:
                sub_reg_all = ic_int_con_vol[(ic_int_con_vol['Subgrupo'] == area_ca) & (ic_int_con_vol['Metrica'].isin(techs_a_graficar))]
                if sub_reg_all.empty:
                    st.info(f'Ningún equipo registró producción propia de **{tech_filtro_ca}** en **{area_ca}** todavía.')
                else:
                    fig_ca_r = go.Figure()
                    for tech in techs_a_graficar:
                        color_t = COLOR_TECH_CURVA.get(tech, COLOR_CADIZ)
                        # 1) Costo propio del equipo en foco (línea sólida gruesa)
                        g_m = sub_reg_all[(sub_reg_all['Empresa'] == empresa_analisis) &
                                           (sub_reg_all['Metrica'] == tech)].sort_values('Ronda_Orden')
                        if not g_m.empty:
                            txt_yoy = _hover_yoy_textos(g_m['Ronda'], g_m['Valor'], fmt_fn=lambda v: f'${v:,.1f} USD/u.')
                            txt_full = [
                                f"<b>{r_row['Ronda']}</b> — {tech} Propia ({empresa_analisis}, {area_ca})<br>"
                                f"Costo unitario: <b>{t_y}</b><br>"
                                f"Prod. del año en {area_ca}: {r_row['Vol']:,.0f}k u.<br>"
                                f"Prod. acumulada en {area_ca}: <b>{r_row['VolAcumReg']:,.0f}k u.</b> · Global: <b>{r_row['VolAcumGlob']:,.0f}k u.</b>"
                                for (_, r_row), t_y in zip(g_m.iterrows(), txt_yoy)
                            ]
                            fig_ca_r.add_trace(go.Scatter(
                                x=g_m['Ronda'], y=g_m['Valor'], name=f'{tech} — Propia ({empresa_analisis})',
                                mode='lines+markers', line=dict(color=color_t, width=3),
                                marker=dict(size=7), text=txt_full, hovertemplate='%{text}<extra></extra>'))

                        # 2) Mejor costo propio de la industria en esa región/ronda + volumen acumulado del equipo que logró ese mínimo
                        sub_t_ind = sub_reg_all[sub_reg_all['Metrica'] == tech].sort_values(['Ronda_Orden', 'Valor'])
                        g_ind = sub_t_ind.groupby('Ronda_Orden', as_index=False).first().sort_values('Ronda_Orden')
                        if not g_ind.empty:
                            txt_ind_yoy = _hover_yoy_textos(g_ind['Ronda'], g_ind['Valor'], fmt_fn=lambda v: f'${v:,.1f} USD/u.')
                            txt_ind_full = [
                                f"<b>{r_row['Ronda']}</b> — {tech} Mejor Propia Industria ({area_ca})<br>"
                                f"Líder de costo: <b>{r_row['Empresa']}</b> — <b>{t_y}</b><br>"
                                f"Prod. del año ({r_row['Empresa']} en {area_ca}): {r_row['Vol']:,.0f}k u.<br>"
                                f"Prod. acumulada ({r_row['Empresa']}): en {area_ca} <b>{r_row['VolAcumReg']:,.0f}k u.</b> · Global: <b>{r_row['VolAcumGlob']:,.0f}k u.</b>"
                                for (_, r_row), t_y in zip(g_ind.iterrows(), txt_ind_yoy)
                            ]
                            fig_ca_r.add_trace(go.Scatter(
                                x=g_ind['Ronda'], y=g_ind['Valor'], name=f'{tech} — Mejor Propia Industria',
                                mode='lines+markers', line=dict(color=color_t, width=2, dash='dot'),
                                marker=dict(size=6, symbol='circle-open'), opacity=0.85,
                                text=txt_ind_full, hovertemplate='%{text}<extra></extra>'))

                    fig_ca_r.update_layout(
                        title=f'Curva de Aprendizaje (Fabricación Propia) — {area_ca}',
                        yaxis=dict(title='USD/u.' + (' (escala log)' if usar_log_ca else ''), type='log' if usar_log_ca else 'linear'),
                        xaxis_title=None,
                        xaxis=dict(categoryorder='array', categoryarray=RONDAS_ORDENADAS),
                        legend=dict(orientation='h', yanchor='top', y=-0.22, xanchor='center', x=0.5))
                    mostrar(fig_ca_r, margen_b=110, altura=410)
        # --- Matriz / Mapa de Decisión: Qué tecnología conviene producir y dónde (en ronda_snapshot) ---
        st.markdown(f'###### Mapa de Decisión de Producción por Tecnología y Planta — {ronda_snapshot}')
        st.caption(f'Para cada tecnología se muestran las **4 opciones reales en {ronda_snapshot}**: Planta EE.UU. (Interna), Planta Asia (Interna), Tercerizada EE.UU. y Tercerizada Asia '
                   f'(cuando {empresa_analisis} no utilizó una modalidad ese año, la barra toma automáticamente el costo de referencia de la industria y lo avisa en el tooltip).')
        ic_all_ronda = df[(df['Estado'] == 'Informe de costos') & (df['Ronda'] == ronda_snapshot)].copy()
        ic_all_ronda['Valor'] = num(ic_all_ronda['Valor'])
        filas_dec_prod = []
        filas_tabla_dec = []
        for tech_d in _TECNOLOGIAS_GAP:
            def _val_costo_emp(sec_name, area_name, emp_name=empresa_analisis):
                s = ic_all_ronda[(ic_all_ronda['Seccion'] == sec_name) & (ic_all_ronda['Subgrupo'] == area_name) &
                                 (ic_all_ronda['Metrica'] == tech_d) & (ic_all_ronda['Empresa'] == emp_name)]['Valor'].dropna()
                return float(s.iloc[0]) if not s.empty and s.iloc[0] > 0 else None

            def _ref_industria(sec_name, area_name, modo='min'):
                s = ic_all_ronda[(ic_all_ronda['Seccion'] == sec_name) &
                                 (ic_all_ronda['Subgrupo'] == area_name) & (ic_all_ronda['Metrica'] == tech_d)]['Valor'].dropna()
                s = s[s > 0]
                if s.empty:
                    return None
                return float(s.min() if modo == 'min' else s.mean())

            c_int_usa_emp = _val_costo_emp('Costo de producción interna por unidad, USD', 'EE.UU.')
            c_int_asia_emp = _val_costo_emp('Costo de producción interna por unidad, USD', 'Asia')
            c_ter_usa_emp = _val_costo_emp('Costos de fabricación contratada por unidad, USD', 'EE.UU.')
            c_ter_asia_emp = _val_costo_emp('Costos de fabricación contratada por unidad, USD', 'Asia')

            b_int_usa = _ref_industria('Costo de producción interna por unidad, USD', 'EE.UU.', 'min')
            b_int_asia = _ref_industria('Costo de producción interna por unidad, USD', 'Asia', 'min')
            b_ter_usa = _ref_industria('Costos de fabricación contratada por unidad, USD', 'EE.UU.', 'min')
            b_ter_asia = _ref_industria('Costos de fabricación contratada por unidad, USD', 'Asia', 'min')

            v_int_usa = c_int_usa_emp if c_int_usa_emp is not None else b_int_usa
            v_int_asia = c_int_asia_emp if c_int_asia_emp is not None else b_int_asia
            v_ter_usa = c_ter_usa_emp if c_ter_usa_emp is not None else b_ter_usa
            v_ter_asia = c_ter_asia_emp if c_ter_asia_emp is not None else b_ter_asia

            for nombre_op, val_op, val_emp_real, val_bm in [
                ('Planta EE.UU. (Interna)', v_int_usa, c_int_usa_emp, b_int_usa),
                ('Planta Asia (Interna)', v_int_asia, c_int_asia_emp, b_int_asia),
                ('Tercerizada EE.UU.', v_ter_usa, c_ter_usa_emp, b_ter_usa),
                ('Tercerizada Asia', v_ter_asia, c_ter_asia_emp, b_ter_asia),
            ]:
                if val_op is not None:
                    origen_txt = f'Dato real de {empresa_analisis}' if val_emp_real is not None else f'Referencia industria ({empresa_analisis} no produjo acá este año)'
                    bm_extra = f' · Mejor industria: ${val_bm:,.1f}/u.' if (val_emp_real is not None and val_bm is not None) else ''
                    filas_dec_prod.append({
                        'Tecnología': tech_d,
                        'Opción': nombre_op,
                        'USD/u.': val_op,
                        'Etiqueta': f'${val_op:,.1f}' + ('' if val_emp_real is not None else '*'),
                        'Hover': f'<b>{tech_d} — {nombre_op}</b><br>Costo: ${val_op:,.1f} USD/u.<br>{origen_txt}{bm_extra}'
                    })

            opciones_disp = {k: v for k, v in [
                ('Planta Asia (Interna)', v_int_asia),
                ('Planta EE.UU. (Interna)', v_int_usa),
                ('Tercerizada EE.UU.', v_ter_usa),
                ('Tercerizada Asia', v_ter_asia),
            ] if v is not None}

            if opciones_disp:
                mejor_op_nombre = min(opciones_disp, key=opciones_disp.get)
                mejor_op_val = opciones_disp[mejor_op_nombre]
                min_propia = min([x for x in (v_int_usa, v_int_asia) if x is not None], default=None)
                min_terc = min([x for x in (v_ter_usa, v_ter_asia) if x is not None], default=None)

                if mejor_op_nombre.startswith('Tercerizada') and min_propia is not None and mejor_op_val < min_propia:
                    rec_txt = f'✅ Conviene {mejor_op_nombre} (${mejor_op_val:,.1f}/u. vs. ${min_propia:,.1f}/u. en planta propia — volumen inicial aún bajo en curva)'
                elif mejor_op_nombre.startswith('Planta') and min_terc is not None:
                    ahorro = min_terc - mejor_op_val
                    rec_txt = f'✅ Conviene {mejor_op_nombre} (${mejor_op_val:,.1f}/u. — ahorra ${ahorro:,.1f}/u. vs. tercerizar)'
                else:
                    rec_txt = f'✅ Conviene {mejor_op_nombre} (${mejor_op_val:,.1f}/u.)'

                def _fmt_celda(v_e, v_b):
                    if v_e is not None and v_b is not None and abs(v_e - v_b) > 0.05:
                        return f'${v_e:,.1f} (mejor ind.: ${v_b:,.1f})'
                    if v_e is not None:
                        return f'${v_e:,.1f}'
                    if v_b is not None:
                        return f'— (ref. ind.: ${v_b:,.1f}*)'
                    return '—'

                filas_tabla_dec.append({
                    'Tecnología': tech_d,
                    'Planta EE.UU. (Interna)': _fmt_celda(c_int_usa_emp, b_int_usa),
                    'Planta Asia (Interna)': _fmt_celda(c_int_asia_emp, b_int_asia),
                    'Tercerizada EE.UU.': _fmt_celda(c_ter_usa_emp, b_ter_usa),
                    'Tercerizada Asia': _fmt_celda(c_ter_asia_emp, b_ter_asia),
                    'Decisión Óptima (Menor Costo Unitario)': rec_txt,
                })

        if filas_dec_prod:
            df_dec_p = pd.DataFrame(filas_dec_prod)
            mapa_col_dec = {
                'Planta EE.UU. (Interna)': COLOR_METRICA['dinero'],
                'Planta Asia (Interna)': COLOR_CADIZ,
                'Tercerizada EE.UU.': COLOR_METRICA['riesgo'],
                'Tercerizada Asia': '#E87BA4',
            }
            fig_dec_p = px.bar(
                df_dec_p, x='Tecnología', y='USD/u.', color='Opción', barmode='group',
                category_orders={'Tecnología': _TECNOLOGIAS_GAP, 'Opción': ['Planta EE.UU. (Interna)', 'Planta Asia (Interna)', 'Tercerizada EE.UU.', 'Tercerizada Asia']},
                color_discrete_map=mapa_col_dec,
                text='Etiqueta', custom_data=['Hover'],
                title=f'Comparativa de las 4 Opciones de Producción por Tecnología — {ronda_snapshot} (* = referencia industria)')
            fig_dec_p.update_traces(textposition='outside', cliponaxis=False, hovertemplate='%{customdata[0]}<extra></extra>')
            fig_dec_p.update_layout(yaxis_title='USD / unidad', legend=dict(orientation='h', yanchor='top', y=-0.22, xanchor='center', x=0.5))
            mostrar(fig_dec_p)
            if filas_tabla_dec:
                st.dataframe(pd.DataFrame(filas_tabla_dec), use_container_width=True, hide_index=True)
        st.divider()
        st.markdown('**Producción: propia vs. contratada, y fábricas**')
        prod = df[(df['Estado'] == 'Detalles de fabricación') &
                  (df['Seccion'].isin(['Producción interna, miles unidades', 'Producción contratada, miles unidades'])) &
                  (df['Empresa'] == empresa_analisis) & (df['Ronda'] == ronda_snapshot) &
                  (df['Subgrupo'].isin(['EE.UU.', 'Asia']))].copy()
        prod['Valor'] = num(prod['Valor'])
        prod = prod.dropna(subset=['Valor']).groupby(['Subgrupo', 'Seccion'], as_index=False)['Valor'].sum()
        prod['Tipo'] = prod['Seccion'].map({'Producción interna, miles unidades': 'Interna', 'Producción contratada, miles unidades': 'Contratada'})

        col_pp, col_ff = st.columns(2)
        with col_pp:
            if not prod.empty:
                # Adenda 25: se saca el marrón. No pasa a lila -- este gráfico es del EQUIPO EN FOCO
                # (empresa_analisis), que puede no ser CADIZ; "Interna" no es identidad de CADIZ.
                # Fix "ya casi": MUTED_PALETTE[5] era casi idéntico a [0] -- se reemplaza por el sage
                # ya usado en otros lados de la app (MUTED_PALETTE[2]), bien separado del azul-grisáceo.
                fig_prod = px.bar(prod, x='Subgrupo', y='Valor', color='Tipo', barmode='group',
                                   color_discrete_map={'Interna': MUTED_PALETTE[2], 'Contratada': MUTED_PALETTE[0]},
                                   text=prod['Valor'].apply(lambda v: f'{v:,.0f}'),
                                   title=f'Producción propia vs. contratada — {ronda_snapshot}')
                fig_prod.update_traces(textposition='outside', cliponaxis=False)
                mostrar(fig_prod, ocultar_eje_valores='y')
            else:
                st.info('Sin datos de producción para esta combinación.')
        with col_ff:
            fab_all = df[(df['Estado'] == 'Detalles de fabricación') & (df['Seccion'] == 'Número de fábricas') &
                         (df['Ronda'] == ronda_snapshot) & (df['Subgrupo'] == 'Ronda actual')].copy()
            fab_all['Valor'] = num(fab_all['Valor'])
            fab_piv = fab_all.groupby(['Empresa', 'Metrica'], as_index=False)['Valor'].sum()
            if not fab_piv.empty:
                # Adenda 25: se saca el marrón. No pasa a lila -- son los 7 equipos a la vez, "EE.UU."
                # es un mercado, no identidad de CADIZ.
                # Fix "ya casi": MUTED_PALETTE[5] era casi idéntico a [0] -- mismo reemplazo por sage.
                fig_fab = px.bar(fab_piv, x='Empresa', y='Valor', color='Metrica', barmode='stack',
                                  color_discrete_map={'EE.UU.': MUTED_PALETTE[2], 'Asia': MUTED_PALETTE[0]},
                                  text=fab_piv['Valor'].apply(lambda v: f'{v:,.0f}'),
                                  title=f'Fábricas por equipo — {ronda_snapshot}')
                fig_fab.update_traces(textposition='inside')
                mostrar(fig_fab, ocultar_eje_valores='y')
            else:
                st.info('Sin datos de fábricas para este año.')

        # La alerta de expansión de capacidad se movió al panel de alertas de Resultados,
        # para no tener avisos importantes desparramados por el tablero.

        st.divider()
        pl = df[(df['Estado'] == 'Cuenta de resultados, miles USD, Global') & (df['Empresa'] == empresa_analisis) & (df['Ronda'] == ronda_snapshot)]
        def g(metrica): return valor_de(pl, metrica) or 0.0
        ingresos = g('Ingresos por ventas')
        if ingresos > 0:
            # Adenda 24 (a pedido del equipo): las etiquetas anteriores ("- Fab. Interna", "- Caract.",
            # etc.) nombraban el COSTO que se resta en cada escalón, pero el valor graficado en ESE
            # escalón es el MARGEN REMANENTE después de restarlo (ingresos acumulados menos todos los
            # costos restados hasta ahí) -- no el costo en sí. Eso es lo que confundía: la etiqueta y
            # el número no describían la misma cosa. Se renombra cada escalón para que diga el estado
            # del margen que efectivamente muestra la barra.
            # De paso, el diseño anterior tenía un escalón "- Op/Admin" y el escalón final "= EBITDA"
            # con el MISMO valor (el EBITDA se calculaba como el valor del escalón anterior, sin restar
            # nada más) -- dos barras idénticas seguidas, sin una razón que lo justifique. Se lo
            # corrige acá restando I+D/Promoción/Administración directamente en el cálculo del EBITDA,
            # sin un escalón intermedio duplicado.
            etapas = [('Ingresos por Ventas', ingresos)]
            etapas.append(('Margen tras Fab. Interna', etapas[-1][1] - g('Costos de fabricación interna')))
            etapas.append(('Margen tras Características', etapas[-1][1] - g('Costos de características')))
            etapas.append(('Margen tras Fab. Contratada', etapas[-1][1] - g('Costos de fabricación contratada')))
            etapas.append(('Margen tras Logística', etapas[-1][1] - g('Costos de transporte y aranceles')))
            ebitda = etapas[-1][1] - g('I+D') - g('Promoción') - g('Administración')
            etapas.append(('= EBITDA', ebitda))
            colores = [COLOR_POSITIVE] + [MUTED_PALETTE[2]]*(len(etapas)-2) + [COLOR_POSITIVE if ebitda > 0 else COLOR_NEGATIVE]
            # textinfo='value+...' usa el formateo automático de Plotly, que muestra decimales sin
            # redondear ("45.91583M") -- inconsistente con format_num() (1 decimal) que se usa en el
            # resto del tablero, incluida la waterfall de "Puente de Beneficio Neto" con estos mismos
            # datos unas filas más abajo. Se arma el texto a mano con format_num().
            fig = go.Figure(go.Funnel(y=[e[0] for e in etapas], x=[e[1] for e in etapas],
                                       text=[format_num(e[1]) for e in etapas], textinfo='text+percent initial',
                                       marker={'color': colores}))
            fig.update_layout(title='Estructura Macro de Costos (Funnel) — margen remanente en cada etapa')
            mostrar(fig, ocultar_eje_valores='x')

        st.divider()
        st.markdown('**Costos de proveedores — composición**')
        st.caption('No incluye Fabricación contratada — eso ya se ve arriba, en Producción propia vs. contratada.')
        prov = df[(df['Modulo'] == 'Creación de valor') & (df['Seccion'] == 'Proveedores') &
                  (df['Empresa'] == empresa_analisis) & (df['Ronda'] == ronda_snapshot) &
                  (~df['Metrica'].isin(['Total', 'Valor total creado', 'Costos de fabricación contratada']))].copy()
        prov['Valor'] = num(prov['Valor'])
        prov = prov.dropna(subset=['Valor'])
        if not prov.empty:
            # Adenda 25: MUTED_SIN_MARRON -- mismo motivo que Mix tecnológico (Plotly asigna el color
            # por orden de aparición; con 2+ categorías el marrón podía tocarle a cualquiera).
            fig_prov = px.bar(prov, x='Metrica', y='Valor', color='Metrica', color_discrete_sequence=MUTED_SIN_MARRON,
                               text=prov['Valor'].apply(format_num), title=f'Composición de costos de proveedores — {ronda_snapshot}')
            fig_prov.update_traces(textposition='outside', cliponaxis=False, showlegend=False)
            mostrar(fig_prov, ocultar_eje_valores='y')
        else:
            st.info('Sin datos de proveedores para esta combinación.')
        st.divider()
        c3, c4 = st.columns(2)
        pais_ue = c3.selectbox('País — Margen Unitario', ['EE.UU.', 'Asia', 'Europa'], key='sel_op_pais')
        tech_ue = c4.selectbox('Tecnología — Margen Unitario', ['Tec 1', 'Tec 2', 'Tec 3', 'Tec 4'], key='sel_op_tech')
        margen = df[(df['Estado'] == f'Desglose de margen por tec, miles USD, {pais_ue}') & (df['Seccion'] == tech_ue) & (df['Empresa'] == empresa_analisis) & (df['Ronda'] == ronda_snapshot)]
        mercado = df[(df['Estado'] == f'Informe de mercado, {pais_ue}') & (df['Seccion'] == tech_ue) & (df['Ronda'] == ronda_snapshot)]
        # Adenda 32 (escala centralizada en cesim_parser): 'margen' (Estado "miles USD") ya llega
        # absoluto -- 'unidades' (Estado "miles unidades", no monetario) sigue en miles, así que hay
        # que llevarlo a absoluto ACÁ antes de dividir un $ absoluto por él (si no, el USD/u. de todo
        # este bloque -- el Waterfall de Margen Unitario -- sale 1000x más grande de lo real).
        unidades = valor_fuzzy(mercado, '^Ventas', empresa=empresa_analisis)
        unidades = unidades * 1000.0 if unidades else unidades
        def gm(metrica): return valor_de(margen, metrica) or 0.0
        if unidades and unidades > 0:
            p_venta = gm('Ingresos por ventas') / unidades
            c_prod = -gm('Fabricación propia y por contrato') / unidades
            c_imp = -gm('Costo de los productos importados') / unidades
            c_flete = -gm('Transporte y aranceles') / unidades
            c_caract = -gm('Costos de características') / unidades
            m_bruto = gm('Beneficio bruto') / unidades
            etapas_ue = [('Precio', p_venta), ('- Fab. Local', c_prod)]
            if abs(c_imp) > 1e-6:
                etapas_ue.append(('- Importado (TP)', c_imp))
            etapas_ue.extend([('- Logística/Arancel', c_flete), ('- Caract.', c_caract), ('= Margen Unitario', m_bruto)])
            _valores_margen_ue = [v for _, v in etapas_ue]
            fig_ue = go.Figure(go.Waterfall(
                orientation='v', measure=['relative'] * (len(etapas_ue) - 1) + ['total'],
                x=[k for k, _ in etapas_ue],
                y=_valores_margen_ue,
                text=_texto_cascada(_valores_margen_ue), textposition='outside',
                decreasing={'marker': {'color': COLOR_NEGATIVE}}, increasing={'marker': {'color': COLOR_POSITIVE}},
                totals={'marker': {'color': COLOR_POSITIVE if m_bruto > 0 else COLOR_NEGATIVE}}
            ))
            fig_ue.update_layout(title=f'Margen Unitario — {tech_ue}, {pais_ue}')
            mostrar(fig_ue, ocultar_eje_valores='y')
            costo_total_unit = -(c_prod + c_imp + c_flete + c_caract)
            markup_pct = (m_bruto / costo_total_unit * 100) if costo_total_unit else None
            margen_pct = (m_bruto / p_venta * 100) if p_venta else None

            ronda_prev_ue = ronda_anterior_de(ronda_snapshot)
            margen_pct_prev = markup_pct_prev = None
            if ronda_prev_ue:
                margen_prev = df[(df['Estado'] == f'Desglose de margen por tec, miles USD, {pais_ue}') &
                                  (df['Seccion'] == tech_ue) & (df['Empresa'] == empresa_analisis) &
                                  (df['Ronda'] == ronda_prev_ue)]
                mercado_prev = df[(df['Estado'] == f'Informe de mercado, {pais_ue}') & (df['Seccion'] == tech_ue) &
                                   (df['Ronda'] == ronda_prev_ue)]
                unidades_prev = valor_fuzzy(mercado_prev, '^Ventas', empresa=empresa_analisis)
                unidades_prev = unidades_prev * 1000.0 if unidades_prev else unidades_prev
                if unidades_prev and unidades_prev > 0:
                    def gm_prev(metrica): return valor_de(margen_prev, metrica) or 0.0
                    p_venta_prev = gm_prev('Ingresos por ventas') / unidades_prev
                    m_bruto_prev = gm_prev('Beneficio bruto') / unidades_prev
                    costo_total_unit_prev = -(-gm_prev('Fabricación propia y por contrato') / unidades_prev
                                               - gm_prev('Costo de los productos importados') / unidades_prev
                                               - gm_prev('Transporte y aranceles') / unidades_prev
                                               - gm_prev('Costos de características') / unidades_prev)
                    margen_pct_prev = (m_bruto_prev / p_venta_prev * 100) if p_venta_prev else None
                    markup_pct_prev = (m_bruto_prev / costo_total_unit_prev * 100) if costo_total_unit_prev else None
            delta_margen_pct = (margen_pct - margen_pct_prev) if (margen_pct is not None and margen_pct_prev is not None) else None
            delta_markup_pct = (markup_pct - markup_pct_prev) if (markup_pct is not None and markup_pct_prev is not None) else None

            margen_pct_todos, markup_pct_todos = {}, {}
            for _emp in COMPANIES:
                _margen_emp = df[(df['Estado'] == f'Desglose de margen por tec, miles USD, {pais_ue}') &
                                  (df['Seccion'] == tech_ue) & (df['Empresa'] == _emp) & (df['Ronda'] == ronda_snapshot)]
                _unid_emp = valor_fuzzy(mercado, '^Ventas', empresa=_emp)
                _unid_emp = _unid_emp * 1000.0 if _unid_emp else _unid_emp
                if _unid_emp and _unid_emp > 0:
                    def _gme(metrica): return valor_de(_margen_emp, metrica) or 0.0
                    _p_venta_e = _gme('Ingresos por ventas') / _unid_emp
                    _m_bruto_e = _gme('Beneficio bruto') / _unid_emp
                    _costo_e = -(-_gme('Fabricación propia y por contrato') / _unid_emp
                                 - _gme('Costo de los productos importados') / _unid_emp
                                 - _gme('Transporte y aranceles') / _unid_emp
                                 - _gme('Costos de características') / _unid_emp)
                    margen_pct_todos[_emp] = (_m_bruto_e / _p_venta_e * 100) if _p_venta_e else None
                    markup_pct_todos[_emp] = (_m_bruto_e / _costo_e * 100) if _costo_e else None
                else:
                    margen_pct_todos[_emp] = markup_pct_todos[_emp] = None

            def _delta_ind_pp(vals_dict, val_propio):
                # Delta en PUNTOS PORCENTUALES vs. promedio de industria (no % relativo) -- mismo
                # criterio que ya se usa acá para "vs. ronda anterior" (también en p.p., porque
                # margen_pct/markup_pct ya son porcentajes).
                _vals = [v for v in vals_dict.values() if v is not None]
                if not _vals or val_propio is None:
                    return None
                _prom = np.nanmean(_vals)
                return (val_propio - _prom) if pd.notna(_prom) else None

            d_margen_ind_pp = _delta_ind_pp(margen_pct_todos, margen_pct)
            d_markup_ind_pp = _delta_ind_pp(markup_pct_todos, markup_pct)

            col_cm, col_mk = st.columns(2)
            with col_cm:
                kpi_doble_delta(None, 'Margen Unitario (%)', f'{margen_pct:,.1f}%' if margen_pct is not None else '—',
                                 d_ronda=delta_margen_pct, ronda_prev_nombre=ronda_prev_ue,
                                 d_industria=d_margen_ind_pp, unidad=' p.p.')
            with col_mk:
                kpi_doble_delta(None, 'Mark-up aplicado', f'{markup_pct:,.1f}%' if markup_pct is not None else '—',
                                 d_ronda=delta_markup_pct, ronda_prev_nombre=ronda_prev_ue,
                                 d_industria=d_markup_ind_pp, unidad=' p.p.')
            st.caption('Margen % = Contribución Marginal Unitaria / Precio de Venta (el desglose en USD/u. está en el '
                       'Waterfall de arriba). Mark-up = Contribución Marginal Unitaria / Costo unitario total '
                       '(fabricación + logística + características) — mismo numerador, denominador distinto (precio '
                       'vs. costo), no confundir uno con otro. Deltas en puntos porcentuales (p.p.), no % relativo: '
                       'vs. el año inmediatamente anterior y vs. el promedio de los 7 equipos, mismo país/tecnología.')

        st.divider()
        st.markdown(f'**Comparador de Abastecimiento: Producción vs. Aranceles y Fletes — {tech_ue}, {ronda_snapshot}**')
        st.caption(f'Para decidir desde qué planta abastecer cada mercado en **{tech_ue}**: a la izquierda, cuánto cuesta fabricar 1 unidad en EE.UU. vs. Asia (Propia y Contratada). A la derecha, el costo unitario final de los productos vendidos en cada mercado (Costo base de fabricación + Flete y Arancel por unidad vendida).')
        ic_ronda = df[(df['Estado'] == 'Informe de costos') & (df['Ronda'] == ronda_snapshot) & (df['Empresa'] == empresa_analisis)].copy()
        ic_ronda['Valor'] = num(ic_ronda['Valor'])
        col_src1, col_src2 = st.columns(2)
        with col_src1:
            filas_fab_src = []
            for area_s in ['EE.UU.', 'Asia']:
                c_int = ic_ronda[(ic_ronda['Seccion'] == 'Costo de producción interna por unidad, USD') & (ic_ronda['Subgrupo'] == area_s) & (ic_ronda['Metrica'] == tech_ue)]['Valor']
                c_ter = ic_ronda[(ic_ronda['Seccion'] == 'Costos de fabricación contratada por unidad, USD') & (ic_ronda['Subgrupo'] == area_s) & (ic_ronda['Metrica'] == tech_ue)]['Valor']
                v_int = float(c_int.iloc[0]) if not c_int.empty and pd.notna(c_int.iloc[0]) else 0.0
                v_ter = float(c_ter.iloc[0]) if not c_ter.empty and pd.notna(c_ter.iloc[0]) else 0.0
                if v_int > 0:
                    filas_fab_src.append({'Planta': area_s, 'Modalidad': 'Propia (Interna)', 'USD/u.': v_int})
                if v_ter > 0:
                    filas_fab_src.append({'Planta': area_s, 'Modalidad': 'Contratada (Tercerizada)', 'USD/u.': v_ter})
            if filas_fab_src:
                df_fab_src = pd.DataFrame(filas_fab_src)
                fig_fsrc = px.bar(df_fab_src, x='Planta', y='USD/u.', color='Modalidad', barmode='group',
                                  color_discrete_map={'Propia (Interna)': MUTED_PALETTE[2], 'Contratada (Tercerizada)': MUTED_PALETTE[0]},
                                  text=df_fab_src['USD/u.'].apply(lambda v: f'${v:,.1f}'),
                                  title=f'Costo de Fabricación en Planta ({empresa_analisis}) — {tech_ue}')
                fig_fsrc.update_traces(textposition='outside', cliponaxis=False)
                mostrar(fig_fsrc, ocultar_eje_valores='y')
            else:
                st.info(f'{empresa_analisis} no registró producción propia ni contratada de {tech_ue} en {ronda_snapshot}.')
        with col_src2:
            filas_dest_src = []
            for mkt_s in ['EE.UU.', 'Asia', 'Europa']:
                c_tot = ic_ronda[(ic_ronda['Seccion'] == 'Costo unitario promedio por producto vendido, USD') & (ic_ronda['Subgrupo'] == mkt_s) & (ic_ronda['Metrica'] == tech_ue)]['Valor']
                c_log = ic_ronda[(ic_ronda['Seccion'] == 'Costo de transporte incl. aranceles por producto vendido, USD') & (ic_ronda['Subgrupo'] == mkt_s) & (ic_ronda['Metrica'] == tech_ue)]['Valor']
                v_tot = float(c_tot.iloc[0]) if not c_tot.empty and pd.notna(c_tot.iloc[0]) else 0.0
                v_log = float(c_log.iloc[0]) if not c_log.empty and pd.notna(c_log.iloc[0]) else 0.0
                if v_tot > 0 or v_log > 0:
                    v_base = max(0.0, v_tot - v_log)
                    filas_dest_src.append({'Mercado': mkt_s, 'Componente': 'Costo Base Producto', 'USD/u.': v_base})
                    filas_dest_src.append({'Mercado': mkt_s, 'Componente': 'Flete + Arancel', 'USD/u.': v_log})
            if filas_dest_src:
                df_dest_src = pd.DataFrame(filas_dest_src)
                fig_dsrc = px.bar(df_dest_src, x='Mercado', y='USD/u.', color='Componente', barmode='stack',
                                  color_discrete_map={'Costo Base Producto': COLOR_METRICA['dinero'], 'Flete + Arancel': COLOR_METRICA['riesgo']},
                                  text=df_dest_src['USD/u.'].apply(lambda v: f'${v:,.1f}' if v > 0 else ''),
                                  title=f'Costo Puesto en Destino (Base + Flete/Arancel) — {tech_ue}')
                fig_dsrc.update_traces(textposition='inside')
                mostrar(fig_dsrc)
            else:
                st.info(f'{empresa_analisis} no registró ventas de {tech_ue} en {ronda_snapshot}.')

        st.divider()
        st.markdown(f'**Punto de equilibrio — {empresa_analisis}, {ronda_snapshot}**')
        # Adenda 32 (escala centralizada en cesim_parser): 'Margen de contribución' (Estado "miles
        # USD") y los 3 componentes de costos fijos (Estado "Cuenta de resultados, miles USD, Global")
        # ya llegan absolutos -- solo 'Ventas, miles unidades' sigue en miles (es un Estado de
        # unidades, no monetario, no lo toca esa corrección), así que sigue siendo el único x1000
        # que hace falta acá.
        cm_total = 0.0
        vol_total_miles = 0.0
        for mercado_be in ['EE.UU.', 'Asia', 'Europa']:
            margen_be = df[(df['Estado'] == f'Desglose de margen por tec, miles USD, {mercado_be}') &
                           (df['Empresa'] == empresa_analisis) & (df['Ronda'] == ronda_snapshot) &
                           (df['Metrica'] == 'Margen de contribución')].copy()
            cm_total += num(margen_be['Valor']).sum()
            ventas_be = df[(df['Estado'] == f'Informe de mercado, {mercado_be}') & (df['Empresa'] == empresa_analisis) &
                          (df['Ronda'] == ronda_snapshot) & (df['Metrica'] == 'Ventas, miles unidades')].copy()
            vol_total_miles += num(ventas_be['Valor']).sum()
        pl_be = df[(df['Estado'] == 'Cuenta de resultados, miles USD, Global') & (df['Empresa'] == empresa_analisis) & (df['Ronda'] == ronda_snapshot)]
        def gbe(metrica): return valor_de(pl_be, metrica) or 0.0
        costos_fijos = gbe('Depreciación de Activos Fijos') + gbe('I+D') + gbe('Administración')
        if vol_total_miles > 0 and cm_total:
            volumen_real = vol_total_miles * 1000.0  # "miles unidades" -> unidades absolutas
            cm_unitaria = cm_total / volumen_real  # USD absoluto / unidades absolutas = USD/u.
            volumen_equilibrio = (costos_fijos / cm_unitaria) if cm_unitaria else None
            if volumen_equilibrio is not None and volumen_equilibrio > 0:
                chart_bullet(f'Punto de Equilibrio — {empresa_analisis}, {ronda_snapshot}', volumen_equilibrio, volumen_real,
                             'unidades', nombre_fondo='Volumen de Equilibrio', nombre_frente='Volumen Real Vendido',
                             color_excedente=COLOR_POSITIVE)  # vender por encima del equilibrio es favorable
                st.caption('Costos Fijos = Depreciación + I+D + Administración (real, Global). Contribución Marginal '
                           'Unitaria Ponderada = Margen de contribución total / unidades totales vendidas, sumado en '
                           'los 3 mercados donde el equipo vende.')
            else:
                st.info('No se pudo calcular el punto de equilibrio para esta combinación.')
        else:
            st.info('Sin datos suficientes de ventas/margen para calcular el punto de equilibrio.')
    with bloque2:
        c1, c2 = st.columns(2)
        pais_sel = c1.selectbox('País Inventario', ['EE.UU.', 'Asia', 'Europa'], key='sel_inv_pais')
        tech_sel = c2.selectbox('Tecnología — Inventario', ['Tec 1', 'Tec 2', 'Tec 3', 'Tec 4'], key='sel_inv_tech')
        log = df[(df['Estado'] == 'Detalles de logística') & (df['Empresa'] == empresa_analisis) & (df['Seccion'] == f'{tech_sel}, miles unidades') & (df['Subgrupo'] == pais_sel) & (df['Ronda'] == ronda_snapshot)].copy()
        log['Valor'] = num(log['Valor'])
        d = log.set_index('Metrica')['Valor']
        if not d.empty:
            inv_ini = d.get('Inventario inicial', 0) or 0
            prod = (d.get('Producción interna', 0) or 0) + (d.get('Producción contratada', 0) or 0)
            imp = sum(v for k, v in d.items() if k.startswith('Importado desde') and pd.notna(v))
            ventas = abs(d.get(f'Ventas en {pais_sel}', 0) or 0)
            exp = sum(abs(v) for k, v in d.items() if k.startswith('Exportado a') and pd.notna(v))
            inv_fin = d.get('Inventario final', 0) or 0
            _valores_inv = [inv_ini, prod, imp, -ventas, -exp, inv_fin]
            fig_inv = go.Figure(go.Waterfall(
                orientation='v', measure=['relative', 'relative', 'relative', 'relative', 'relative', 'total'],
                x=['Inv Inicial', '+ Prod', '+ Import', '- Ventas', '- Export', '= Inv Final'],
                y=_valores_inv,
                # Adenda 25: % entre paréntesis sobre el Inventario Inicial (primera barra).
                text=_texto_cascada(_valores_inv), textposition='outside',
                # Adenda 25: convención universal de color -- verde = suma, rojo = resta. Antes
                # decreasing usaba MUTED_PALETTE[2] (verde grisáceo apagado, no rojo). Totals se
                # mantiene neutro (MUTED_PALETTE[0]): "Inv Final" acá no es identidad CADIZ ni
                # sentimiento (más/menos inventario final no es en sí bueno o malo), es un dato físico.
                decreasing={'marker': {'color': COLOR_NEGATIVE}}, increasing={'marker': {'color': COLOR_POSITIVE}},
                totals={'marker': {'color': MUTED_PALETTE[0]}}
            ))
            fig_inv.update_layout(title='Puente de Inventario Físico')
            mostrar(fig_inv, ocultar_eje_valores='y')

        st.divider()
        st.markdown('**Gap de pronóstico: demanda insatisfecha vs. inventario que sobró**')
        st.caption('Evolución de las dos formas de errar la estimación de demanda: faltante (no llegaste a vender lo que te pedían) y sobrante (produjiste de más y quedó en depósito).')
        log_hist = df[(df['Estado'] == 'Detalles de logística') & (df['Empresa'] == empresa_analisis) &
                      (df['Seccion'] == f'{tech_sel}, miles unidades') & (df['Subgrupo'] == pais_sel) &
                      (df['Metrica'].isin(['Demanda insatisfecha', 'Inventario final']))].copy()
        log_hist['Valor'] = num(log_hist['Valor'])
        log_hist = log_hist.dropna(subset=['Valor']).sort_values('Ronda_Orden')
        if not log_hist.empty:
            fig_gap = go.Figure()
            for metrica, color, nombre in [('Demanda insatisfecha', COLOR_NEGATIVE, 'Faltante (demanda insatisfecha)'),
                                            ('Inventario final', MUTED_PALETTE[0], 'Sobrante (inventario final)')]:
                d_m = log_hist[log_hist['Metrica'] == metrica]
                fig_gap.add_trace(go.Bar(x=d_m['Ronda'], y=d_m['Valor'], name=nombre, marker_color=color))
            fig_gap.update_layout(barmode='group', title=f'Faltante vs. sobrante — {empresa_analisis}, {tech_sel}, {pais_sel}',
                                   legend=dict(orientation="h", yanchor="top", y=-0.30, xanchor="center", x=0.5))
            mostrar(fig_gap)
        else:
            st.info('Sin datos suficientes para esta combinación.')

        st.divider()
        log_tech = df[(df['Estado'] == 'Detalles de logística') & (df['Empresa'] == empresa_analisis) & (df['Seccion'] == f'{tech_sel}, miles unidades') & (df['Ronda'] == ronda_snapshot)]
        def val_log(planta, metrica):
            r = log_tech[(log_tech['Subgrupo'] == planta) & (log_tech['Metrica'] == metrica)]['Valor']
            return abs(pd.to_numeric(r.iloc[0], errors='coerce')) if len(r) else 0.0
        destinos = ['EE.UU.', 'Asia', 'Europa']
        matriz = pd.DataFrame(0.0, index=['EE.UU.', 'Asia', 'Subcontratado'], columns=destinos)
        for planta in ['EE.UU.', 'Asia']:
            interna, contratada = val_log(planta, 'Producción interna'), val_log(planta, 'Producción contratada')
            tot = interna + contratada
            flows = {dst: val_log(planta, f'Ventas en {planta}' if dst == planta else f'Exportado a {dst}') for dst in destinos}
            if tot > 0:
                for dst in destinos:
                    matriz.loc[planta, dst] += flows[dst] * (interna/tot)
                    matriz.loc['Subcontratado', dst] += flows[dst] * (contratada/tot)
        if matriz.sum().sum() > 0:
            # Heatmap de magnitud (flujo logístico), sin identidad ni sentimiento -- azul de
            # COLOR_METRICA['dinero'] en vez del lila/rojo de marca (Adenda 25).
            fig3 = px.imshow(matriz.values, x=destinos, y=matriz.index, text_auto='.0f', aspect='auto', color_continuous_scale=[[0, BRAND_LIGHT], [1, COLOR_METRICA['dinero']]])
            fig3.update_coloraxes(showscale=False)
            fig3.update_xaxes(title_text='Destino (Mercado)')
            fig3.update_yaxes(title_text='Origen (Planta)')
            fig3.update_traces(xgap=3, ygap=3) 
            fig3.update_layout(title='Matriz Logística (Heatmap Origen -> Destino)')
            mostrar(fig3)
        else:
            st.info(f"Sin flujos logísticos de {tech_sel} para mostrar en este año.")
# =================================================================
# SECCIÓN 4 — FINANZAS (Corto y Largo Plazo)
# =================================================================
def seccion_finanzas():
    # =================================================================
    # Adenda 25 -- RESTRUCTURACIÓN DE FINANZAS (a pedido del equipo). Cambios:
    #  1) KPIs principales (banda oscura): antes EBITDA/Caja final/Deuda CP no planificada -> ahora
    #     Precio Acción/Capitalización de mercado/EPS (la "foto" de una acción cotizante).
    #  2) KPIs secundarios: antes Margen bruto/ROS/Deuda LP/Calificación -> ahora Ingresos por
    #     ventas/EBITDA/Beneficio neto/Calificación. Margen bruto y ROS no se pierden: pasan al
    #     Gráfico 1 de más abajo.
    #  3) Gráfico 1 (nuevo): desglose Ingresos/Margen bruto/EBITDA/EBIT/Margen Neto en un solo eje.
    #  4) Gráfico 2 (nuevo), al lado: evolución del Precio de la Acción (reusa chart_evolucion, los
    #     7 equipos + promedio, como el resto de la app).
    #  5) Estructura del Balance se reposiciona debajo de Gráfico 1/2 (antes vivía en la pestaña
    #     "Largo Plazo").
    #  6) Debajo del Balance: 3 KPIs -- WACC, ROCE, Deuda LP (reemplazan la tarjeta única de
    #     "Spread de Creación de Valor").
    #  7) Rango de Industria se recorta a WACC/Apalancamiento/ROA/ROE/ROCE (se saca "Spread
    #     ROCE-WACC", que no lo pidió el equipo).
    #  8) Se eliminan 3 gráficos: "Costo de la deuda por mercado", "Matriz Riesgo/Retorno" y
    #     "Beneficio Neto vs. Nivel de Deuda". ("Evolución del margen bruto" -- el 4° de la lista
    #     original -- no se encontró como gráfico propio en esta sección; puede haberse eliminado ya
    #     en una etapa anterior, o el equipo puede estar refiriéndose al Gráfico 1 nuevo, que sí
    #     incluye Margen bruto. Señalado acá para no asumir en silencio.)
    #  9) En Comparativa Plan vs. Real se saca el llamado a fila3_finanzas_flujo_caja() (el puente
    #     CFO->CFI->CFF) -- queda solo el comparativo lateral Proyectado vs. Real. La función sigue
    #     definida más arriba, sin uso, por si se retoma.
    #
    # Adenda 26 -- AJUSTES SOBRE LA RESTRUCTURACIÓN DE ARRIBA (a pedido del equipo, feedback sobre
    # la Adenda 25). Cambios:
    #  A) Pestañas al TOPE de la sección (debajo del título "Finanzas", antes de las tarjetas de
    #     cabecera) y recortadas a 2: "Finanzas" (todo lo que antes vivía suelto: cabecera, Gráfico
    #     1/2, Balance, KPIs WACC/ROCE/Deuda LP, Rango de Industria, y "Deuda y liquidez" que antes
    #     vivía en la pestaña "Corto Plazo") y "Comparativa Plan vs. Real".
    #  B) Gráfico 1 (desglose de Ingresos y Márgenes): ahora SÍ muestra las etiquetas de categoría en
    #     el eje Y (antes se ocultaban con ocultar_eje_valores='y', quedaba sin texto a la izquierda)
    #     -- se saca ese parámetro del llamado a mostrar(). Etiquetas de categoría renombradas para
    #     que se lean como conceptos de estado de resultados en vez de "Margen X" repetido:
    #     "Margen bruto"->"Margen Bruto", "Margen EBITDA"->"EBITDA", "Margen EBIT"->"EBIT / Resultado
    #     Operativo", "Margen Neto (ROS)"->"Beneficio Neto" (el valor y el % que muestran son los
    #     MISMOS ratios de antes, solo cambia el texto de la etiqueta).
    #  C) "Evolución — Deuda CP no planificada" (el gráfico de línea temporal) se elimina. La lógica
    #     de alerta sigue viva: ya existía en evaluar_alertas()/panel_alertas() (regla "Sobregiro
    #     automático", mostrada en la sección Resultados) y ahora se agrega ADEMÁS un st.toast() acá
    #     mismo en Finanzas para no perder la señal visual que daba el gráfico que se sacó.
    #  D) Se reincorpora un badge de "Spread de Creación de Valor" (ROCE − WACC) y se agrega un
    #     gráfico nuevo de "Composición de Estructura de Capital" (ponderación Deuda/Patrimonio del
    #     propio cálculo de WACC) -- los dos, debajo de los 3 KPIs de WACC/ROCE/Deuda LP.
    #  E) panel_comparativa_plan_real(): se llama con mostrar_metricas=False -- saca la Fila 1 de
    #     tarjetas st.metric y deja solo el panel de barras horizontales apiladas como elemento
    #     protagonista (ver comentario en la definición de esa función). [Adenda 29: ese llamado ya
    #     no vive acá -- se movió al Nivel 1 de la nueva sección 'Control de Gestión', con el mismo
    #     criterio mostrar_metricas=False/mostrar_extras=False.]
    #  DECISIÓN DE LAYOUT PROPIA (no especificada por el equipo, a flagear): con Balance, Rango de
    #  Industria y los KPIs de Largo Plazo promovidos al bloque fijo de arriba, y con "Costo de la
    #  deuda"/"Matriz Riesgo-Retorno"/"Beneficio Neto vs Deuda" eliminados, la pestaña "Largo Plazo:
    #  Estructura, Retorno y Competencia" se quedaba vacía -- se elimina esa pestaña y "Deuda y
    #  liquidez" (lo único que quedaba en "Corto Plazo") pasa a vivir dentro de la pestaña "Finanzas".
    # =================================================================
    pl_ronda = df[(df['Estado'] == 'Cuenta de resultados, miles USD, Global') & (df['Ronda'] == ronda_snapshot)]
    ratios_ronda = df[(df['Estado'] == 'Ratios e indicadores financieros clave') & (df['Ronda'] == ronda_snapshot)]
    val_ronda = df[(df['Estado'] == 'Valuación - Global') & (df['Ronda'] == ronda_snapshot)]
    bal_ronda = df[(df['Estado'] == 'Hoja de Balance, miles USD, Global') & (df['Ronda'] == ronda_snapshot)]

    def wacc(emp, val_df=None):
        val_df = val_ronda if val_df is None else val_df
        de = valor_de(val_df, 'Deuda a patrimonio', emp)
        re_ = valor_de(val_df, 'Rendimiento esperado del patrimonio, %', emp)
        rd = valor_de(val_df, 'Costo de la deuda después de impuestos, %', emp)
        if None in (de, re_, rd): return None
        return (1/(1+de))*re_ + (de/(1+de))*rd

    def delta_raw(vals, empresa=empresa_analisis):
        # Mismo cálculo que el resto de la app: % de distancia contra el promedio de los 7 equipos.
        prom = np.nanmean([v for v in vals.values() if v is not None]) if any(v is not None for v in vals.values()) else None
        val = vals.get(empresa)
        if prom in (None, 0) or val is None:
            return None
        return (val - prom) / abs(prom) * 100

    # Adenda 29 (a pedido del equipo, "Control de Gestión" centralizado): ya no hace falta la
    # pestaña -- con 'Comparativa Plan vs. Real' movida a su propia sección (ver comentario más
    # abajo, donde vivía tab_cg), esta sección vuelve a tener un solo contenido; se cambia el
    # st.tabs(...) de la Adenda 26 por un contenedor simple para no dejar una tira de UNA sola
    # pestaña (sin cambiar la indentación del cuerpo de abajo).
    with st.container():
        # Adenda 37 (a pedido del equipo: reorganizar Finanzas en bloques con "hilo conductor" propio,
        # mismo espíritu narrativo que ya usa Control de Gestión con sus Niveles, pero con subtítulos
        # simples en vez de "Nivel N" -- a pedido explícito del equipo, "más simple"). 4 bloques:
        # Desempeño y Valoración (como ya existía) / Retorno al Accionista (nuevo) / Riesgo
        # Competitivo (nuevo) / Estructura Financiera (como ya existía, desde "Estructura del Balance"
        # en adelante).
        st.subheader('Desempeño y Valoración')
        # ---- KPIs principales: Precio Acción / Capitalización / EPS ----
        precio_vals = {e: valor_de(ratios_ronda, 'Precio de la acción al final de la ronda, USD', e) for e in COMPANIES}
        cap_vals = {e: valor_de(val_ronda, 'Capitalización de mercado, miles USD', e) for e in COMPANIES}
        eps_vals = {e: valor_de(ratios_ronda, 'Ganancias por acción (EPS), USD', e) for e in COMPANIES}
        d_precio_ronda, ronda_prev_fin = delta_vs_ronda_anterior('Ratios e indicadores financieros clave', 'Precio de la acción al final de la ronda, USD')
        d_cap_ronda, _ = delta_vs_ronda_anterior('Valuación - Global', 'Capitalización de mercado, miles USD')
        d_eps_ronda, _ = delta_vs_ronda_anterior('Ratios e indicadores financieros clave', 'Ganancias por acción (EPS), USD')
        d_precio_ind, d_cap_ind, d_eps_ind = delta_raw(precio_vals), delta_raw(cap_vals), delta_raw(eps_vals)
        sufijo_ronda_fin = f'vs {ronda_prev_fin}' if ronda_prev_fin else 'vs año anterior'
        kpi_banda_oscura([
            {'label': 'Precio Acción (USD)', 'valor': f"{precio_vals.get(empresa_analisis):,.2f}" if pd.notna(precio_vals.get(empresa_analisis)) else '—',
             'delta': f'{d_precio_ronda:+.1f}% {sufijo_ronda_fin}' if d_precio_ronda is not None else None, 'favorable': (d_precio_ronda > 0) if d_precio_ronda is not None else None,
             'delta2': f'{d_precio_ind:+.1f}% vs Industria' if d_precio_ind is not None else None, 'favorable2': (d_precio_ind > 0) if d_precio_ind is not None else None},
            {'label': 'Capitalización de mercado (USD)', 'valor': format_num(cap_vals.get(empresa_analisis)) if pd.notna(cap_vals.get(empresa_analisis)) else '—',
             'delta': f'{d_cap_ronda:+.1f}% {sufijo_ronda_fin}' if d_cap_ronda is not None else None, 'favorable': (d_cap_ronda > 0) if d_cap_ronda is not None else None,
             'delta2': f'{d_cap_ind:+.1f}% vs Industria' if d_cap_ind is not None else None, 'favorable2': (d_cap_ind > 0) if d_cap_ind is not None else None},
            {'label': 'EPS (USD)', 'valor': f"{eps_vals.get(empresa_analisis):,.2f}" if pd.notna(eps_vals.get(empresa_analisis)) else '—',
             'delta': f'{d_eps_ronda:+.1f}% {sufijo_ronda_fin}' if d_eps_ronda is not None else None, 'favorable': (d_eps_ronda > 0) if d_eps_ronda is not None else None,
             'delta2': f'{d_eps_ind:+.1f}% vs Industria' if d_eps_ind is not None else None, 'favorable2': (d_eps_ind > 0) if d_eps_ind is not None else None},
        ])

        # ---- KPIs secundarios: Ingresos por ventas / EBITDA / Beneficio neto / Calificación ----
        ingresos_vals = {e: valor_de(pl_ronda, 'Ingresos por ventas', e) for e in COMPANIES}
        ebitda_vals = {e: valor_de(pl_ronda, 'Beneficio operativo antes de depreciación (EBITDA)', e) for e in COMPANIES}
        beneficio_neto_vals = {e: valor_de(pl_ronda, 'Beneficio de la ronda', e) for e in COMPANIES}
        # Margen bruto, ROS y Deuda CP/LP se siguen calculando -- Margen bruto/ROS alimentan el
        # Gráfico 1 de más abajo, Deuda CP sigue en "Deuda y liquidez", Deuda LP en los 3 KPIs junto
        # al Balance.
        margen_vals = {e: valor_de(ratios_ronda, 'Margen bruto', e) for e in COMPANIES}
        ros_vals = {e: valor_de(ratios_ronda, 'Rentabilidad de las ventas (ROS)', e) for e in COMPANIES}
        ebitda_pct_vals = {e: valor_de(ratios_ronda, 'Beneficio operativo antes de depreciación ( EBITDA )', e) for e in COMPANIES}
        ebit_pct_vals = {e: valor_de(ratios_ronda, 'BENEFICIO OPERATIVO (EBIT)', e) for e in COMPANIES}
        ebit_usd_vals = {e: valor_de(pl_ronda, 'Beneficio operativo (EBIT)', e) for e in COMPANIES}
        deuda_cp_vals = {e: valor_de(bal_ronda, 'Deudas a corto plazo (no planificadas)', e) for e in COMPANIES}
        deuda_lp_vals = {e: valor_de(bal_ronda, 'Deudas a largo plazo', e) for e in COMPANIES}
        calif_val = valor_texto(ratios_ronda, 'Calificación crediticia', empresa_analisis)

        d_ingresos_ronda, _ = delta_vs_ronda_anterior('Cuenta de resultados, miles USD, Global', 'Ingresos por ventas')
        d_ebitda_ronda, _ = delta_vs_ronda_anterior('Cuenta de resultados, miles USD, Global', 'Beneficio operativo antes de depreciación (EBITDA)')
        d_bn_ronda, _ = delta_vs_ronda_anterior('Cuenta de resultados, miles USD, Global', 'Beneficio de la ronda')
        f2, f3, f6, f7 = st.columns(4)
        with f2:
            kpi_doble_delta(None, 'Ingresos por ventas (USD)', format_num(ingresos_vals.get(empresa_analisis)),
                             d_ronda=d_ingresos_ronda, ronda_prev_nombre=ronda_prev_fin, d_industria=delta_raw(ingresos_vals))
        with f3:
            kpi_doble_delta(None, 'EBITDA (USD)', format_num(ebitda_vals.get(empresa_analisis)),
                             d_ronda=d_ebitda_ronda, ronda_prev_nombre=ronda_prev_fin, d_industria=delta_raw(ebitda_vals))
        with f6:
            kpi_doble_delta(None, 'Beneficio neto (USD)', format_num(beneficio_neto_vals.get(empresa_analisis)),
                             d_ronda=d_bn_ronda, ronda_prev_nombre=ronda_prev_fin, d_industria=delta_raw(beneficio_neto_vals))
        with f7: st.metric('Calificación crediticia', calif_val if calif_val else '—')
        st.write('')

        # Fix (a pedido del equipo: "no me convence como quedaron esos 4 gráficos, muy chiquitos"):
        # la grilla 2x2 de antes apretaba 2 gráficos de 7 equipos + Promedio (8 series c/u) al 50% del
        # ancho -- se pasan los 4 a ancho completo, uno por fila. A los dos de evolución (Precio de la
        # Acción, Beneficio Neto Acumulado) se les sube la altura (420px vs. los 370px fijos del
        # resto de la app) porque son los que más se leían apretados; el Desglose y el de Dividendos
        # vs. Retorno (bar chart simple) se dejan con la altura estándar.
        ing_emp = ingresos_vals.get(empresa_analisis)
        if ing_emp:
            # Adenda 26: etiquetas renombradas a pedido del equipo (mismo dato/ratio de antes,
            # solo cambia el texto que se lee en el eje Y -- ver punto (B) arriba).
            filas_cs = [
                ('Ingresos por ventas', 100.0, ing_emp),
                ('Margen Bruto', margen_vals.get(empresa_analisis), None),
                ('EBITDA', ebitda_pct_vals.get(empresa_analisis), ebitda_vals.get(empresa_analisis)),
                ('EBIT / Resultado Operativo', ebit_pct_vals.get(empresa_analisis), ebit_usd_vals.get(empresa_analisis)),
                ('Beneficio Neto', ros_vals.get(empresa_analisis), beneficio_neto_vals.get(empresa_analisis)),
            ]
            filas_cs = [(n, p, u) for n, p, u in filas_cs if pd.notna(p)]
            if filas_cs:
                cs_df = pd.DataFrame(filas_cs, columns=['Concepto', 'Pct', 'USD'])
                cs_df['Etiqueta'] = cs_df.apply(lambda r: f"{r['Pct']:.1f}% ({format_num(r['USD'])})" if pd.notna(r['USD']) else f"{r['Pct']:.1f}%", axis=1)
                # Color = identidad del EQUIPO EN FOCO (COLOR_MAP ya resuelve lila solo si es CADIZ).
                fig_cs = px.bar(cs_df.iloc[::-1], x='Pct', y='Concepto', orientation='h', text='Etiqueta',
                                 color_discrete_sequence=[COLOR_MAP.get(empresa_analisis, COLOR_CADIZ)],
                                 title=f'Desglose de Ingresos y Márgenes (% de Ingresos) — {empresa_analisis}, {ronda_snapshot}')
                fig_cs.update_traces(textposition='outside', cliponaxis=False)
                # Adenda 27: se sacan los títulos de los dos ejes (a pedido del equipo) -- las
                # etiquetas de categoría (eje Y) y los valores de % (eje X, con el texto de cada
                # barra) ya se entienden solos, sin necesidad de un título de eje aparte.
                fig_cs.update_layout(xaxis_title=None, yaxis_title=None, showlegend=False)
                # Adenda 26: se saca ocultar_eje_valores='y' -- a pedido del equipo, ahora se
                # fuerza a mostrar el nombre de cada concepto sobre el eje vertical (antes
                # quedaba en blanco a la izquierda, solo con la barra y el texto de afuera).
                mostrar(fig_cs)
                # Adenda 27: se saca el caption de abajo (a pedido del equipo, "no es necesario").
            else:
                st.info('Sin datos de márgenes para esta combinación.')
        else:
            st.info('Sin datos de Ingresos por ventas para esta combinación.')

        precio_sub = df[(df['Estado'] == 'Ratios e indicadores financieros clave') & (df['Metrica'] == 'Precio de la acción al final de la ronda, USD')]
        chart_evolucion(precio_sub, 'Precio de la Acción (USD)', altura=420)

        # Beneficio Neto Acumulado: se traslada ACÁ desde Resultados (Adenda 34, "sacar gráficos
        # de líneas de Resultados... agregar evolución del beneficio neto en Finanzas") -- misma
        # lógica, sin cambios: CESIM NO publica un acumulado de 'Beneficio de la ronda' (es el
        # resultado DE ESA ronda únicamente), así que se acumula ronda a ronda por equipo. Dato
        # 100% real acumulado por nosotros, no una proyección ni un supuesto de valor. El x1000
        # de "miles USD" ya lo aplica cesim_parser (Adenda 32, centralizado).
        bn_sub = df[(df['Estado'] == 'Cuenta de resultados, miles USD, Global') &
                    (df['Metrica'] == 'Beneficio de la ronda')].copy()
        bn_sub['Valor'] = num(bn_sub['Valor'])
        bn_sub = bn_sub.dropna(subset=['Valor']).sort_values('Ronda_Orden')
        bn_sub['Valor'] = bn_sub.groupby('Empresa')['Valor'].cumsum()
        chart_evolucion(bn_sub, 'Beneficio Neto Acumulado (USD, desde Año 0)', altura=420)

        # ---- Bloque 2: Retorno al Accionista ----
        # Adenda 37 (a pedido del equipo, reemplaza el combo de una sola ronda de arriba -- "quizás
        # sea mejor mostrar con barras apiladas los dividendos pagados ronda a ronda"). CORRECCIÓN a
        # un informe anterior: ahí se había dicho (sin verificar lo suficiente) que CESIM NO publica
        # un monto absoluto de dividendos pagados -- es falso, verificado contra el RDOS real de este
        # repo: 'Flujo de efectivo de casa matriz, miles USD' -> Actividades Financieras ->
        # 'Dividendos' SÍ trae el monto real en USD pagado por cada una de las 7 empresas, cada año
        # (signo negativo = salida de caja; se muestra en valor absoluto, como "monto pagado"). No se
        # repite acá el Retorno acumulado (%) como evolución -- el equipo señaló que ya está en
        # Resultados ('Retorno Total Acumulado del Accionista (TSR), %', chart_evolucion) y
        # duplicarlo no suma.
        st.write('')
        st.subheader('Retorno al Accionista')
        vista_ret_acc = st.radio(
            'Vista de distribución de caja al accionista',
            ['Mix Acumulado: Dividendos vs. Recompra de Acciones', 'Desglose por Año — Dividendos', 'Desglose por Año — Recompra de Acciones'],
            horizontal=True, key='radio_vista_ret_acc')

        div_pagados = df[(df['Estado'] == 'Flujo de efectivo de casa matriz, miles USD') &
                          (df['Metrica'] == 'Dividendos')].copy()
        div_pagados['Valor'] = num(div_pagados['Valor']).abs()
        div_pagados = div_pagados.dropna(subset=['Valor'])
        div_pagados = div_pagados[div_pagados['Ronda_Orden'] > 0]

        recompras_raw = df[(df['Estado'] == 'Flujo de efectivo de casa matriz, miles USD') &
                            (df['Metrica'] == 'Recaudación de emisión de patrimonio neto y recompras')].copy()
        recompras_raw['Valor'] = (-num(recompras_raw['Valor'])).clip(lower=0.0)
        recompras_raw = recompras_raw.dropna(subset=['Valor'])
        recompras_raw = recompras_raw[recompras_raw['Ronda_Orden'] > 0]

        if vista_ret_acc == 'Mix Acumulado: Dividendos vs. Recompra de Acciones':
            sum_div = div_pagados.groupby('Empresa')['Valor'].sum().reindex(COMPANIES).fillna(0.0)
            sum_rec = recompras_raw.groupby('Empresa')['Valor'].sum().reindex(COMPANIES).fillna(0.0)
            tot_dist = (sum_div + sum_rec).sort_values(ascending=False)
            empresas_orden = tot_dist.index.tolist()
            umbral_mix = tot_dist.max() * 0.06 if tot_dist.max() > 0 else 1.0
            fig_mix_ret = go.Figure()
            fig_mix_ret.add_trace(go.Bar(
                x=empresas_orden, y=[sum_div[e] for e in empresas_orden], name='Dividendos Acumulados',
                marker_color=[COLOR_CADIZ if e == MY_COMPANY else COLOR_METRICA['dinero'] for e in empresas_orden],
                text=[format_num(sum_div[e]) if sum_div[e] >= umbral_mix else '' for e in empresas_orden],
                textposition='inside', textfont=dict(size=11),
                customdata=[format_num(sum_div[e]) for e in empresas_orden],
                hovertemplate='<b>%{x}</b><br>Dividendos Acumulados: %{customdata}<extra></extra>'))
            fig_mix_ret.add_trace(go.Bar(
                x=empresas_orden, y=[sum_rec[e] for e in empresas_orden], name='Recompra de Acciones Acumulada',
                marker_color=[_hex_a_rgba(COLOR_CADIZ, 0.55) if e == MY_COMPANY else COLOR_METRICA['riesgo'] for e in empresas_orden],
                text=[format_num(sum_rec[e]) if sum_rec[e] >= umbral_mix else '' for e in empresas_orden],
                textposition='inside', textfont=dict(size=11),
                customdata=[format_num(sum_rec[e]) for e in empresas_orden],
                hovertemplate='<b>%{x}</b><br>Recompra de Acciones Acumulada: %{customdata}<extra></extra>'))
            color_total = BRAND_LIGHT if es_modo_oscuro() else BRAND_DARK
            for emp in empresas_orden:
                fig_mix_ret.add_annotation(
                    x=emp, y=tot_dist[emp], text=f'<b>{format_num(tot_dist[emp])}</b>',
                    showarrow=False, yshift=14,
                    font=dict(size=13, color=COLOR_CADIZ if emp == MY_COMPANY else color_total))
            fig_mix_ret.update_layout(
                barmode='stack', title='Caja Total Devuelta al Accionista (Dividendos + Recompras de Acciones)',
                yaxis_title='USD', xaxis=dict(categoryorder='array', categoryarray=empresas_orden),
                legend=dict(orientation='h', yanchor='top', y=-0.18, xanchor='center', x=0.5))
            mostrar(fig_mix_ret, margen_b=90, altura=420)
            st.caption('Compara las dos vías reales para devolver caja al accionista sin recargar el gráfico: '
                       'Dividendos pagados (barra inferior) + Recompra de acciones acumulada (barra superior). '
                       'Cambiá el selector de arriba si querés ver en qué año puntual se ejecutó cada desembolso.')
        else:
            es_div = vista_ret_acc.endswith('Dividendos')
            df_serie_ret = div_pagados if es_div else recompras_raw
            titulo_ret = 'Dividendos Pagados Acumulados por Empresa (Desglose por Año)' if es_div else 'Recompra de Acciones Acumulada por Empresa (Desglose por Año)'
            if df_serie_ret.empty or df_serie_ret['Valor'].sum() == 0:
                st.info('Sin desembolsos registrados para esta modalidad.')
            else:
                totales_emp = df_serie_ret.groupby('Empresa')['Valor'].sum().reindex(COMPANIES).fillna(0.0).sort_values(ascending=False)
                empresas_orden = totales_emp.index.tolist()
                rondas_presentes = df_serie_ret[['Ronda', 'Ronda_Orden']].drop_duplicates().sort_values('Ronda_Orden')
                nombres_ronda = rondas_presentes['Ronda'].tolist()
                n_r = len(nombres_ronda)
                ramp_cadiz = _ramp_secuencial(COLOR_CADIZ, n_r)
                ramp_rival = _ramp_secuencial(COLOR_METRICA['dinero'] if es_div else COLOR_METRICA['riesgo'], n_r)
                tonos_por_ronda_empresa = {}
                for emp in empresas_orden:
                    ramp = ramp_cadiz if emp == MY_COMPANY else ramp_rival
                    for i, r_nombre in enumerate(nombres_ronda):
                        tonos_por_ronda_empresa[(emp, r_nombre)] = ramp[i]
                umbral_label = totales_emp.max() * 0.05
                fig_divp = go.Figure()
                for r_nombre in nombres_ronda:
                    d_r = df_serie_ret[df_serie_ret['Ronda'] == r_nombre].set_index('Empresa').reindex(empresas_orden)
                    fig_divp.add_trace(go.Bar(
                        x=empresas_orden, y=d_r['Valor'], name=r_nombre,
                        marker_color=[tonos_por_ronda_empresa[(emp, r_nombre)] for emp in empresas_orden],
                        text=d_r['Valor'].apply(lambda v: format_num(v) if pd.notna(v) and v >= umbral_label else ''),
                        textposition='inside', textfont=dict(size=11),
                        customdata=d_r['Valor'].apply(lambda v: format_num(v) if pd.notna(v) else 'sin dato'),
                        hovertemplate=f'<b>%{{x}}</b><br>{r_nombre}: %{{customdata}}<extra></extra>'))
                fig_divp.update_layout(barmode='stack', title=titulo_ret,
                                        yaxis_title='USD', xaxis=dict(categoryorder='array', categoryarray=empresas_orden),
                                        legend=dict(orientation='h', yanchor='top', y=-0.18, xanchor='center', x=0.5))
                color_total = BRAND_LIGHT if es_modo_oscuro() else BRAND_DARK
                for emp in empresas_orden:
                    fig_divp.add_annotation(x=emp, y=totales_emp[emp], text=f'<b>{format_num(totales_emp[emp])}</b>',
                                             showarrow=False, yshift=14,
                                             font=dict(size=13, color=COLOR_CADIZ if emp == MY_COMPANY else color_total))
                mostrar(fig_divp, margen_b=90, altura=420)

        # ---- Bloque 3: Riesgo Competitivo ----
        # Adenda 37 (a pedido del equipo, inspirado en un gráfico de referencia de un profesor:
        # "Capacidad de Distribución de Dividendos", Ganancias Acumuladas + Beneficio de la ronda vs.
        # Caja Real). Objetivo: anticipar qué equipos tienen margen para un dividendo grande en la
        # PRÓXIMA ronda. Verificado 100% con datos reales de la Hoja de Balance y la Cuenta de
        # Resultados (Global), las 7 empresas: 'Ganancias acumuladas' se toma al CIERRE DE LA RONDA
        # ANTERIOR (antes de sumar el beneficio de esta ronda, para no mezclar el stock ya cerrado con
        # el flujo de este año) + 'Beneficio de la ronda' (el de esta ronda, puede ser negativo) dan
        # el techo TEÓRICO de lo repartible; 'Efectivo y equivalentes de efectivo' (el real, de esta
        # ronda) es lo que de verdad hay en caja. La brecha entre ambos es capital de trabajo, deuda o
        # inversión que no está disponible para repartir aunque "en el papel" sobre.
        st.write('')
        st.subheader('Riesgo Competitivo')
        ronda_prev_cap = ronda_anterior_de(ronda_snapshot)
        ganancias_prev_vals = {}
        if ronda_prev_cap:
            bal_prev_cap = df[(df['Estado'] == 'Hoja de Balance, miles USD, Global') & (df['Ronda'] == ronda_prev_cap)]
            ganancias_prev_vals = {e: valor_de(bal_prev_cap, 'Ganancias acumuladas', e) for e in COMPANIES}
        efectivo_vals = {e: valor_de(bal_ronda, 'Efectivo y equivalentes de efectivo', e) for e in COMPANIES}
        filas_cap = []
        for e in COMPANIES:
            ga, bn, ef = ganancias_prev_vals.get(e), beneficio_neto_vals.get(e), efectivo_vals.get(e)
            if ga is None and bn is None:
                continue
            filas_cap.append({'Empresa': e, 'GananciasPrev': ga or 0.0, 'Beneficio': bn or 0.0, 'Efectivo': ef})
        dfcap = pd.DataFrame(filas_cap)
        if dfcap.empty:
            st.info('Sin datos de Balance/Resultados suficientes para estimar capacidad de pago en este año.')
        else:
            dfcap['Total'] = dfcap['GananciasPrev'] + dfcap['Beneficio']
            dfcap = dfcap.sort_values('Total', ascending=False)
            etq_prev = ronda_prev_cap or 'la ronda anterior'
            # Fix de legibilidad + identidad (mismo pedido que en "Retorno al Accionista"): CADIZ en
            # lila para diferenciarse del resto (identidad), y etiqueta de texto solo en segmentos
            # que superan un umbral -- acá un umbral ABSOLUTO (5% del mayor total entre las 7
            # empresas), no relativo a cada barra, para que un segmento de tamaño parecido se trate
            # igual en todos lados del gráfico.
            umbral_cap = dfcap['Total'].abs().max() * 0.05
            def _etq_cap(v):
                return format_num(v) if pd.notna(v) and abs(v) >= umbral_cap else ''
            fig_cap = go.Figure()
            fig_cap.add_trace(go.Bar(x=dfcap['Empresa'], y=dfcap['GananciasPrev'], name=f'Ganancias Acumuladas (cierre {etq_prev})',
                                      marker_color=[COLOR_CADIZ if e == MY_COMPANY else COLOR_METRICA['dinero'] for e in dfcap['Empresa']],
                                      text=dfcap['GananciasPrev'].apply(_etq_cap), textposition='inside', textfont=dict(size=11),
                                      hovertemplate=f'<b>%{{x}}</b><br>Ganancias Acumuladas (cierre {etq_prev}): %{{y:,.0f}}<extra></extra>'))
            fig_cap.add_trace(go.Bar(x=dfcap['Empresa'], y=dfcap['Beneficio'], name=f'Beneficio de {ronda_snapshot}',
                                      marker_color=[COLOR_METRICA['eficiencia'] if v >= 0 else COLOR_METRICA['critico'] for v in dfcap['Beneficio']],
                                      text=dfcap['Beneficio'].apply(_etq_cap), textposition='inside', textfont=dict(size=11),
                                      hovertemplate=f'<b>%{{x}}</b><br>Beneficio de {ronda_snapshot}: %{{y:,.0f}}<extra></extra>'))
            # Fix (a pedido del equipo, viendo la referencia que mandó): línea conectada en vez de
            # rombos sueltos -- se lee mejor la caída/suba de equipo a equipo (mismo orden del eje X
            # que las barras, de mayor a menor capacidad teórica).
            fig_cap.add_trace(go.Scatter(x=dfcap['Empresa'], y=dfcap['Efectivo'], name='Efectivo real disponible',
                                          mode='lines+markers',
                                          line=dict(color=COLOR_METRICA['riesgo'], width=2.5),
                                          marker=dict(symbol='circle', size=10, color=COLOR_METRICA['riesgo'],
                                                       line=dict(width=1.5, color=BRAND_DARK if not es_modo_oscuro() else BRAND_LIGHT)),
                                          hovertemplate='<b>%{x}</b><br>Efectivo real disponible: %{y:,.0f}<extra></extra>'))
            fig_cap.update_layout(barmode='relative', title=f'Capacidad de pago de dividendos — {ronda_snapshot}',
                                   yaxis_title='USD',
                                   legend=dict(orientation='h', yanchor='top', y=-0.18, xanchor='center', x=0.5))
            mostrar(fig_cap, margen_b=90, altura=420)
            st.caption(f'Barra (azul, lila para ULTI) + verde/rojo = techo teórico de lo repartible (Ganancias '
                       f'Acumuladas al cierre de {etq_prev} + Beneficio de {ronda_snapshot}, antes de cualquier '
                       'dividendo de esta ronda). Línea = Efectivo real disponible. Un equipo con barra alta y '
                       'línea baja tiene "ganancias de papel" sin respaldo en caja -- poco probable que pague '
                       'mucho la próxima ronda; barra y línea parejas es la señal de que sí podría.')
        st.write('')

        # ---- Bloque 4: Estructura Financiera ----
        st.subheader('Estructura Financiera')
        # ---- Estructura del Balance (reposicionada -- antes vivía en la pestaña "Largo Plazo") ----
        st.markdown('**Estructura del Balance: Activo vs. Pasivo + Patrimonio Neto**')

        def gb(metrica):
            return valor_de(bal_ronda, metrica, empresa_analisis) or 0.0

        activo_items = {'Efectivo y equivalentes': gb('Efectivo y equivalentes de efectivo'),
                         'Cuentas por cobrar': gb('Cuentas por Cobrar'), 'Inventario': gb('Inventario'),
                         'Activo fijo': gb('Activo fijo')}
        pasivo_pn_items = {'Cuentas por pagar': gb('Cuentas por pagar'),
                            'Deudas CP no planificadas': gb('Deudas a corto plazo (no planificadas)'),
                            'Deudas LP': gb('Deudas a largo plazo'),
                            'Capital social + adicional': gb('Capital social') + gb('Capital adicional desembolsado'),
                            'Ganancias acumuladas + de la ronda': gb('Ganancias acumuladas') + gb('Beneficio de la ronda')}
        if sum(activo_items.values()) > 0:
            fig_bal = go.Figure()
            # Paletas separadas por lado: antes el verde era "Activo fijo" a la izquierda y
            # "Deudas LP" a la derecha, y el tan era "Inventario" y "Ganancias acumuladas".
            # Con la misma paleta de los dos lados parecía que un color significaba lo mismo.
            colores_activo = ['#3E7CB1', '#5C9BC9', '#8FBEDC', '#C3DCEC']          # azules  = qué tengo
            colores_pasivo = ['#C9922E', '#B3261E', '#8C6D3F', '#6E8C6E', '#A8A29A']  # cálidos = quién lo financia
            for (nombre, val), color in zip(activo_items.items(), colores_activo):
                fig_bal.add_trace(go.Bar(x=['Activo'], y=[val], name=nombre, marker_color=color,
                                          text=format_num(val), textposition='inside', showlegend=False))
            for (nombre, val), color in zip(pasivo_pn_items.items(), colores_pasivo):
                fig_bal.add_trace(go.Bar(x=['Pasivo + PN'], y=[val], name=nombre, marker_color=color,
                                          text=format_num(val), textposition='inside', showlegend=False))
            fig_bal.update_layout(
                barmode='stack', title=f'Estructura del Balance — {empresa_analisis}, {ronda_snapshot}',
                # Dos leyendas separadas, cada una pegada a la barra que le corresponde —
                # antes una sola leyenda combinada hacía difícil saber qué color era de qué lado.
                showlegend=False)
            mostrar(fig_bal, ocultar_eje_valores='y')
            # La leyenda de Plotly, aun puesta afuera, mezclaba los conceptos de los dos lados en
            # una sola tira. Se dibuja a mano en dos columnas, cada una bajo su barra, para que
            # se vea de una qué compone el Activo y qué compone el Pasivo + PN.
            def bloque_leyenda(titulo, items, colores):
                filas = ''.join(
                    f'<div style="display:flex;align-items:center;gap:8px;margin:3px 0;font-size:0.82rem">'
                    f'<span style="width:11px;height:11px;border-radius:3px;background:{c};flex:none"></span>'
                    f'<span style="flex:1">{n}</span>'
                    f'<span style="opacity:0.65">{format_num(v)}</span></div>'
                    for (n, v), c in zip(items.items(), colores))
                return (f'<div style="font-weight:600;font-size:0.8rem;opacity:0.7;text-transform:uppercase;'
                        f'letter-spacing:0.02em;margin-bottom:4px">{titulo}</div>{filas}')
            col_leg_a, col_leg_p = st.columns(2)
            with col_leg_a:
                st.markdown(bloque_leyenda('Activo', activo_items, colores_activo), unsafe_allow_html=True)
            with col_leg_p:
                st.markdown(bloque_leyenda('Pasivo + PN', pasivo_pn_items, colores_pasivo), unsafe_allow_html=True)
            st.caption('Los dos lados deben dar la misma altura (el Balance siempre cierra) — Activo total = Pasivo + Patrimonio Neto.')
        else:
            st.info('Sin datos de balance para esta combinación.')

        # ---- 3 KPIs junto al Balance: WACC, ROCE, Deuda LP ----
        # Adenda 23 (a pedido del equipo): ROA no lo publica CESIM como ratio propio (verificado -- no
        # está en 'Ratios e indicadores financieros clave') así que se calcula acá con la fórmula
        # estándar Beneficio Neto / Activos Totales (Global) -- es una métrica de análisis financiero de
        # manual de cátedra, no una regla CESIM, así que se documenta como tal.
        def _roa(emp):
            ben = valor_de(pl_ronda, 'Beneficio de la ronda', emp)
            act = valor_de(bal_ronda, 'Activos Totales', emp)
            if ben is None or not act:
                return None
            return ben / act * 100

        # Orden pedido por el equipo para el Rango de Industria: WACC, Apalancamiento, ROA, ROE, ROCE.
        datos_lp = {
            'WACC': {e: wacc(e) for e in COMPANIES},
            'Apalancamiento': {e: valor_de(ratios_ronda, 'Endeudamiento neto/patrimonio (apalancamiento)', e) for e in COMPANIES},
            'ROA': {e: _roa(e) for e in COMPANIES},
            'ROE': {e: valor_de(ratios_ronda, 'Rendimiento de los Fondos Propios (ROE)', e) for e in COMPANIES},
            'ROCE': {e: valor_fuzzy(ratios_ronda, 'Rentabilidad del capital empleado', empresa=e) for e in COMPANIES},
        }
        ronda_prev_lp = ronda_anterior_de(ronda_snapshot)

        # FIX (a pedido del equipo: "no me convence como quedaron los kpis" -- ROA +10879.3%, ROS
        # +1168.4%, valores sin sentido). Causa raíz confirmada: WACC/ROCE/ROA/ROS YA son porcentajes,
        # pero sus deltas (tanto "vs año anterior" como "vs Industria") se calculaban con la fórmula de
        # % RELATIVO que usa el resto de la app para magnitudes monetarias -- (val - base) / abs(base)
        # * 100 -- que explota cuando `base` (el valor previo, o el promedio de los 7 equipos) está
        # cerca de 0: una ROA que pasa de +0.05% a +5.4%, o un promedio de industria de ROS ~0.1%,
        # produce variaciones de miles de %, matemáticamente correctas pero inútiles para decidir.
        # Fix: estos 4 KPIs pasan al mismo criterio de PUNTOS PORCENTUALES (p.p.) que ya usa el
        # Margen/Markup de Operaciones y el "Spread de Creación de Valor" más abajo -- diferencia
        # DIRECTA (val_act - val_base), sin dividir por nada, acotada por construcción al rango real
        # de la métrica. Deuda LP (un monto en USD, no un %) NO se toca -- ahí el % relativo sigue
        # siendo la unidad correcta.
        def _delta_pp(val_act, val_base):
            if val_act is None or val_base is None or pd.isna(val_act) or pd.isna(val_base):
                return None
            return val_act - val_base

        def _delta_ind_pp_lp(vals_dict):
            vals = [v for v in vals_dict.values() if v is not None and pd.notna(v)]
            val = vals_dict.get(empresa_analisis)
            if not vals or val is None or pd.isna(val):
                return None
            prom = np.nanmean(vals)
            return (val - prom) if pd.notna(prom) else None

        d_wacc_ronda = d_roce_ronda = d_ros_ronda = None
        if ronda_prev_lp:
            val_ronda_prev = df[(df['Estado'] == 'Valuación - Global') & (df['Ronda'] == ronda_prev_lp)]
            ratios_ronda_prev = df[(df['Estado'] == 'Ratios e indicadores financieros clave') & (df['Ronda'] == ronda_prev_lp)]
            wacc_prev, wacc_act = wacc(empresa_analisis, val_ronda_prev), wacc(empresa_analisis)
            d_wacc_ronda = _delta_pp(wacc_act, wacc_prev)
            roce_prev = valor_fuzzy(ratios_ronda_prev, 'Rentabilidad del capital empleado', empresa=empresa_analisis)
            roce_act = valor_fuzzy(ratios_ronda, 'Rentabilidad del capital empleado', empresa=empresa_analisis)
            d_roce_ronda = _delta_pp(roce_act, roce_prev)
            ros_prev = valor_de(ratios_ronda_prev, 'Rentabilidad de las ventas (ROS)', empresa_analisis)
            d_ros_ronda = _delta_pp(ros_vals.get(empresa_analisis), ros_prev)
        d_wacc_ind, d_roce_ind = _delta_ind_pp_lp(datos_lp['WACC']), _delta_ind_pp_lp(datos_lp['ROCE'])
        d_deuda_lp_ronda, _ = delta_vs_ronda_anterior('Hoja de Balance, miles USD, Global', 'Deudas a largo plazo')
        d_deuda_lp_ind = delta_raw(deuda_lp_vals)
        st.write('')
        col_w1, col_w2, col_w3 = st.columns(3)
        with col_w1:
            # WACC: costo de financiarse -- menos es mejor, favorable invertido.
            kpi_doble_delta(None, 'WACC', f"{datos_lp['WACC'].get(empresa_analisis):,.1f}%" if pd.notna(datos_lp['WACC'].get(empresa_analisis)) else '—',
                             d_ronda=d_wacc_ronda, ronda_prev_nombre=ronda_prev_fin, favorable_ronda=(d_wacc_ronda < 0) if d_wacc_ronda is not None else None,
                             d_industria=d_wacc_ind, favorable_industria=(d_wacc_ind < 0) if d_wacc_ind is not None else None, unidad=' p.p.')
        with col_w2:
            kpi_doble_delta(None, 'ROCE', f"{datos_lp['ROCE'].get(empresa_analisis):,.1f}%" if pd.notna(datos_lp['ROCE'].get(empresa_analisis)) else '—',
                             d_ronda=d_roce_ronda, ronda_prev_nombre=ronda_prev_fin, d_industria=d_roce_ind, unidad=' p.p.')
        with col_w3:
            # Deuda LP: menos es mejor, favorable invertido.
            kpi_doble_delta(None, 'Deuda LP (USD)', format_num(deuda_lp_vals.get(empresa_analisis)),
                             d_ronda=d_deuda_lp_ronda, ronda_prev_nombre=ronda_prev_fin, favorable_ronda=(d_deuda_lp_ronda < 0) if d_deuda_lp_ronda is not None else None,
                             d_industria=d_deuda_lp_ind, favorable_industria=(d_deuda_lp_ind < 0) if d_deuda_lp_ind is not None else None)
        st.caption('WACC y ROCE: deltas en puntos porcentuales (p.p.), no % relativo -- mismo criterio que Margen/Markup '
                   '(ver Operaciones) y el Spread de abajo, para no exagerar variaciones cuando el año anterior o el '
                   'promedio de industria están cerca de 0%.')

        # ---- KPI ROA y ROS (Adenda 34, a pedido del equipo) ----
        # ROA ya se calculaba más arriba (datos_lp['ROA'], vía _roa()) pero solo se veía adentro del
        # gráfico "Rango de Industria" -- acá se agrega como tarjeta propia, mismo criterio que
        # WACC/ROCE/Deuda LP de arriba. ROS ('Rentabilidad de las ventas (ROS)') ya se calculaba para
        # el Gráfico 1 (ros_vals) -- mismo caso, se agrega como tarjeta propia además de seguir
        # alimentando ese gráfico. Deltas en p.p. -- ver nota de WACC/ROCE más arriba.
        d_roa_ronda = None
        if ronda_prev_lp:
            pl_ronda_prev_roa = df[(df['Estado'] == 'Cuenta de resultados, miles USD, Global') & (df['Ronda'] == ronda_prev_lp)]
            bal_ronda_prev_roa = df[(df['Estado'] == 'Hoja de Balance, miles USD, Global') & (df['Ronda'] == ronda_prev_lp)]
            ben_prev_roa = valor_de(pl_ronda_prev_roa, 'Beneficio de la ronda', empresa_analisis)
            act_prev_roa = valor_de(bal_ronda_prev_roa, 'Activos Totales', empresa_analisis)
            roa_prev = (ben_prev_roa / act_prev_roa * 100) if act_prev_roa else None
            d_roa_ronda = _delta_pp(datos_lp['ROA'].get(empresa_analisis), roa_prev)
        d_roa_ind, d_ros_ind = _delta_ind_pp_lp(datos_lp['ROA']), _delta_ind_pp_lp(ros_vals)
        col_roa, col_ros = st.columns(2)
        with col_roa:
            kpi_doble_delta(None, 'ROA', f"{datos_lp['ROA'].get(empresa_analisis):,.1f}%" if pd.notna(datos_lp['ROA'].get(empresa_analisis)) else '—',
                             d_ronda=d_roa_ronda, ronda_prev_nombre=ronda_prev_fin, d_industria=d_roa_ind, unidad=' p.p.')
        with col_ros:
            kpi_doble_delta(None, 'ROS', f"{ros_vals.get(empresa_analisis):,.1f}%" if pd.notna(ros_vals.get(empresa_analisis)) else '—',
                             d_ronda=d_ros_ronda, ronda_prev_nombre=ronda_prev_fin, d_industria=d_ros_ind, unidad=' p.p.')

        # ---- Spread de Creación de Valor + Composición de Estructura de Capital (Adenda 26, a ----
        # ---- pedido del equipo: "debajo o cerca de los kpis de wacc, roce y deuda lp") ---------
        st.write('')
        roce_focal, wacc_focal = datos_lp['ROCE'].get(empresa_analisis), datos_lp['WACC'].get(empresa_analisis)
        spread = (roce_focal - wacc_focal) if (pd.notna(roce_focal) and pd.notna(wacc_focal)) else None
        de_focal = valor_de(val_ronda, 'Deuda a patrimonio', empresa_analisis)
        col_sp, col_wc = st.columns(2)
        with col_sp:
            # Spread = ROCE − WACC: fórmula de manual de cátedra (Categoría 3, no un ratio propio de
            # CESIM) a partir de dos ratios que CESIM sí publica y que ya están arriba (WACC, ROCE).
            kpi_doble_delta(None, 'Spread de Creación de Valor (ROCE − WACC)',
                             f"{spread:+.1f} p.p." if spread is not None else '—', unidad=' p.p.')
            st.caption('ROCE > WACC = el año creó valor para el accionista (el capital empleado rindió más de lo '
                       'que costó financiarlo); ROCE < WACC = lo destruyó.')
        with col_wc:
            if de_focal is not None and pd.notna(de_focal) and de_focal >= 0:
                # Mismos pesos que usa wacc() de arriba: de/(1+de) pondera el costo de la deuda,
                # 1/(1+de) pondera el retorno esperado del patrimonio -- se visualiza esa relación
                # como % Deuda / % Patrimonio Neto (Equity) de la estructura de capital.
                peso_deuda = de_focal / (1 + de_focal) * 100
                peso_equity = 100 - peso_deuda
                fig_wacc_c = go.Figure()
                fig_wacc_c.add_trace(go.Bar(x=[peso_deuda], y=['Estructura'], orientation='h', name='Deuda',
                                             marker_color=COLOR_METRICA['riesgo'],
                                             text=f'Deuda {peso_deuda:.0f}%', textposition='inside'))
                # Adenda 28 (feedback "más contraste, paleta única"): Equity pasa de MUTED_PALETTE[2]
                # (sage -- reprobó el validador de contraste, ΔE 13.4 contra el ámbar de Deuda, por
                # debajo del piso de 15) a COLOR_METRICA['dinero'] (azul), el mismo azul que ahora abre
                # MUTED_SIN_MARRON -- así este gráfico y el de Mix tecnológico comparten paleta.
                fig_wacc_c.add_trace(go.Bar(x=[peso_equity], y=['Estructura'], orientation='h', name='Patrimonio Neto (Equity)',
                                             marker_color=COLOR_METRICA['dinero'],
                                             text=f'Equity {peso_equity:.0f}%', textposition='inside'))
                fig_wacc_c.update_layout(barmode='stack', showlegend=False,
                                          title=f'Composición de Estructura de Capital (ponderación del WACC) — {empresa_analisis}',
                                          xaxis=dict(range=[0, 100], ticksuffix='%'))
                # Adenda 27 (a pedido del equipo: "que quede del mismo tamaño que el kpi de creación
                # de valor"): altura chica en vez de la ALTURA_TARJETA fija (370px) que usa el resto
                # de los gráficos -- acá se lo compara con una tarjeta kpi_doble_delta de al lado
                # (col_sp), mucho más baja, y sin leyenda abajo no hace falta el margen extra.
                mostrar(fig_wacc_c, ocultar_eje_valores='y', altura=150, margen_b=10)
                st.caption('Ponderación usada en el cálculo de WACC de arriba: Deuda a patrimonio / (1 + Deuda a '
                           'patrimonio) para la Deuda, y 1 / (1 + Deuda a patrimonio) para el Patrimonio Neto.')
            else:
                st.info('Sin datos de Deuda a patrimonio para esta combinación.')

        st.write('')
        st.markdown('**Ubicación de Ganancias (EBT) y Presión Fiscal Efectiva por Región**')
        st.caption('Muestra en qué región declara su ganancia antes de impuestos (EBT) cada equipo y cuánto paga de impuesto corporativo. '
                   'Cuando una región tiene pérdidas acumuladas de rondas previas (quebranto impositivo), su impuesto pagado es $0 (0.0%) hasta agotar ese saldo a favor.')
        filas_ebt_reg = []
        for pais_t in ['EE.UU.', 'Asia', 'Europa']:
            pl_pt = df[(df['Estado'] == f'Cuenta de resultados, miles USD, {pais_t}') & (df['Ronda'] == ronda_snapshot)]
            for e in COMPANIES:
                v_ebt_p = valor_de(pl_pt, 'Beneficio antes de impuestos', e) or 0.0
                v_imp_p = valor_de(pl_pt, 'Impuesto sobre el beneficio', e) or 0.0
                tasa_p = (v_imp_p / v_ebt_p * 100) if v_ebt_p > 0 else 0.0
                filas_ebt_reg.append({'Empresa': e, 'Región': pais_t, 'EBT': v_ebt_p, 'Impuesto': v_imp_p, 'TasaReg': tasa_p})
        df_ebt_reg = pd.DataFrame(filas_ebt_reg)
        if not df_ebt_reg.empty and df_ebt_reg['EBT'].abs().sum() > 0:
            colores_reg_ebt = {'EE.UU.': MUTED_SIN_MARRON[1], 'Asia': MUTED_SIN_MARRON[2], 'Europa': MUTED_SIN_MARRON[0]}
            fig_ebt_tax = go.Figure()
            for pais_t in ['EE.UU.', 'Asia', 'Europa']:
                d_pt = df_ebt_reg[df_ebt_reg['Región'] == pais_t].set_index('Empresa').reindex(COMPANIES).reset_index()
                txt_hover = [f"EBT {pais_t}: ${format_num(r['EBT'])}<br>Impuesto pagado: ${format_num(r['Impuesto'])} ({r['TasaReg']:.1f}% sobre EBT de {pais_t})" for _, r in d_pt.iterrows()]
                fig_ebt_tax.add_trace(go.Bar(
                    x=d_pt['Empresa'], y=d_pt['EBT'], name=f'EBT {pais_t}',
                    marker_color=colores_reg_ebt[pais_t],
                    customdata=txt_hover, hovertemplate='<b>%{x}</b><br>%{customdata}<extra></extra>'))
            tot_pos = df_ebt_reg[df_ebt_reg['EBT'] > 0].groupby('Empresa')['EBT'].sum()
            imp_tot = df_ebt_reg.groupby('Empresa')['Impuesto'].sum()
            color_txt_t = BRAND_LIGHT if es_modo_oscuro() else BRAND_DARK
            for e in COMPANIES:
                y_top = tot_pos.get(e, 0.0)
                ebt_pos_e = tot_pos.get(e, 0.0)
                imp_e = imp_tot.get(e, 0.0)
                t_pos = (imp_e / ebt_pos_e * 100) if ebt_pos_e > 0 else 0.0
                etq_top = f'<b>Imp.: ${format_num(imp_e)} ({t_pos:.0f}%)</b>' if imp_e > 0 else '<b>Imp.: $0 (0%)</b>'
                fig_ebt_tax.add_annotation(
                    x=e, y=y_top, text=etq_top,
                    showarrow=False, yshift=14,
                    font=dict(size=11, color=COLOR_CADIZ if e == MY_COMPANY else color_txt_t))
            fig_ebt_tax.update_layout(
                barmode='relative',
                title=f'Beneficio antes de Impuestos (EBT) por Región e Impuesto Total Pagado — {ronda_snapshot}',
                yaxis_title='EBT (USD)',
                legend=dict(orientation='h', yanchor='top', y=-0.18, xanchor='center', x=0.5))
            mostrar(fig_ebt_tax, margen_b=85, altura=400)

        #-----------------------------------------------------------------
        # 8. RRHH -> Personal y Talento: Add 7-team benchmark of I+D Headcount, Salary & Efficiency Multiplier
        #-----------------------------------------------------------------

        # ---- Rango de Industria (recortado: WACC, Apalancamiento, ROA, ROE, ROCE -- sin Spread) ----
        ejes_validos = {k: v for k, v in datos_lp.items() if len([x for x in v.values() if pd.notna(x)]) >= 2}
        if ejes_validos:
            color_ref = 'rgba(255,255,255,0.5)' if es_modo_oscuro() else 'rgba(26,23,20,0.5)'
            fig_rango = go.Figure()
            for i, (nombre, vals) in enumerate(ejes_validos.items()):
                valores = sorted(v for v in vals.values() if pd.notna(v))
                vmin, vmax, vmed = valores[0], valores[-1], np.median(valores)
                vcadiz = vals.get(empresa_analisis)
                rango = (vmax - vmin) or 1
                pos = lambda x: (x - vmin) / rango * 100
                suf = "%" if nombre in ['ROCE', 'ROE', 'WACC', 'ROA'] else "x"

                fig_rango.add_trace(go.Scatter(x=[0, 100], y=[i, i], mode='lines', line=dict(color=MUTED_PALETTE[3], width=6), showlegend=False))
                # Adenda 25: se saca el marrón de la marca de mediana. No pasa a lila -- esta marca
                # convive con el marcador del equipo en foco (unas líneas más abajo), que puede ser
                # lila si el foco es CADIZ; usar lila acá también las confundiría.
                # Fix "ya casi": se reemplaza MUTED_PALETTE[5] por el azul acero nuevo, por consistencia
                # con el resto de la paleta "sin marrón" (mismo tono ya usado en el dumbbell de mercado).
                fig_rango.add_trace(go.Scatter(x=[pos(vmed)], y=[i], mode='markers', marker=dict(symbol='line-ns', size=16, color='#58759D', line_width=2), showlegend=False))

                if vcadiz is not None:
                    val_str = f"{vcadiz:,.1f}{suf}"
                    # Bug de identidad (Adenda 25, mismo caso que la tasa de interés más arriba):
                    # "vcadiz" es en realidad el valor del EQUIPO EN FOCO (empresa_analisis), que puede
                    # no ser CADIZ -- se resuelve con COLOR_MAP en vez de asumir siempre el color de
                    # marca.
                    color_foco = COLOR_MAP.get(empresa_analisis, COLOR_CADIZ)
                    fig_rango.add_trace(go.Scatter(
                        x=[pos(vcadiz)], y=[i],
                        mode='markers+text',
                        text=[val_str],
                        textposition="top center",
                        textfont=dict(color=color_foco, size=12, family="JetBrains Mono"),
                        marker=dict(size=14, color=color_foco),
                        showlegend=False
                    ))

                fig_rango.add_annotation(x=0, y=i, text=f'{vmin:,.1f}{suf}', showarrow=False, xshift=-30, font=dict(size=11, color=color_ref))
                fig_rango.add_annotation(x=100, y=i, text=f'{vmax:,.1f}{suf}', showarrow=False, xshift=30, font=dict(size=11, color=color_ref))

            fig_rango.update_layout(yaxis=dict(tickmode='array', tickvals=list(range(len(ejes_validos))), ticktext=list(ejes_validos.keys())), xaxis=dict(range=[-15, 115]), title='Rango de Industria (Mín / Mediana / ULTI / Máx)')
            mostrar(fig_rango, ocultar_eje_valores='x')

        # ---- Deuda y liquidez (Adenda 26: antes vivía en la pestaña "Corto Plazo", ahora acá) ----
        st.write('')
        st.subheader('Deuda y liquidez')
        # Adenda 26 (a pedido del equipo: "remover el gráfico de Evolución -- Deuda CP no
        # planificada, mantener únicamente la lógica condicional en segundo plano para disparar un
        # toast/banner de alerta solo si el valor llega a ser mayor a cero"): el gráfico de línea
        # temporal se saca. La regla "Sobregiro automático" YA existía en evaluar_alertas() y se ve
        # en el panel de alertas de Resultados -- acá se agrega el mismo disparo como st.toast() para
        # no perder la señal en Finanzas ahora que se sacó el gráfico que cumplía ese rol visual.
        deuda_cp_focal = deuda_cp_vals.get(empresa_analisis)
        if deuda_cp_focal and deuda_cp_focal > 0:
            st.toast(f'Sobregiro automático en {empresa_analisis}: {format_num(deuda_cp_focal)} USD de deuda CP '
                     f'no planificada en {ronda_snapshot} (detalle en el panel de Alertas, sección Resultados).',
                     icon='⚠️')
        ranking_deuda = pd.DataFrame(list(deuda_cp_vals.items()), columns=['Empresa', 'Valor']).dropna().sort_values('Valor', ascending=False)
        if not ranking_deuda.empty and ranking_deuda['Valor'].sum() > 0:
            ranking_deuda['Etiqueta'] = ranking_deuda['Valor'].apply(format_num)
            fig_dcp = px.bar(ranking_deuda, x='Empresa', y='Valor', color='Empresa', color_discrete_map=COLOR_MAP,
                              title=f'Deuda CP no planificada — {ronda_snapshot}', text='Etiqueta')
            fig_dcp.update_traces(textposition='outside', cliponaxis=False, showlegend=False)
            mostrar(fig_dcp, ocultar_eje_valores='y')
        else:
            st.info('Ningún equipo tomó deuda de corto plazo no planificada en este año.')

    # Adenda 29 (a pedido del equipo, "Control de Gestión" centralizado): se elimina la pestaña
    # 'Comparativa Plan vs. Real' -- ver mismo comentario en seccion_resultado(). El panel de barras
    # horizontales (chart_bullet_panel con CROSSWALK_FINANZAS) pasa al Nivel 1 de 'Control de
    # Gestión', con el mismo criterio de esta Adenda 26/27 (mostrar_metricas=False,
    # mostrar_extras=False -- SOLO el panel, sin reactivar fila3_finanzas_flujo_caja(), el puente
    # CFO->CFI->CFF, que sigue definida sin uso más arriba por si se retoma).
    # =================================================================
    # SECCIÓN 5 — RRHH Y SOSTENIBILIDAD
    # =================================================================
def seccion_rrhh_sostenibilidad():
    bloque_rrhh, bloque_sost = st.tabs(['Personal y Talento', 'Sostenibilidad'])

    with bloque_rrhh:
        rrhh = df_all[(df_all['Estado'] == 'Informe de RRHH') & (df_all['Empresa'] == empresa_analisis)].copy()
        rrhh['Valor'] = num(rrhh['Valor'])

        # Adenda 34 (a pedido del equipo): se sacan los gráficos "Rotación vs. Contrataciones netas"
        # e "Inversión en I+D: costo vs. dotación" -- quedan solo "Salario y rotación" y
        # "Capacitación e impacto", ahora en una grilla de 2 columnas (antes eran 2 filas de 2).
        col_a, col_d = st.columns(2)
        with col_a:
            st.subheader('Salario y rotación')
            salario = rrhh[rrhh['Metrica'] == 'Salario mensual, USD'].sort_values('Ronda_Orden')
            rotacion = rrhh[rrhh['Metrica'] == 'Rotación de personal, %'].sort_values('Ronda_Orden')
            if not salario.empty and not rotacion.empty:
                # Antes doble eje Y (Salario en USD y Rotación en % superpuestos en el mismo plano) --
                # dos paneles apilados, cada métrica con su propia escala.
                chart_dos_metricas_apiladas('Evolución: Salario vs Rotación',
                                             salario['Ronda'], salario['Valor'], 'Salario (USD)', COLOR_METRICA['dinero'], 'line',
                                             rotacion['Ronda'], rotacion['Valor'], 'Rotación (%)', COLOR_METRICA['riesgo'], 'line')
        with col_d:
            st.subheader('Capacitación e impacto')
            capac = rrhh[rrhh['Metrica'] == 'Presupuesto mensual para capacitación, USD'].sort_values('Ronda_Orden')
            efic = rrhh[rrhh['Metrica'] == 'Multiplicador de la eficiencia de RRHH'].sort_values('Ronda_Orden')
            if not capac.empty and not efic.empty:
                chart_dos_metricas_apiladas('Capacitación vs. eficiencia de RRHH',
                                             capac['Ronda'], capac['Valor'], 'Presupuesto capacitación (USD)', COLOR_METRICA['dinero'], 'bar',
                                             efic['Ronda'], efic['Valor'], 'Multiplicador eficiencia RRHH', COLOR_METRICA['eficiencia'], 'line')
                st.caption('Ojo con leer una relación directa: el efecto de la capacitación no es instantáneo, así que el '
                           'presupuesto de un año y el multiplicador de ese MISMO año no se explican entre sí. '
                           'Lo que hay que mirar es la pendiente del multiplicador en los años siguientes a un aumento de presupuesto.')
            else:
                st.info('Sin datos de capacitación para este equipo.')

        st.divider()
        st.subheader(f'Benchmark Competitivo de I+D y Talento — {ronda_snapshot}')
        st.caption('Comparativa de los 7 equipos en el año seleccionado: dotación de ingenieros de I+D vs. multiplicador de eficiencia (lo que define la capacidad real de desarrollo propio) y política salarial vs. rotación.')
        rrhh_snap = df[(df['Estado'] == 'Informe de RRHH') & (df['Ronda'] == ronda_snapshot)].copy()
        rrhh_snap['Valor'] = num(rrhh_snap['Valor'])
        if not rrhh_snap.empty:
            col_b1, col_b2 = st.columns(2)
            with col_b1:
                hc_s = rrhh_snap[rrhh_snap['Metrica'] == 'Número de personal de I+D, esta ronda'].set_index('Empresa')['Valor']
                ef_s = rrhh_snap[rrhh_snap['Metrica'] == 'Multiplicador de la eficiencia de RRHH'].set_index('Empresa')['Valor']
                df_b1 = pd.DataFrame({'Empresa': COMPANIES, 'Personal': [hc_s.get(e) for e in COMPANIES], 'Eficiencia': [ef_s.get(e) for e in COMPANIES]}).dropna()
                if not df_b1.empty:
                    df_b1['CapacidadEfectiva'] = df_b1['Personal'] * df_b1['Eficiencia']
                    df_b1 = df_b1.sort_values('CapacidadEfectiva', ascending=False)
                    fig_b1 = go.Figure()
                    fig_b1.add_trace(go.Bar(
                        x=df_b1['Empresa'], y=df_b1['Personal'], name='Personal I+D (personas)',
                        marker_color=[COLOR_CADIZ if e == MY_COMPANY else MUTED_PALETTE[0] for e in df_b1['Empresa']],
                        text=df_b1['Personal'].apply(lambda v: f'{v:,.0f}'), textposition='inside', yaxis='y1',
                        hovertemplate='<b>%{x}</b><br>Personal I+D: %{y:,.0f} ing.<extra></extra>'))
                    fig_b1.add_trace(go.Scatter(
                        x=df_b1['Empresa'], y=df_b1['Eficiencia'], name='Multiplicador Eficiencia',
                        mode='lines+markers', line=dict(color=COLOR_METRICA['eficiencia'], width=3),
                        marker=dict(size=9, color=COLOR_METRICA['eficiencia']), yaxis='y2',
                        hovertemplate='<b>%{x}</b><br>Multiplicador eficiencia: %{y:.3f}x<extra></extra>'))
                    fig_b1.update_layout(
                        title=f'Dotación de I+D y Multiplicador de Eficiencia — {ronda_snapshot}',
                        yaxis=dict(title='Ingenieros I+D', side='left', rangemode='tozero'),
                        yaxis2=dict(title='Multiplicador (x)', side='right', overlaying='y', showgrid=False),
                        legend=dict(orientation='h', yanchor='top', y=-0.22, xanchor='center', x=0.5))
                    mostrar(fig_b1)
            with col_b2:
                sal_s = rrhh_snap[rrhh_snap['Metrica'] == 'Salario mensual, USD'].set_index('Empresa')['Valor']
                rot_s = rrhh_snap[rrhh_snap['Metrica'] == 'Rotación de personal, %'].set_index('Empresa')['Valor']
                cap_s = rrhh_snap[rrhh_snap['Metrica'] == 'Presupuesto mensual para capacitación, USD'].set_index('Empresa')['Valor']
                df_b2 = pd.DataFrame({'Empresa': COMPANIES, 'Salario': [sal_s.get(e) for e in COMPANIES],
                                      'Rotacion': [rot_s.get(e) for e in COMPANIES],
                                      'Capacitacion': [cap_s.get(e, 300) for e in COMPANIES]}).dropna(subset=['Salario', 'Rotacion'])
                if not df_b2.empty:
                    fig_b2 = px.scatter(
                        df_b2, x='Salario', y='Rotacion', size='Capacitacion', color='Empresa',
                        color_discrete_map=COLOR_MAP, text='Empresa',
                        title=f'Salario Mensual vs. Rotación (tamaño = Capacitación) — {ronda_snapshot}')
                    fig_b2.update_traces(textposition='top center', showlegend=False)
                    fig_b2.update_layout(xaxis_title='Salario mensual (USD)', yaxis_title='Rotación de personal (%)')
                    linea_media(fig_b2, df_b2['Salario'].mean(), eje='x', etiqueta='Salario Prom')
                    linea_media(fig_b2, df_b2['Rotacion'].mean(), eje='y', etiqueta='Rotación Prom')
                    mostrar(fig_b2)

        st.write('')
        col_ev_r1, col_ev_r2 = st.columns(2)
        with col_ev_r1:
            sub_ef_all = df[(df['Estado'] == 'Informe de RRHH') & (df['Metrica'] == 'Multiplicador de la eficiencia de RRHH')].copy()
            chart_evolucion(sub_ef_all, 'Multiplicador de Eficiencia de RRHH (7 equipos)')
        with col_ev_r2:
            sub_hc_all = df[(df['Estado'] == 'Informe de RRHH') & (df['Metrica'] == 'Número de personal de I+D, esta ronda')].copy()
            chart_evolucion(sub_hc_all, 'Dotación de Personal de I+D (7 equipos)')

    with bloque_sost:
        # ---- Certificación ESG + Evolución del ESG (nuevo, Adenda 34, a pedido del equipo) ----
        st.subheader('Certificación de sostenibilidad')
        st.caption(f'Nivel de certificación alcanzado por cada equipo, {ronda_snapshot} — dato categórico '
                   'que publica CESIM ("Sin certificación" / "Bronce" / "Plata" / "Oro"), no un score numérico.')
        cert_sub = df[(df['Estado'] == 'Informe ESG') & (df['Metrica'] == 'Certificaciones de sostenibilidad') &
                      (df['Ronda'] == ronda_snapshot)][['Empresa', 'Valor']].dropna()
        if not cert_sub.empty:
            # Mismo patrón visual que los "chips" de Estrategia de marketing (seccion_mercado) --
            # color por NIVEL de certificación (orden fijo, no por orden de aparición), y el equipo en
            # foco destacado con el borde lila de identidad (clase 'destacado', ya definida en el CSS
            # de la app).
            niveles_cert = ['Sin certificación', 'Bronce', 'Plata', 'Oro']
            colores_cert = dict(zip(niveles_cert, [MUTED_PALETTE[0], '#A6702E', '#8C97A6', '#C9922E']))
            cert_sub = cert_sub.copy()
            cert_sub['_orden'] = cert_sub['Valor'].apply(lambda v: niveles_cert.index(v) if v in niveles_cert else -1)
            cert_sub = cert_sub.sort_values(['_orden', 'Empresa'], ascending=[False, True])
            chips_cert = []
            for _, fila in cert_sub.iterrows():
                color = colores_cert.get(fila['Valor'], MUTED_PALETTE[0])
                clase = 'chip-estrategia destacado' if fila['Empresa'] == MY_COMPANY else 'chip-estrategia'
                chips_cert.append(f'<span class="{clase}" style="background-color:{color}">'
                                   f'{fila["Empresa"]} · {fila["Valor"]}</span>')
            st.markdown(' '.join(chips_cert), unsafe_allow_html=True)
        else:
            st.info(f'Sin datos de certificación de sostenibilidad para {ronda_snapshot}.')

        st.divider()
        st.subheader('Evolución del ESG')
        # 'Reputación ESG' (Subgrupo='Puntuación final') es el score agregado que publica CESIM en una
        # escala absoluta (~2,5-3,7 en los RDOS reales de CADIZ) -- NO es la suma de los % de impacto
        # en la demanda que se ven más abajo (ver nota de la Adenda 22, un poco más abajo en este
        # mismo bloque) -- por eso va en su propio chart_evolucion(), no mezclado con el heatmap/balance.
        esg_evol_sub = df[(df['Estado'] == 'Informe ESG') & (df['Seccion'] == 'Impactos en la demanda') &
                          (df['Subgrupo'] == 'Puntuación final') & (df['Metrica'] == 'Reputación ESG')].copy()
        chart_evolucion(esg_evol_sub, 'Reputación ESG (score)')

        # Adenda 35 (a pedido del equipo: "que contemple las 3 variables que lo componen -- ambiental,
        # social, gobernanza"): el gráfico de arriba compara el score AGREGADO de CADIZ contra los 7
        # equipos, pero no muestra de qué está hecho. Acá se desagrega en los 3 sub-scores que lo
        # componen -- misma fuente, mismo Subgrupo='Puntuación final', misma escala absoluta ~2,5-3,7
        # -- pero SOLO para {empresa_analisis}: desagregar 3 componentes x 7 equipos a la vez (21
        # líneas) deja de ser legible, y el objetivo acá es "cómo viene construyendo CADIZ su ESG",
        # no compararlo contra el resto (eso ya lo cubre el gráfico agregado de arriba).
        esg_componentes = df[(df['Estado'] == 'Informe ESG') & (df['Seccion'] == 'Impactos en la demanda') &
                             (df['Subgrupo'] == 'Puntuación final') &
                             (df['Metrica'].isin(['Ambiental (E)', 'Social (S)', 'Gobernanza (G)'])) &
                             (df['Empresa'] == empresa_analisis)].copy()
        esg_componentes['Valor'] = num(esg_componentes['Valor'])
        esg_componentes = esg_componentes.dropna(subset=['Valor']).sort_values('Ronda_Orden')
        if esg_componentes.empty:
            st.info(f'Sin datos de componentes ESG (Ambiental/Social/Gobernanza) para {empresa_analisis}.')
        else:
            _COMPONENTES_ESG = ['Ambiental (E)', 'Social (S)', 'Gobernanza (G)']
            COLOR_ESG_COMP = dict(zip(_COMPONENTES_ESG, MUTED_SIN_MARRON))
            fig_esg_comp = go.Figure()
            for metrica in _COMPONENTES_ESG:
                d_m = esg_componentes[esg_componentes['Metrica'] == metrica].sort_values('Ronda_Orden')
                if d_m.empty:
                    continue
                txt_esg_c = _hover_yoy_textos(d_m['Ronda'], d_m['Valor'], fmt_fn=lambda v: f'{v:,.2f}')
                fig_esg_comp.add_trace(go.Scatter(x=d_m['Ronda'], y=d_m['Valor'], mode='lines+markers', name=metrica,
                                                   line=dict(color=COLOR_ESG_COMP[metrica], width=2.5),
                                                   marker=dict(size=6), text=txt_esg_c,
                                                   hovertemplate=f'<b>%{{x}}</b><br>{metrica}: %{{text}}<extra></extra>'))
            fig_esg_comp.update_layout(title=f'Componentes del ESG — {empresa_analisis}',
                                        xaxis=dict(categoryorder='array', categoryarray=RONDAS_ORDENADAS),
                                        legend=dict(orientation='h', yanchor='top', y=-0.2, xanchor='center', x=0.5))
            mostrar(fig_esg_comp)
            st.caption(f'Los 3 componentes que arman la "Reputación ESG" de {empresa_analisis} (gráfico de arriba).')

        st.divider()
        st.subheader('Impacto ambiental')
        c1, c2 = st.columns(2)
        pais_esg = c1.selectbox('País', ['EE.UU.', 'Asia'], key='pais_esg_rrhh')
        ind = c2.selectbox('Indicador', ['Emisiones de CO2', 'Consumo de energía', 'Consumo de agua'], key='ind_esg_rrhh')
        dicc = {'Emisiones de CO2': 'Total, toneladas métricas', 'Consumo de energía': 'Total, MWh', 'Consumo de agua': 'Total, miles de m3'}
        sub_amb = df[(df['Estado'] == 'Informe ESG') & (df['Seccion'] == f'Impacto ambiental, {pais_esg}') & (df['Metrica'] == dicc[ind])]
        chart_comparacion_equipos(sub_amb, f'{ind} — {pais_esg}')

        st.divider()
        # Adenda 22 (a pedido del equipo): reemplaza el scatter "Reputación ESG y cuota de mercado"
        # (un único score agregado por País vs. Share) por dos vistas más ricas construidas sobre
        # 'Informe ESG' -> Sección 'Impactos en la demanda', que trae el detalle línea por línea de
        # CADA variable Ambiental/Social/Gobernanza y su % de impacto sobre la demanda -- filtrando
        # SIEMPRE Subgrupo != 'Puntuación final' porque esas 4 filas (Ambiental (E), Social (S),
        # Gobernanza (G), Reputación ESG) son un score en una escala absoluta (~2,5-3,7) que NO es la
        # suma de los % de abajo (verificado: para CADIZ Ronda 1 los 5 ítems de Ambiental (E) suman
        # -11,8%, muy distinto del score 2,52 de 'Ambiental (E)' en Puntuación final) -- mezclar
        # ambas unidades en el mismo gráfico sería engañoso.
        def _pct(series):
            return pd.to_numeric(series.astype(str).str.rstrip('%'), errors='coerce')

        imp_esg = df[(df['Estado'] == 'Informe ESG') & (df['Seccion'] == 'Impactos en la demanda') &
                     (df['Subgrupo'] != 'Puntuación final') & (df['Ronda'] == ronda_snapshot)][['Empresa', 'Subgrupo', 'Metrica', 'Valor']].copy()
        imp_esg['Valor'] = _pct(imp_esg['Valor'])
        imp_esg = imp_esg.dropna(subset=['Valor'])

        st.subheader('ESG Impact Heatmap')
        st.caption('% de impacto de cada variable ESG sobre la demanda — ' + str(ronda_snapshot) +
                   ', los 7 equipos. Verde = impacto positivo sobre la demanda, rojo = negativo. Filas agrupadas '
                   'por Ambiental (E) / Social (S) / Gobernanza (G) -- NO incluye los scores agregados de '
                   '"Puntuación final" (otra escala, ver nota).')
        if not imp_esg.empty:
            orden_metricas = (imp_esg[['Subgrupo', 'Metrica']].drop_duplicates()
                               .sort_values(['Subgrupo', 'Metrica'])['Metrica'].tolist())
            piv_heat = imp_esg.pivot_table(index='Metrica', columns='Empresa', values='Valor', aggfunc='mean')
            piv_heat = piv_heat.reindex(orden_metricas)
            max_abs = max(1.0, float(piv_heat.abs().max().max()) if not piv_heat.empty else 1.0)
            fig_heat = px.imshow(piv_heat, color_continuous_scale='RdYlGn', color_continuous_midpoint=0,
                                  zmin=-max_abs, zmax=max_abs, text_auto='.1f', aspect='auto',
                                  labels=dict(color='% impacto'))
            fig_heat.update_xaxes(side='top')
            fig_heat.update_layout(title=f'Impactos en la demanda, % — {ronda_snapshot}', height=420)
            mostrar(fig_heat)
        else:
            st.info('Sin datos de "Impactos en la demanda" para este año.')

        st.divider()
        st.subheader('Balance Neto ESG')
        st.caption('Suma de los % de impacto sobre la demanda de cada bloque (Ambiental, Social, Gobernanza) por equipo '
                   '-- el total de la barra es el Impacto Neto en la demanda de todo el informe ESG, no un promedio.')
        if not imp_esg.empty:
            balance = imp_esg.groupby(['Empresa', 'Subgrupo'], as_index=False)['Valor'].sum()
            netos = balance.groupby('Empresa', as_index=False)['Valor'].sum().rename(columns={'Valor': 'Neto'})
            orden_emp = netos.sort_values('Neto', ascending=False)['Empresa'].tolist()
            # 3 categorías genéricas (E/S/G, para los 7 equipos) -- sin identidad ni sentimiento,
            # tonos muted (Adenda 25; el marrón que tenía "Social (S)" se saca en la misma Adenda,
            # sin pasar a lila porque tampoco es identidad de CADIZ).
            # Fix "ya casi": "Social (S)" en MUTED_PALETTE[5] quedaba casi idéntico a "Gobernanza (G)"
            # en MUTED_PALETTE[0] (mismo gráfico, barras apiladas) -- se reemplaza por el rosa apagado
            # nuevo, bien separado de los otros dos tonos.
            colores_subgrupo = {'Ambiental (E)': MUTED_PALETTE[2],
                                 'Social (S)': '#B67C8F',
                                 'Gobernanza (G)': MUTED_PALETTE[0]}
            fig_bal = px.bar(balance, x='Empresa', y='Valor', color='Subgrupo', barmode='relative',
                              category_orders={'Empresa': orden_emp},
                              color_discrete_map=colores_subgrupo,
                              title=f'Balance Neto ESG (Ambiental + Social + Gobernanza) — {ronda_snapshot}')
            fig_bal.update_layout(yaxis_title='% impacto en la demanda (suma)')
            fig_bal.add_trace(go.Scatter(x=netos['Empresa'], y=netos['Neto'], mode='markers+text',
                                          text=netos['Neto'].apply(lambda v: f'{v:+.1f}%'), textposition='top center',
                                          marker=dict(size=1, color='rgba(0,0,0,0)'), showlegend=False, hoverinfo='skip'))
            mostrar(fig_bal)
        else:
            st.info('Sin datos de "Impactos en la demanda" para este año.')
# =================================================================
# SECCIÓN 6 — CONTROL DE GESTIÓN
# =================================================================
def seccion_control_gestion():
    """Adenda 29 (a pedido del equipo): antes 'Comparativa Plan vs. Real' vivía repartida en una
    sub-pestaña de Resultados/Mercado/Operaciones/Finanzas, cada una mostrando el desvío de SU
    propio recorte (Ingresos, Cuota, Costo fabril, KPIs financieros) sin conexión entre sí. Acá se
    arma la misma información -- sin sacar ningún gráfico -- como una única narrativa secuencial de
    3 niveles, de lo más agregado a lo más específico:
      Nivel 1 (Impacto Financiero Macro): panel compacto de KPIs financieros (EBITDA, ROS, etc.).
      Nivel 2 (Desvío Comercial e Ingresos): waterfall Precio/Volumen/Mix + Cuota Proyectada vs Real.
      Nivel 3 (Desvío Fabril y de Costos): waterfall de costo unitario de fabricación por área.
    Es inherentemente sobre CADIZ (es nuestra propia proyección en el modelo de gestión, no la de
    'Equipo en foco') -- si se está mirando otro equipo, se avisa en vez de mostrar el gap de CADIZ
    sin aclarar de quién es (mismo criterio que ya usaba cada sub-pestaña vieja)."""
    if empresa_analisis != MY_COMPANY:
        st.caption('Control de Gestión es sobre la proyección propia de ULTI en el modelo de gestión — '
                   'cambiá "Equipo en foco" a ULTI en la barra lateral para verlo.')
        return
    ronda_num_cg = ronda_a_num(ronda_snapshot)
    df_proy_cg = get_proyeccion(ronda_num_cg)

    st.markdown('#### Nivel 1 — Impacto Financiero Macro')
    # mostrar_metricas=False + mostrar_extras=False: SOLO el panel de barras horizontales
    # (chart_bullet_panel, CROSSWALK_FINANZAS) -- mismo criterio que ya pedía el equipo en Finanzas
    # (Adenda 26/27). NO se reactiva fila3_finanzas_flujo_caja() (el puente CFO->CFI->CFF): sigue
    # definida sin uso más arriba, a pedido explícito de Mati para esta reorganización.
    panel_comparativa_plan_real(df_all.copy(), ronda_snapshot, crosswalk=CROSSWALK_FINANZAS, key_suffix='cg_nivel1',
                                 mostrar_directo=True, mostrar_metricas=False, mostrar_extras=False)

    st.divider()
    st.markdown('#### Nivel 2 — Desvío Comercial e Ingresos')
    # Adenda 33 (a pedido del equipo, reordenamiento narrativo + consolidación de selectores):
    # el orden estricto de lectura pasa a ser Físico/Volumen -> Posicionamiento relativo -> Impacto
    # financiero final, es decir: 1) Demanda Estimada vs. Real, 2) Cuota de mercado Proyectado vs.
    # Real, 3) Análisis de Desvíos de Ingresos (Waterfall) -- antes el waterfall de Ingresos iba en
    # el medio, cortando la lectura comercial entre la demanda y la cuota. Un único selector de
    # Mercado al inicio del nivel alimenta los tres gráficos (antes cada uno tenía su propio
    # st.selectbox('Mercado', ...) redundante, con la misma lista _MERCADOS_GAP).
    # OJO (Categoría 3, decisión de modelización, no pedida explícitamente): el selector NO incluye
    # "Global" -- _MERCADOS_GAP = ["EE.UU.", "Asia", "Europa"] son las 3 monedas nativas en las que
    # CESIM reporta Precio de venta/Ingresos (USD/RMB/EUR, ver MONEDA_MERCADO en gap_analysis.py); el
    # waterfall de Ingresos ya documentaba (ver su caption) que NO se consolida a una sola moneda para
    # no asumir un tipo de cambio que el simulador no publica. Si se agrega "Global" al selector, ese
    # tercer gráfico rompería o necesitaría una tasa de cambio inventada -- se avisa en vez de
    # agregarlo como si fuera una regla confirmada.
    mercado_sel_cg = st.selectbox('Mercado', _MERCADOS_GAP, key='sel_cg_nivel2_mercado')
    fila_cg_demanda_estimada(df_all.copy(), ronda_snapshot, ronda_num_cg, df_proy_cg, mercado_sel_cg)
    st.divider()
    fila3_mercado_cuota_objetivo(df_all.copy(), ronda_snapshot, ronda_num_cg, df_proy_cg, mercado_sel_cg)
    st.divider()
    fila3_resultados_ingresos(df_all.copy(), ronda_snapshot, ronda_num_cg, df_proy_cg, mercado_sel_cg)

    st.divider()
    st.markdown('#### Nivel 3 — Desvío Fabril y de Costos')
    # Adenda 33: único selector de Área de producción en la cabecera del nivel (antes vivía adentro
    # de fila3_operaciones_gap_fabricacion); hoy el nivel tiene una sola fila, pero se deja acá para
    # no reintroducir un selector propio si se agrega otra métrica de esta vista más adelante.
    area_sel_cg = st.selectbox('Área de producción', _AREAS_GAP, key='sel_cg_nivel3_area')
    fila3_operaciones_gap_fabricacion(df_all.copy(), ronda_snapshot, ronda_num_cg, df_proy_cg, area_sel_cg)
# ---------------- Router ----------------
st.title(seccion)
if seccion == SECCIONES[0]: seccion_resultado()
elif seccion == SECCIONES[1]: seccion_mercado()
elif seccion == SECCIONES[2]: seccion_operaciones()
elif seccion == SECCIONES[3]: seccion_finanzas()
elif seccion == SECCIONES[4]: seccion_rrhh_sostenibilidad()
elif seccion == SECCIONES[5]: seccion_control_gestion()
